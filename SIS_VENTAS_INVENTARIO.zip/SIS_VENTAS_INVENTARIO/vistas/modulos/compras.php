<?php
if (!class_exists("ModeloProductos")) {
    if (file_exists("modelos/productos.modelo.php")) {
        require_once "modelos/productos.modelo.php";
    }
}
if (!class_exists("ControladorProductos")) {
    if (file_exists("controladores/productos.controlador.php")) {
        require_once "controladores/productos.controlador.php";
    }
}
if (!class_exists("ModeloCompras")) {
    if (file_exists("modelos/compras.modelo.php")) {
        require_once "modelos/compras.modelo.php";
    }
}
if (!class_exists("ControladorCompras")) {
    if (file_exists("controladores/compras.controlador.php")) {
        require_once "controladores/compras.controlador.php";
    }
}

require_once "controladores/proveedores.controlador.php";
require_once "modelos/proveedores.modelo.php";

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold"><i class="fa-solid fa-truck-ramp-box me-2 text-primary"></i> Módulo de Compras</h3>
</div>

<!-- NAVEGACIÓN POR PESTAÑAS -->
<ul class="nav nav-tabs mb-4 border-bottom-0" id="comprasTab" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active fw-bold px-4 py-2" id="nueva-compra-tab" data-bs-toggle="tab" data-bs-target="#nueva-compra" type="button" role="tab"><i class="fa-solid fa-cart-plus me-2"></i>Nueva Compra</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link fw-bold px-4 py-2" id="historial-tab" data-bs-toggle="tab" data-bs-target="#historial" type="button" role="tab"><i class="fa-solid fa-clock-rotate-left me-2"></i>Historial de Compras</button>
    </li>
</ul>

<div class="tab-content" id="comprasTabContent">
    
    <!-- PESTAÑA 1: NUEVA COMPRA -->
    <div class="tab-pane fade show active" id="nueva-compra" role="tabpanel">
        <div class="row">
            <!-- COLUMNA IZQUIERDA: FORMULARIO -->
            <div class="col-lg-5 col-12 mb-4">
                <div class="card border-0 shadow-sm rounded-3">
                    <form method="post" class="formularioCompra">
                        <div class="card-body p-4">

                            <!-- CÓDIGO DE ORDEN -->
                            <div class="mb-3">
                                <label class="form-label text-muted">N° Orden de Compra</label>
                                <?php
                                $compras = ControladorCompras::ctrMostrarCompras(null, null);
                                if (!$compras) {
                                    $codigo = "COMP-10001";
                                } else {
                                    $codigo = "COMP-" . (count($compras) + 10001);
                                }
                                ?>
                                <input type="text" class="form-control bg-light fw-bold text-primary" name="nuevaCompra" value="<?php echo $codigo; ?>" readonly>
                            </div>

                            <!-- PROVEEDOR -->
                            <div class="mb-3">
                                <label class="form-label fw-bold">Proveedor:</label>
                                     <select class="form-select form-select-lg" name="nuevoProveedor" required>
                                     <option value="">-- Seleccionar Proveedor --</option>
                                     <?php
                                        $proveedores = ControladorProveedores::ctrMostrarProveedores(null, null);
                                        foreach ($proveedores as $key => $value) {
            // Guardamos directamente la Razón Social en el value para tu columna actual
                                    echo '<option value="' . $value["razon_social"] . '">' . $value["razon_social"] . ' - RUC: ' . ($value["ruc"] ?? 'S/RUC') . '</option>';
                        
                                        } 
                                    ?>
                                    </select>
                            </div>

                            <hr class="my-3">

                            <!-- TABLA PRODUCTOS SELECCIONADOS -->
                            <div class="table-responsive mb-3">
                                <table class="table table-sm align-middle">
                                    <thead>
                                        <tr>
                                            <th>Producto</th>
                                            <th style="width: 80px;">Cant.</th>
                                            <th style="width: 110px;">P. Unit (S/)</th>
                                            <th style="width: 90px;">Total</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody class="nuevoProductoCompra">
                                        <!-- Se agregan via JavaScript -->
                                    </tbody>
                                </table>
                            </div>

                            <input type="hidden" id="listaProductos" name="listaProductos">

                            <hr class="my-3">

                            <!-- MÉTODO DE PAGO Y TOTAL -->
                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <label class="form-label fw-bold">Método de Pago</label>
                                    <select class="form-select" name="nuevoMetodoPago" required>
                                        <option value="Efectivo">Efectivo</option>
                                        <option value="Transferencia">Transferencia</option>
                                        <option value="Crédito">Crédito a proveedor</option>
                                    </select>
                                </div>
                                <div class="col-6 text-end">
                                    <label class="form-label fw-bold text-dark">Total Compra</label>
                                    <div class="input-group">
                                        <span class="input-group-text fw-bold">S/</span>
                                        <input type="text" class="form-control form-control-lg fw-bold text-primary text-end" id="nuevoTotalCompra" name="totalCompra" value="0.00" readonly required>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="card-footer bg-white p-3 border-0">
                            <button type="submit" class="btn btn-primary fw-bold w-100 py-2"><i class="fa-solid fa-floppy-disk me-1"></i> Guardar Compra e Incrementar Stock</button>
                        </div>
                        <?php
                            ControladorCompras::ctrCrearCompra();
                        ?>
                    </form>
                </div>
            </div>

            <!-- COLUMNA DERECHA: SELECCIÓN DE PRODUCTOS -->
            <div class="col-lg-7 col-12">
                <div class="card border-0 shadow-sm rounded-3">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center gap-2 mb-3"><h5 class="fw-bold mb-0">Seleccionar Producto para Reabastecer</h5><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalScannerCodigoCompra"><i class="fa-solid fa-barcode me-1"></i> Escanear código de barras</button></div>
                        <div class="table-responsive">

                            <!-- TABLA CON DATATABLES INTEGRADO -->
                            <table class="table table-hover align-middle tablaProductosCompra dt-responsive w-100">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Código</th>
                                        <th>Descripción</th>
                                        <th>Stock Actual</th>
                                        <th class="text-center">Acción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $productos = ControladorProductos::ctrMostrarProductos(null, null);
                                    if (is_array($productos)) {
                                        foreach ($productos as $value) {
                                            echo '<tr>
                                                <td class="fw-bold codigoProducto"><div>'.$value["codigo"].'</div>'.(!empty($value["codigo_barras"]) ? '<small class="text-muted codigoBarrasProducto"><i class="fa-solid fa-barcode me-1"></i>'.htmlspecialchars($value["codigo_barras"], ENT_QUOTES, "UTF-8").'</small>' : '').'</td>
                                                <td>'.$value["descripcion"].'</td>
                                                <td><span class="badge bg-info text-dark fs-6">'.$value["stock"].'</span></td>
                                                <td class="text-center">
                                                    <button class="btn btn-success btn-sm agregarProductoCompra" idProducto="'.$value["id"].'"><i class="fa-solid fa-plus me-1"></i> Agregar</button>
                                                </td>
                                            </tr>';
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- PESTAÑA 2: HISTORIAL DE COMPRAS -->
    <div class="tab-pane fade" id="historial" role="tabpanel">
        <div class="card border-0 shadow-sm rounded-3">
            <div class="card-body p-4">
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle tablaHistorialCompras dt-responsive w-100">
                        <thead class="table-dark">
                            <tr>
                                <th>N° Orden</th>
                                <th>Proveedor</th>
                                <th>Método de Pago</th>
                                <th>Total Compra</th>
                                <th>Fecha</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $historialCompras = ControladorCompras::ctrMostrarCompras(null, null);
                            if (is_array($historialCompras) && count($historialCompras) > 0) {
                                foreach ($historialCompras as $compra) {
                                    echo '<tr>
                                        <td class="fw-bold text-primary">'.$compra["codigo"].'</td>
                                        <td>'.$compra["proveedor"].'</td>
                                        <td><span class="badge bg-secondary">'.$compra["metodo_pago"].'</span></td>
                                        <td class="fw-bold">S/ '.number_format($compra["total"], 2).'</td>
                                        <td>'.$compra["fecha"].'</td>
                                        <td>
                                            <button class="btn btn-info btn-sm btnVerDetalleCompra text-white fw-bold" idCompra="'.$compra["id"].'" codigoCompra="'.$compra["codigo"].'" data-bs-toggle="modal" data-bs-target="#modalDetalleCompra">
                                                <i class="fa-solid fa-eye me-1"></i> Ver Detalle
                                            </button>
                                        </td>
                                    </tr>';
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- MODAL VER DETALLE DE COMPRA -->
<div class="modal fade" id="modalDetalleCompra" tabindex="-1" aria-labelledby="modalDetalleCompraLabel">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title" id="modalDetalleCompraLabel"><i class="fa-solid fa-receipt me-2"></i>Detalle de Compra</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Producto</th>
                                <th class="text-center">Cantidad</th>
                                <th class="text-end">Precio Unit. (S/)</th>
                                <th class="text-end">Subtotal (S/)</th>
                            </tr>
                        </thead>
                        <tbody id="contenidoDetalleCompra">
                            <!-- Se llena dinámicamente con JS -->
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-3 pt-2 border-top">
                    <h5 class="fw-bold mb-0 me-3">Monto Total Orden:</h5>
                    <h4 class="fw-bold text-primary mb-0" id="totalOrdenModal">S/ 0.00</h4>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary fw-bold" data-bs-dismiss="modal"><i class="fa-solid fa-xmark me-1"></i> Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- MODAL LECTOR QR -->
<div class="modal fade" id="modalScannerCodigoCompra" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content">
<div class="modal-header bg-success text-white"><h5 class="modal-title"><i class="fa-solid fa-barcode me-2"></i>Buscar producto por código de barras</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><div id="readerComprasCodigo" class="border rounded overflow-hidden mb-3"></div><div class="input-group"><input type="text" id="codigoBarrasCompra" class="form-control" placeholder="Código de barras leído o escribir código..."><button type="button" class="btn btn-success" id="btnBuscarCodigoBarrasCompra"><i class="fa-solid fa-magnifying-glass"></i></button></div><small class="text-muted d-block mt-2">Compatible con EAN-13, EAN-8, UPC, Code 128, Code 39, ITF y Codabar. La cámara requiere HTTPS o localhost.</small><div id="estadoCodigoBarrasCompra" class="small mt-2"></div></div>
</div></div></div>

<!-- SCRIPT JS PARA EL FUNCIONAMIENTO DE COMPRAS, MODAL Y DATATABLES -->
<script>
$(document).ready(function() {

    /*=============================================
    INICIALIZAR DATATABLE EN PRODUCTOS
    =============================================*/
    if ($.fn.DataTable.isDataTable('.tablaProductosCompra')) {
        $('.tablaProductosCompra').DataTable().destroy();
    }
    
    $('.tablaProductosCompra').DataTable({
        "pageLength": 5,
        "lengthChange": false,
        "searching": true,
        "ordering": true,
        "info": false,
        "language": {
            "sSearch": "Buscar producto:",
            "sZeroRecords": "No se encontraron productos coincidentes",
            "sEmptyTable": "No hay productos disponibles",
            "oPaginate": {
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            }
        }
    });

    /*=============================================
    INICIALIZAR DATATABLE EN HISTORIAL
    =============================================*/
    if ($.fn.DataTable.isDataTable('.tablaHistorialCompras')) {
        $('.tablaHistorialCompras').DataTable().destroy();
    }

    $('.tablaHistorialCompras').DataTable({
        "pageLength": 10,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "sSearch": "Buscar en historial:",
            "sZeroRecords": "No se encontraron compras en el historial",
            "sEmptyTable": "No hay compras registradas hasta el momento.",
            "sInfo": "Mostrando _START_ a _END_ de _TOTAL_ compras",
            "sInfoEmpty": "Mostrando 0 a 0 de 0 compras",
            "sLengthMenu": "Mostrar _MENU_ registros",
            "oPaginate": {
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            }
        }
    });
});

/*=============================================
AGREGAR PRODUCTO A LA TABLA DE COMPRA
=============================================*/
$(document).on("click", ".agregarProductoCompra", function() {

    var idProducto = $(this).attr("idProducto");
    $(this).removeClass("btn-success agregarProductoCompra").addClass("btn-secondary").attr("disabled", true);

    var datos = new FormData();
    datos.append("idProducto", idProducto);

    $.ajax({
        url: "ajax/productos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            if (Array.isArray(respuesta) && respuesta.length > 0) {
                respuesta = respuesta[0];
            }

            var descripcion = respuesta["descripcion"];
            var precioCompra = respuesta["precio_compra"] || 0;

            $(".nuevoProductoCompra").append(
                '<tr>' +
                    '<td><small class="fw-bold d-block">' + descripcion + '</small></td>' +
                    '<td><input type="number" class="form-control form-control-sm nuevaCantidadProducto" idProducto="' + idProducto + '" name="nuevaCantidadProducto" min="1" value="1" required></td>' +
                    '<td>' +
                        '<input type="number" step="0.01" min="0" class="form-control form-control-sm nuevoPrecioCompra" name="nuevoPrecioCompra" value="' + precioCompra + '" required>' +
                    '</td>' +
                    '<td>' +
                        '<span class="fw-bold subtotalProducto">S/ ' + Number(precioCompra).toFixed(2) + '</span>' +
                    '</td>' +
                    '<td><button type="button" class="btn btn-danger btn-sm quitarProductoCompra" idProducto="' + idProducto + '"><i class="fa-solid fa-xmark"></i></button></td>' +
                '</tr>'
            );

            sumarTotalesCompra();
            listarProductosCompra();
        }
    });
});

/*=============================================
QUITAR PRODUCTO DE LA COMPRA
=============================================*/
$(document).on("click", ".quitarProductoCompra", function() {

    $(this).parent().parent().remove();
    var idProducto = $(this).attr("idProducto");

    $("button[idProducto='" + idProducto + "']").removeClass("btn-secondary").addClass("btn-success agregarProductoCompra").attr("disabled", false);

    if ($(".nuevoProductoCompra").children().length == 0) {
        $("#nuevoTotalCompra").val("0.00");
    } else {
        sumarTotalesCompra();
        listarProductosCompra();
    }
});

/*=============================================
CAMBIAR CANTIDAD O PRECIO UNITARIO
=============================================*/
$(document).on("change keyup", ".nuevaCantidadProducto, .nuevoPrecioCompra", function() {
    
    var fila = $(this).closest("tr");
    var cant = Number(fila.find(".nuevaCantidadProducto").val()) || 0;
    var precio = Number(fila.find(".nuevoPrecioCompra").val()) || 0;
    var subtotal = cant * precio;

    fila.find(".subtotalProducto").text("S/ " + subtotal.toFixed(2));

    sumarTotalesCompra();
    listarProductosCompra();
});

/*=============================================
SUMAR TOTALES
=============================================*/
function sumarTotalesCompra() {
    var filas = $(".nuevoProductoCompra tr");
    var total = 0;

    filas.each(function() {
        var cant = Number($(this).find(".nuevaCantidadProducto").val()) || 0;
        var precio = Number($(this).find(".nuevoPrecioCompra").val()) || 0;
        total += (cant * precio);
    });

    $("#nuevoTotalCompra").val(total.toFixed(2));
}

/*=============================================
LISTAR PRODUCTOS EN FORMATO JSON
=============================================*/
function listarProductosCompra() {
    var listaProductos = [];
    var filas = $(".nuevoProductoCompra tr");

    filas.each(function() {
        var cantInput = $(this).find(".nuevaCantidadProducto");
        var precioInput = $(this).find(".nuevoPrecioCompra");
        var cant = Number(cantInput.val()) || 0;
        var precio = Number(precioInput.val()) || 0;

        listaProductos.push({
            "id": cantInput.attr("idProducto"),
            "cantidad": cant,
            "precio": precio,
            "total": (cant * precio).toFixed(2)
        });
    });

    $("#listaProductos").val(JSON.stringify(listaProductos));
}

/*=============================================
VER DETALLE DE COMPRA (AJAX MODAL)
=============================================*/
$(document).on("click", ".btnVerDetalleCompra", function() {

    var idCompra = $(this).attr("idCompra");
    var codigoCompra = $(this).attr("codigoCompra");

    $("#codigoOrdenModal").text(codigoCompra);
    $("#contenidoDetalleCompra").html('<tr><td colspan="5" class="text-center text-muted"><i class="fa-solid fa-spinner fa-spin me-2"></i>Cargando productos...</td></tr>');
    $("#totalOrdenModal").text("S/ 0.00");

    var datos = new FormData();
    datos.append("idCompra", idCompra);

    $.ajax({
        url: "ajax/compras.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json"
    }).done(function(respuesta) {
        var filas = "";
        var totalGeneral = 0;

        if (Array.isArray(respuesta) && respuesta.length > 0) {
            $.each(respuesta, function(i, item) {
                var cant = Number(item.cantidad || item.cant || 0);
                var precio = Number(item.precio_unitario || item.precio_compra || item.precio || 0);
                var subtotal = Number(item.total_producto || item.total || item.subtotal || (cant * precio));
                var desc = item.descripcion || "Producto #" + (item.id_producto || (i + 1));

                totalGeneral += subtotal;

                filas += '<tr>' +
                    '<td>' + (i + 1) + '</td>' +
                    '<td class="fw-bold">' + desc + '</td>' +
                    '<td class="text-center"><span class="badge bg-primary fs-6">' + cant + '</span></td>' +
                    '<td class="text-end">S/ ' + precio.toFixed(2) + '</td>' +
                    '<td class="text-end fw-bold">S/ ' + subtotal.toFixed(2) + '</td>' +
                '</tr>';
            });
        } else {
            filas = '<tr><td colspan="5" class="text-center text-muted">No se encontraron productos registrados para esta orden.</td></tr>';
        }

        $("#contenidoDetalleCompra").html(filas);
        $("#totalOrdenModal").text("S/ " + totalGeneral.toFixed(2));

    }).fail(function(jqXHR, textStatus, errorThrown) {
        $("#contenidoDetalleCompra").html('<tr><td colspan="5" class="text-center text-danger"><i class="fa-solid fa-triangle-exclamation me-1"></i> Error al cargar el detalle (Respuesta del servidor no válida).</td></tr>');
        console.error("Error AJAX Compras:", textStatus, errorThrown, jqXHR.responseText);
    });
});

let scannerCodigoCompra=null;
function detenerScannerCodigoCompra(){if(scannerCodigoCompra){scannerCodigoCompra.stop().catch(function(){}).finally(function(){scannerCodigoCompra.clear();scannerCodigoCompra=null;});}}
function buscarYAgregarProductoCompra(codigo){codigo=String(codigo||"").trim();if(!codigo)return;const tabla=$('.tablaProductosCompra').DataTable();tabla.search(codigo).draw();setTimeout(function(){let boton=null;$('.tablaProductosCompra tbody tr').each(function(){const textoCodigo=$(this).find('.codigoProducto').text().trim().toLowerCase(); if(textoCodigo===codigo.toLowerCase() || textoCodigo.indexOf(codigo.toLowerCase())!==-1)boton=$(this).find('.agregarProductoCompra');});if(boton&&boton.length){boton.trigger('click');cerrarModalCodigoCompra();}else $('#estadoCodigoBarrasCompra').html('<span class="text-danger">No se encontró el código.</span>');},100);}
function iniciarScannerCodigoCompra(){if(typeof Html5Qrcode==="undefined"){return;}if(scannerCodigoCompra)return;scannerCodigoCompra=new Html5Qrcode("readerComprasCodigo");const formatos=[Html5QrcodeSupportedFormats.CODE_128,Html5QrcodeSupportedFormats.CODE_39,Html5QrcodeSupportedFormats.EAN_13,Html5QrcodeSupportedFormats.EAN_8,Html5QrcodeSupportedFormats.UPC_A,Html5QrcodeSupportedFormats.UPC_E,Html5QrcodeSupportedFormats.ITF,Html5QrcodeSupportedFormats.CODABAR];scannerCodigoCompra.start({facingMode:"environment"},{fps:10,qrbox:{width:320,height:120},formatsToSupport:formatos},function(t){$('#codigoBarrasCompra').val(t);buscarYAgregarProductoCompra(t);},function(){}).catch(function(){$('#estadoCodigoBarrasCompra').html('<span class="text-warning">No se pudo abrir la cámara. Usa HTTPS y concede permiso.</span>');});}
function cerrarModalCodigoCompra(){detenerScannerCodigoCompra();const m=bootstrap.Modal.getInstance(document.getElementById('modalScannerCodigoCompra'));if(m)m.hide();}
$(document).on('shown.bs.modal','#modalScannerCodigoCompra',function(){iniciarScannerCodigoCompra();});
$(document).on('hidden.bs.modal','#modalScannerCodigoCompra',function(){detenerScannerCodigoCompra();});
$(document).on('click','#btnBuscarCodigoBarrasCompra',function(){buscarYAgregarProductoCompra($('#codigoBarrasCompra').val());});
$(document).on('keydown','#codigoBarrasCompra',function(e){if(e.key==='Enter'){e.preventDefault();buscarYAgregarProductoCompra($('#codigoBarrasCompra').val());}});
</script>