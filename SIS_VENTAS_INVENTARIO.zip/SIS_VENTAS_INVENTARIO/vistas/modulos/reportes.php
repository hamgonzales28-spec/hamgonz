<?php
// 1. Obtener fechas del GET
if (isset($_GET["fechaInicial"])) {
    $fechaInicial = $_GET["fechaInicial"];
    $fechaFinal = $_GET["fechaFinal"];
} else {
    $fechaInicial = null;
    $fechaFinal = null;
}

// 2. Obtener las ventas filtradas por el rango de fechas seleccionadas
$ventas = ControladorVentas::ctrRangoFechasVentas($fechaInicial, $fechaFinal);

// 3. Obtener gráficos dinámicos (puedes pasar las fechas si tu controlador lo soporta)
$ventasFechas = ControladorVentas::ctrSumaTotalVentasPorFecha();
$productosTop = ControladorVentas::ctrProductosMasVendidos();

// 4. Calcular métricas dinámicas basadas en $ventas (filtradas)
$totalGeneral = 0;
$totalTransacciones = count($ventas);

foreach ($ventas as $v) {
    $totalGeneral += $v["total"];
}

$ticketPromedio = $totalTransacciones > 0 ? ($totalGeneral / $totalTransacciones) : 0;

// 5. Preparar arrays para Chart.js
$fechas = array();
$totalesDias = array();

if (is_array($ventasFechas)) {
    foreach (array_reverse($ventasFechas) as $item) {
        $fechas[] = date("d/m", strtotime($item["fecha_corta"]));
        $totalesDias[] = $item["total_dia"];
    }
}

$prodNombres = array();
$prodCantidades = array();

if (is_array($productosTop)) {
    foreach ($productosTop as $prod) {
        $prodNombres[] = $prod["descripcion"];
        $prodCantidades[] = $prod["total_vendido"];
    }
}
?>

<div class="content-wrapper p-3">

    <section class="content-header mb-3">
        <div class="container-fluid">
            <h1><i class="fa-solid fa-chart-line me-2"></i>Reportes y Estadísticas</h1>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <!-- BARRA SUPERIOR DE FILTROS Y EXPORTACIÓN -->
            <div class="card shadow-sm mb-4">
                <div class="card-body py-2">
                    <div class="row align-items-center g-2">
                        
                        <!-- TITULO -->
                        <div class="col-md-4 col-12">
                            <span class="fw-bold text-secondary">
                                <i class="fa-solid fa-calendar-days me-2 text-primary"></i>Rango de Análisis:
                            </span>
                        </div>

                        <!-- FILTRO DATE RANGE PICKER -->
                        <div class="col-md-5 col-8">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-white"><i class="fa-regular fa-calendar"></i></span>
                                <input type="text" class="form-control fw-bold text-center" id="btnRangoFechasReportes" readonly placeholder="Seleccionar fechas">
                                <button class="btn btn-outline-secondary" type="button" id="btnLimpiarFiltroFechas" title="Limpiar Filtro">
                                    <i class="fa-solid fa-rotate-left"></i>
                                </button>
                            </div>
                        </div>

                        <!-- BOTÓN EXPORTAR EXCEL -->
                        <div class="col-md-3 col-4 text-end">
                            <button class="btn btn-success btn-sm fw-bold w-100" id="btnExportarExcelReporte">
                                <i class="fa-solid fa-file-excel me-1"></i> Exportar
                            </button>
                        </div>

                    </div>
                </div>
            </div>

            <!-- TARJETAS DE MÉTRICAS DINÁMICAS -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card bg-primary text-white shadow-sm">
                        <div class="card-body">
                            <h6 class="card-title text-white-50">Total Recaudado</h6>
                            <h2 class="fw-bold mb-0">S/ <?php echo number_format($totalGeneral, 2); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-success text-white shadow-sm">
                        <div class="card-body">
                            <h6 class="card-title text-white-50">Total de Transacciones</h6>
                            <h2 class="fw-bold mb-0"><?php echo $totalTransacciones; ?> ventas</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-info text-white shadow-sm">
                        <div class="card-body">
                            <h6 class="card-title text-white-50">Ticket Promedio</h6>
                            <h2 class="fw-bold mb-0">
                                S/ <?php echo number_format($ticketPromedio, 2); ?>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>

            <!-- GRÁFICOS -->
            <div class="row">
                
                <!-- Gráfico de Ventas por Día -->
                <div class="col-md-7 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-white">
                            <h5 class="card-title m-0"><i class="fa-solid fa-calendar-days me-2"></i>Ventas de los Últimos Días</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="graficoVentasDias"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Gráfico de Productos Top -->
                <div class="col-md-5 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-white">
                            <h5 class="card-title m-0"><i class="fa-solid fa-fire me-2"></i>Productos Más Vendidos</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="graficoProductosTop"></canvas>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </section>

</div>

<!-- CDN DE CHART.JS -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
$(document).ready(function() {

    // 1. Detección y mantenimiento de fechas elegidas en la URL
    var urlParams = new URLSearchParams(window.location.search);
    var fInit = urlParams.get('fechaInicial');
    var fEnd = urlParams.get('fechaFinal');

    if (fInit && fEnd) {
        $('#btnRangoFechasReportes').val(fInit + ' al ' + fEnd);
    }

    // 2. Configuración del DateRangePicker
    $('#btnRangoFechasReportes').daterangepicker({
        "locale": {
            "format": "YYYY-MM-DD",
            "separator": " al ",
            "applyLabel": "Aplicar",
            "cancelLabel": "Cancelar",
            "fromLabel": "Desde",
            "toLabel": "Hasta",
            "customRangeLabel": "Personalizado",
            "daysOfWeek": ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sá"],
            "monthNames": ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
        },
        ranges: {
           'Hoy': [moment(), moment()],
           'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Últimos 7 Días': [moment().subtract(6, 'days'), moment()],
           'Últimos 30 Días': [moment().subtract(29, 'days'), moment()],
           'Este Mes': [moment().startOf('month'), moment().endOf('month')],
           'Mes Anterior': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, function(start, end) {
        var fechaInicial = start.format('YYYY-MM-DD');
        var fechaFinal = end.format('YYYY-MM-DD');
        
        window.location = "index.php?ruta=reportes&fechaInicial=" + fechaInicial + "&fechaFinal=" + fechaFinal;
    });

    // 3. Limpiar filtro de fechas
    $("#btnLimpiarFiltroFechas").click(function(){
        window.location = "index.php?ruta=reportes";
    });

    // 4. Exportar a Excel
    $("#btnExportarExcelReporte").click(function(){
        var fi = fInit || '';
        var ff = fEnd || '';
        window.open("vistas/modulos/descargar-reporte.php?reporte=ventas&fechaInicial=" + fi + "&fechaFinal=" + ff, "_blank");
    });

    // 5. GRÁFICO DE VENTAS DIARIAS (Línea)
    const ctxVentas = document.getElementById('graficoVentasDias').getContext('2d');
    new Chart(ctxVentas, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($fechas); ?>,
            datasets: [{
                label: 'Total de Ventas (S/)',
                data: <?php echo json_encode($totalesDias); ?>,
                borderColor: '#0d6efd',
                backgroundColor: 'rgba(13, 110, 253, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    // 6. GRÁFICO DE PRODUCTOS MÁS VENDIDOS (Dona)
    const ctxProductos = document.getElementById('graficoProductosTop').getContext('2d');
    new Chart(ctxProductos, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($prodNombres); ?>,
            datasets: [{
                data: <?php echo json_encode($prodCantidades); ?>,
                backgroundColor: ['#0d6efd', '#198754', '#ffc107', '#dc3545', '#0dcaf0']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });

});
</script>