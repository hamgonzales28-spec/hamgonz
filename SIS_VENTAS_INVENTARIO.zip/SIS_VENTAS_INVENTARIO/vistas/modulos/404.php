<div class="text-center py-5">
    <h1 class="display-1 fw-bold text-danger">404</h1>
    <h3 class="fw-bold">Página no encontrada</h3>
    <p class="text-muted">La ruta solicitada no existe dentro del sistema.</p>
    <a href="dashboard" class="btn btn-primary mt-2"><i class="fa-solid fa-house me-2"></i> Volver al Dashboard</a>
</div>