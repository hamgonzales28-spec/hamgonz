<?php
require_once __DIR__ . "/../../controladores/facturacion.controlador.php";
$cfg = ControladorFacturacion::ctrConfig();
ControladorFacturacion::ctrGuardarConfig();
$cfg = ControladorFacturacion::ctrConfig();
$facturacionError = $cfg['__error'] ?? '';
?>
<style>
.sunat-hero{background:linear-gradient(135deg,#0f172a,#1d4ed8);color:#fff;border-radius:20px;padding:24px;box-shadow:0 16px 40px rgba(15,23,42,.16)}
.sunat-card{border:0;border-radius:18px;box-shadow:0 8px 28px rgba(15,23,42,.08)}
.sunat-status{display:inline-flex;align-items:center;gap:8px;border-radius:999px;padding:8px 14px;font-weight:700;background:rgba(255,255,255,.14)}
</style>
<div class="container-fluid py-2">
  <?php if ($facturacionError): ?>
    <div class="alert alert-danger border-0 shadow-sm mb-4">
      <div class="d-flex align-items-start gap-3">
        <i class="fa-solid fa-triangle-exclamation fa-xl mt-1"></i>
        <div>
          <div class="fw-bold mb-1">Facturación SUNAT no está instalada</div>
          <div class="small"><?= htmlspecialchars($facturacionError, ENT_QUOTES, 'UTF-8') ?></div>
          <div class="small mt-2"><b>Instalación:</b> ejecuta manualmente <code>database/sunat.sql</code> desde phpMyAdmin.</div>
        </div>
      </div>
    </div>
  <?php endif; ?>
  <div class="sunat-hero mb-4 d-flex flex-wrap justify-content-between align-items-center gap-3">
    <div><div class="small text-uppercase opacity-75 fw-bold">Emisión directa</div><h2 class="fw-bold mb-1">Facturación electrónica SUNAT</h2><div class="opacity-75">SEE – Del Contribuyente · UBL 2.1 · Firma digital · SOAP</div></div>
    <div class="sunat-status"><i class="fa-solid fa-circle-check"></i><?= !empty($cfg['activo'])?'Activo':'Pendiente de configuración' ?></div>
  </div>
  <form method="post">
    <div class="row g-4">
      <div class="col-lg-7">
        <div class="card sunat-card"><div class="card-body p-4">
          <h5 class="fw-bold mb-3"><i class="fa-solid fa-building me-2 text-primary"></i>Datos del emisor</h5>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label fw-semibold">RUC</label><input name="ruc" class="form-control" maxlength="11" value="<?=htmlspecialchars($cfg['ruc']??'')?>" required></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Razón social</label><input name="razon_social" class="form-control" value="<?=htmlspecialchars($cfg['razon_social']??'')?>" required></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Nombre comercial</label><input name="nombre_comercial" class="form-control" value="<?=htmlspecialchars($cfg['nombre_comercial']??'')?>"></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Ubigeo</label><input name="ubigeo" class="form-control" maxlength="6" value="<?=htmlspecialchars($cfg['ubigeo']??'')?>" placeholder="150101"></div>
            <div class="col-12"><label class="form-label fw-semibold">Dirección fiscal</label><input name="direccion" class="form-control" value="<?=htmlspecialchars($cfg['direccion']??'')?>"></div>
            <div class="col-md-4"><label class="form-label">Departamento</label><input name="departamento" class="form-control" value="<?=htmlspecialchars($cfg['departamento']??'')?>"></div>
            <div class="col-md-4"><label class="form-label">Provincia</label><input name="provincia" class="form-control" value="<?=htmlspecialchars($cfg['provincia']??'')?>"></div>
            <div class="col-md-4"><label class="form-label">Distrito</label><input name="distrito" class="form-control" value="<?=htmlspecialchars($cfg['distrito']??'')?>"></div>
          </div>
        </div></div>
      </div>
      <div class="col-lg-5">
        <div class="card sunat-card"><div class="card-body p-4">
          <h5 class="fw-bold mb-3"><i class="fa-solid fa-shield-halved me-2 text-success"></i>Acceso y certificado</h5>
          <div class="alert alert-warning small"><b>Importante:</b> el certificado digital debe estar instalado en el servidor. No subas aquí archivos sensibles a un hosting sin HTTPS y control de permisos.</div>
          <label class="form-label fw-semibold">Usuario SOL</label><input name="sol_usuario" class="form-control mb-3" value="<?=htmlspecialchars($cfg['sol_usuario']??'')?>">
          <label class="form-label fw-semibold">Clave SOL</label><input type="password" name="sol_clave" class="form-control mb-3" value="<?=htmlspecialchars($cfg['sol_clave']??'')?>">
          <label class="form-label fw-semibold">Ruta del certificado (.pfx/.p12/.pem)</label><input name="certificado_path" class="form-control mb-3" placeholder="C:\\certificados\\mi-certificado.pfx" value="<?=htmlspecialchars($cfg['certificado_path']??'')?>">
          <label class="form-label fw-semibold">Contraseña del certificado</label><input type="password" name="certificado_clave" class="form-control" value="<?=htmlspecialchars($cfg['certificado_clave']??'')?>">
        </div></div>
      </div>
      <div class="col-12">
        <div class="card sunat-card"><div class="card-body p-4">
          <div class="row g-3 align-items-end">
            <div class="col-md-3"><label class="form-label fw-semibold">Ambiente</label><select name="ambiente" class="form-select"><option value="beta" <?=($cfg['ambiente']??'beta')==='beta'?'selected':''?>>Beta / pruebas</option><option value="produccion" <?=($cfg['ambiente']??'')==='produccion'?'selected':''?>>Producción</option></select></div>
            <div class="col-md-3"><label class="form-label fw-semibold">Serie factura</label><input name="serie_factura" class="form-control" maxlength="4" value="<?=htmlspecialchars($cfg['serie_factura']??'F001')?>"></div>
            <div class="col-md-3"><label class="form-label fw-semibold">Serie boleta</label><input name="serie_boleta" class="form-control" maxlength="4" value="<?=htmlspecialchars($cfg['serie_boleta']??'B001')?>"></div>
            <div class="col-md-3"><label class="form-label fw-semibold">IGV (%)</label><input type="number" step="0.01" name="igv" class="form-control" value="<?=htmlspecialchars($cfg['igv']??'18')?>"></div>
          </div>
          <hr><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="activo" id="sunatActivo" <?=!empty($cfg['activo'])?'checked':''?>><label class="form-check-label fw-bold" for="sunatActivo">Activar emisión electrónica automática para Factura y Boleta</label></div>
          <button class="btn btn-primary btn-lg mt-4" name="guardarSunat" value="1"><i class="fa-solid fa-floppy-disk me-2"></i>Guardar configuración SUNAT</button>
        </div></div>
      </div>
    </div>
  </form>
</div>
