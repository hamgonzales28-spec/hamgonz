<?php

require_once "modelos/caja.modelo.php";
require_once "controladores/caja.controlador.php";

$idUsuario = isset($_SESSION["id"]) ? $_SESSION["id"] : 1;
$cajaAbierta = ModeloCaja::mdlObtenerCajaAbierta($idUsuario);

if ($cajaAbierta) {
    $ventasEfectivo = ModeloCaja::mdlObtenerVentasEfectivo($cajaAbierta["fecha_apertura"], $idUsuario);
    $comprasEfectivo = ModeloCaja::mdlObtenerComprasEfectivo($cajaAbierta["fecha_apertura"]);
    $montoEsperado = ($cajaAbierta["monto_inicial"] + $ventasEfectivo) - $comprasEfectivo;
}
?>

<div class="content-wrapper p-3">

    <section class="content-header mb-3">
        <div class="container-fluid">
            <h1><i class="fa-solid fa-cash-register me-2"></i>Control de Caja Chica</h1>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">

            <?php if (!$cajaAbierta): ?>
                
                <!-- ESTADO: CAJA CERRADA (FORMULARIO APERTURA) -->
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card card-primary shadow-sm">
                            <div class="card-header bg-primary text-white">
                                <h5 class="card-title mb-0"><i class="fa-solid fa-lock me-2"></i>Apertura de Caja</h5>
                            </div>
                            <form method="post">
                                <div class="card-body">
                                    <p class="text-muted">No tienes ninguna caja abierta actualmente. Ingrese el monto inicial para comenzar el turno.</p>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Monto Inicial en Efectivo (S/):</label>
                                        <input type="number" step="0.01" min="0" class="form-control form-control-lg" name="montoInicial" placeholder="0.00" required autofocus>
                                    </div>
                                </div>
                                <div class="card-footer text-end">
                                    <button type="submit" class="btn btn-success btn-lg"><i class="fa-solid fa-key me-2"></i>Abrir Caja</button>
                                </div>
                                <?php
                                $abrirCaja = new ControladorCaja();
                                $abrirCaja->ctrAbrirCaja();
                                ?>
                            </form>
                        </div>
                    </div>
                </div>

            <?php else: ?>

                <!-- ESTADO: CAJA ABIERTA (PANEL DE MONITOREO Y ARQUEO) -->
                <div class="row">
                    <!-- Tarjeta Monto Inicial -->
                    <div class="col-md-3 mb-3">
                        <div class="card bg-info text-white shadow-sm h-100">
                            <div class="card-body">
                                <h6 class="card-title text-white-50">Monto Inicial (Base)</h6>
                                <h2 class="fw-bold mb-0">S/ <?php echo number_format($cajaAbierta["monto_inicial"], 2); ?></h2>
                            </div>
                        </div>
                    </div>

                    <!-- Tarjeta Ventas Efectivo -->
                    <div class="col-md-3 mb-3">
                        <div class="card bg-success text-white shadow-sm h-100">
                            <div class="card-body">
                                <h6 class="card-title text-white-50">(+) Ventas Efectivo Turno</h6>
                                <h2 class="fw-bold mb-0">S/ <?php echo number_format($ventasEfectivo, 2); ?></h2>
                            </div>
                        </div>
                    </div>

                    <!-- Tarjeta Compras Efectivo -->
                    <div class="col-md-3 mb-3">
                        <div class="card bg-danger text-white shadow-sm h-100">
                            <div class="card-body">
                                <h6 class="card-title text-white-50">(-) Compras Efectivo Turno</h6>
                                <h2 class="fw-bold mb-0">S/ <?php echo number_format($comprasEfectivo, 2); ?></h2>
                            </div>
                        </div>
                    </div>

                    <!-- Tarjeta Esperado en Gaveta -->
                    <div class="col-md-3 mb-3">
                        <div class="card bg-dark text-white shadow-sm h-100">
                            <div class="card-body">
                                <h6 class="card-title text-white-50">Total Esperado en Caja</h6>
                                <h2 class="fw-bold mb-0">S/ <?php echo number_format($montoEsperado, 2); ?></h2>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- FORMULARIO DE ARQUEO Y CIERRE -->
                <div class="card shadow-sm mt-3">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0"><i class="fa-solid fa-calculator me-2"></i>Arqueo y Cierre de Caja</h5>
                    </div>
                    <form method="post">
                        <div class="card-body">
                            <input type="hidden" name="idCaja" value="<?php echo $cajaAbierta["id"]; ?>">
                            <input type="hidden" name="montoInicialOculto" value="<?php echo $cajaAbierta["monto_inicial"]; ?>">
                            <input type="hidden" name="ventasEfectivoOculto" value="<?php echo $ventasEfectivo; ?>">
                            <input type="hidden" name="comprasEfectivoOculto" value="<?php echo $comprasEfectivo; ?>">

                            <div class="row align-items-center">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold">Efectivo Real Físico Contado (S/):</label>
                                    <input type="number" step="0.01" min="0" class="form-control form-control-lg" name="montoReal" id="montoReal" placeholder="Ingrese el dinero total contado" required>
                                </div>
                                <div class="col-md-6 mb-3 text-center">
                                    <small class="text-muted d-block mb-1">Aperturado el: <?php echo date("d/m/Y H:i", strtotime($cajaAbierta["fecha_apertura"])); ?></small>
                                    <button type="submit" class="btn btn-danger btn-lg"><i class="fa-solid fa-box-archive me-2"></i>Realizar Arqueo y Cerrar Caja</button>
                                </div>
                            </div>
                        </div>
                        <?php
                        $cerrarCaja = new ControladorCaja();
                        $cerrarCaja->ctrCerrarCaja();
                        ?>
                    </form>
                </div>

            <?php endif; ?>

        </div>
    </section>

</div>