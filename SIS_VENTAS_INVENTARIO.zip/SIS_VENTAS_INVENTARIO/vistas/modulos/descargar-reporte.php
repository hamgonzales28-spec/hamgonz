<?php

// Calculamos la ruta raíz del proyecto de forma absoluta e infalible
$raiz = dirname(dirname(dirname(__FILE__))); 

// Requerimos los controladores y modelos usando la ruta absoluta
if (file_exists($raiz . "/controladores/ventas.controlador.php")) {
    require_once $raiz . "/controladores/ventas.controlador.php";
    require_once $raiz . "/modelos/ventas.modelo.php";
}

if (file_exists($raiz . "/controladores/usuarios.controlador.php")) {
    require_once $raiz . "/controladores/usuarios.controlador.php";
    require_once $raiz . "/modelos/usuarios.modelo.php";
}

if (file_exists($raiz . "/controladores/clientes.controlador.php")) {
    require_once $raiz . "/controladores/clientes.controlador.php";
    require_once $raiz . "/modelos/clientes.modelo.php";
}

if (isset($_GET["reporte"])) {

    if ($_GET["reporte"] == "ventas") {

        $fechaInicial = isset($_GET["fechaInicial"]) && $_GET["fechaInicial"] != "" ? $_GET["fechaInicial"] : null;
        $fechaFinal = isset($_GET["fechaFinal"]) && $_GET["fechaFinal"] != "" ? $_GET["fechaFinal"] : null;

        $ventas = ControladorVentas::ctrRangoFechasVentas($fechaInicial, $fechaFinal);

        // Nombre del archivo Excel
        $NombreArchivo = 'Reporte_Ventas_' . date('Y-m-d_H-i-s') . '.xls';

        // Cabeceras HTTP para forzar la descarga en formato Excel
        header('Expires: 0');
        header('Cache-Control: private', false);
        header('Cache-Control: cache, must-revalidate');
        header('Content-Description: File Transfer');
        header('Content-Disposition: attachment; filename="' . $NombreArchivo . '"');
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Transfer-Encoding: binary');

        echo utf8_decode("
        <table border='1'>
            <tr style='background-color:#0d6efd; color:#ffffff; font-weight:bold;'>
                <td style='border:1px solid #000;'>#</td>
                <td style='border:1px solid #000;'>CÓDIGO / COMPROBANTE</td>
                <td style='border:1px solid #000;'>CLIENTE</td>
                <td style='border:1px solid #000;'>VENDEDOR / USUARIO</td>
                <td style='border:1px solid #000;'>FORMA DE PAGO</td>
                <td style='border:1px solid #000;'>NETO</td>
                <td style='border:1px solid #000;'>IMPUESTO</td>
                <td style='border:1px solid #000;'>TOTAL</td>
                <td style='border:1px solid #000;'>FECHA</td>
            </tr>");

        $itemNo = 1;

        if (is_array($ventas)) {
            foreach ($ventas as $key => $value) {

                // 1. CÓDIGO
                $codigoVenta = $value["codigo"] ?? $value["comprobante"] ?? $value["id"] ?? "N/A";

                // 2. CLIENTE
                $clienteNombre = "Cliente General";
                if (class_exists("ControladorClientes") && isset($value["id_cliente"]) && !empty($value["id_cliente"])) {
                    $respuestaCliente = ControladorClientes::ctrMostrarClientes("id", $value["id_cliente"]);
                    if (is_array($respuestaCliente) && isset($respuestaCliente["nombre"])) {
                        $clienteNombre = $respuestaCliente["nombre"];
                    }
                } elseif (isset($value["cliente"])) {
                    $clienteNombre = $value["cliente"];
                }

                // 3. VENDEDOR / USUARIO
                $vendedorNombre = "Administrador";
                $idUser = $value["id_vendedor"] ?? $value["id_usuario"] ?? null;

                if (class_exists("ControladorUsuarios") && !empty($idUser)) {
                    $respuestaUsuario = ControladorUsuarios::ctrMostrarUsuarios("id", $idUser);
                    if (is_array($respuestaUsuario) && isset($respuestaUsuario["nombre"])) {
                        $vendedorNombre = $respuestaUsuario["nombre"];
                    }
                } elseif (isset($value["vendedor"])) {
                    $vendedorNombre = $value["vendedor"];
                }

                // 4. METRICAS
                $metodoPago = $value["metodo_pago"] ?? $value["forma_pago"] ?? "Efectivo";
                $neto       = number_format(($value["neto"] ?? 0), 2);
                $impuesto   = number_format(($value["impuesto"] ?? 0), 2);
                $total      = number_format(($value["total"] ?? 0), 2);
                $fecha      = isset($value["fecha"]) ? date("d/m/Y H:i:s", strtotime($value["fecha"])) : "N/A";

                echo utf8_decode("
                <tr>
                    <td style='border:1px solid #eee;'>{$itemNo}</td>
                    <td style='border:1px solid #eee;'>{$codigoVenta}</td>
                    <td style='border:1px solid #eee;'>{$clienteNombre}</td>
                    <td style='border:1px solid #eee;'>{$vendedorNombre}</td>
                    <td style='border:1px solid #eee;'>{$metodoPago}</td>
                    <td style='border:1px solid #eee;'>S/ {$neto}</td>
                    <td style='border:1px solid #eee;'>S/ {$impuesto}</td>
                    <td style='border:1px solid #eee;'>S/ {$total}</td>
                    <td style='border:1px solid #eee;'>{$fecha}</td>
                </tr>");

                $itemNo++;
            }
        }

        echo "</table>";
    }
}
?>