<?php
require_once "modelos/caja.modelo.php";
require_once "controladores/caja.controlador.php";
require_once "modelos/clientes.modelo.php";
require_once "controladores/clientes.controlador.php";
require_once "modelos/productos.modelo.php";
require_once "controladores/productos.controlador.php";

$idUsuario = isset($_SESSION["id"]) ? $_SESSION["id"] : 1;
$cajaAbierta = ModeloCaja::mdlObtenerCajaAbierta($idUsuario);

if (!$cajaAbierta) {
    echo '<div class="content-wrapper p-4">
        <div class="alert alert-warning text-center shadow-sm p-4" role="alert">
            <h3 class="alert-heading fw-bold"><i class="fa-solid fa-triangle-exclamation me-2"></i>¡Caja Chica Cerrada!</h3>
            <p class="fs-5 mb-3">Para poder realizar ventas en el sistema, primero debes realizar la <strong>Apertura de Caja</strong>.</p>
            <hr>
            <a href="caja" class="btn btn-primary btn-lg mt-2">
                <i class="fa-solid fa-cash-register me-2"></i>Ir a Abrir Caja Chica
            </a>
        </div>
    </div>';
    return;
}
?>

<!-- Estilos para garantizar que todo se mantenga alineado y compacto -->
<style>
    .pos-card-body {
        max-height: 380px;
        overflow-y: auto;
    }
    .table-pos th, .table-pos td {
        vertical-align: middle;
        padding: 0.4rem 0.5rem;
    }
    .catalogo-pos-wrapper {
        overflow-x: auto;
        width: 100%;
    }
    .tablaVentasPOS {
        min-width: 620px;
        table-layout: auto;
    }
    .tablaVentasPOS td:last-child,
    .tablaVentasPOS th:last-child {
        min-width: 112px;
        white-space: nowrap;
    }
    .btnAgregarProducto {
        display: inline-block !important;
        visibility: visible !important;
        white-space: nowrap;
    }
    .catalogo-pos-wrapper .dataTables_wrapper {
        width: 100%;
    }
    .catalogo-pos-wrapper .dataTables_filter input {
        max-width: 180px;
    }
    @media (min-width: 1200px) {
        .catalogo-pos-wrapper {
            overflow-x: hidden;
        }
        .tablaVentasPOS {
            min-width: 100%;
            font-size: 0.86rem;
        }
        .tablaVentasPOS th,
        .tablaVentasPOS td {
            padding-left: 0.35rem;
            padding-right: 0.35rem;
        }
    }
</style>

<div class="content-wrapper p-3">

    <!-- CABECERA -->
    <section class="content-header mb-2">
        <div class="container-fluid">
            <h2 class="m-0 fw-bold"><i class="fa-solid fa-cart-shopping me-2"></i>Punto de Venta (POS)</h2>
        </div>
    </section>

    <!-- SECCIÓN PRINCIPAL -->
    <section class="content">
        <div class="container-fluid">
            
            <div class="row g-3">

                <!-- COLUMNA IZQUIERDA: CARRITO Y RESUMEN DE VENTA -->
                <div class="col-lg-6">
                    <form method="post" class="formularioVenta d-flex flex-column h-100">
                        
                        <!-- CARD 1: DETALLE DE LA VENTA / CARRITO -->
                        <div class="card shadow-sm mb-3">
                            <div class="card-header bg-white py-2">
                                <h6 class="card-title m-0 fw-bold"><i class="fa-solid fa-receipt me-2"></i>Detalle de la Venta</h6>
                            </div>
                            <div class="card-body p-3">

                                <!-- SELECTOR DE CLIENTE -->
                                <div class="mb-3">
                                    <label class="form-label fw-bold small mb-1"><i class="fa-solid fa-user me-1"></i> Cliente:</label>
                                    <div class="input-group">
                                        <input type="text" 
                                               class="form-control form-control-sm" 
                                               id="inputBuscarCliente" 
                                               list="listaClientesPOS" 
                                               placeholder="Buscar por DNI o Nombre..."
                                               autocomplete="off" 
                                               required>
                                        
                                        <input type="hidden" name="seleccionarCliente" id="seleccionarCliente" value="1">

                                        <datalist id="listaClientesPOS">
                                            <option data-id="1" value="Público General"></option>
                                            <?php
                                            $clientes = ControladorClientes::ctrMostrarClientes(null, null);

                                            if (!empty($clientes)) {
                                                foreach ($clientes as $key => $value) {
                                                    echo '<option data-id="' . $value["id"] . '" value="' . $value["documento"] . ' - ' . $value["nombre"] . '"></option>';
                                                }
                                            }
                                            ?>
                                        </datalist>

                                        <button class="btn btn-outline-primary btn-sm" type="button" data-bs-toggle="modal" data-bs-target="#modalAgregarClientePOS" title="Nuevo Cliente">
                                            <i class="fa-solid fa-user-plus"></i>
                                        </button>
                                    </div>
                                </div>

                                <!-- TABLA DE PRODUCTOS EN EL CARRITO -->
                                <div class="table-responsive pos-card-body border rounded">
                                    <table class="table table-bordered table-hover table-pos mb-0" id="tablaCarritoPOS">
                                        <thead class="table-light sticky-top">
                                            <tr>
                                                <th>Producto</th>
                                                <th style="width: 90px;">Cant.</th>
                                                <th style="width: 100px;">Precio</th>
                                                <th style="width: 100px;">Subtotal</th>
                                                <th style="width: 40px;" class="text-center"><i class="fa-solid fa-trash"></i></th>
                                            </tr>
                                        </thead>
                                        <tbody class="nuevoProducto">
                                            <!-- Filas agregadas dinámicamente por JS -->
                                        </tbody>
                                    </table>
                                </div>

                                <!-- ENTRADAS OCULTAS PARA ENVÍO DE DATOS -->
                                <input type="hidden" id="listaProductos" name="listaProductos">
                                <input type="hidden" id="listaProductosJSON" name="listaProductosJSON">

                            </div>
                        </div>

                        <!-- CARD 2: RESUMEN DE PAGO -->
                        <div class="card shadow-sm border-primary">
                            <div class="card-header bg-primary text-white py-2">
                                <h6 class="card-title m-0"><i class="fa-solid fa-calculator me-2"></i>Resumen de Pago</h6>
                            </div>
                            <div class="card-body p-3">
                                <div class="row align-items-center">
                                    
                                    <!-- TOTAL A PAGAR -->
                                    <div class="col-md-5 mb-3 mb-md-0">
                                        <div class="p-3 bg-light rounded text-center border">
                                            <span class="text-muted text-uppercase fw-bold d-block small">Total a Pagar</span>
                                            <h2 class="fw-bold text-success my-1">S/ <span id="totalVentaTexto">0.00</span></h2>
                                            
                                            <input type="hidden" name="nuevoTotalVenta" id="nuevoTotalVenta" value="0.00">
                                            <input type="hidden" name="nuevoSubtotal" id="nuevoSubtotal" value="0.00">
                                        </div>
                                    </div>

                                    <!-- MÉTODOS Y DETALLES DE PAGO -->
                                    <div class="col-md-7">
                                        <div class="row g-2 mb-2">
                                            <div class="col-6">
                                                <label class="form-label fw-bold small mb-1">Comprobante:</label>
                                                <select class="form-select form-select-sm" name="nuevoTipoComprobante" id="nuevoTipoComprobante">
                                                    <option value="Ticket">Ticket</option>
                                                    <option value="Boleta">Boleta</option>
                                                    <option value="Factura">Factura</option>
                                                </select>
                                            </div>
                                            <div class="col-6">
                                                <label class="form-label fw-bold small mb-1">Método Pago:</label>
                                                <select class="form-select form-select-sm" name="nuevoMetodoPago" id="nuevoMetodoPago" required>
                                                    <option value="Efectivo">Efectivo</option>
                                                    <option value="Yape/Plin">Yape / Plin</option>
                                                    <option value="Tarjeta">Tarjeta Débito/Crédito</option>
                                                    <option value="Transferencia">Transferencia</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row g-2 mb-2">
                                            <div class="col-12">
                                                <label class="form-label fw-bold small mb-1">Descuento (S/):</label>
                                                <input type="number" step="0.01" min="0" class="form-control form-control-sm" name="nuevoDescuentoVenta" id="nuevoDescuentoVenta" value="0.00">
                                            </div>
                                        </div>

                                        <div id="cajaEfectivo">
                                            <div class="row g-2 mb-2">
                                                <div class="col-6">
                                                    <label class="form-label fw-bold small mb-1">Paga con (S/):</label>
                                                    <input type="number" step="0.01" class="form-control form-control-sm" name="nuevoPagueCon" id="nuevoPagueCon" placeholder="0.00">
                                                </div>
                                                <div class="col-6">
                                                    <label class="form-label fw-bold small mb-1">Vuelto (S/):</label>
                                                    <input type="number" step="0.01" class="form-control form-control-sm bg-warning text-dark fw-bold" name="nuevoVuelto" id="nuevoVuelto" value="0.00" readonly>
                                                </div>
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-success fw-bold w-100 mt-2">
                                            <i class="fa-solid fa-print me-2"></i>Procesar Venta
                                        </button>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <?php
                        $crearVenta = new ControladorVentas();
                        $crearVenta->ctrCrearVenta();
                        ?>
                    </form>
                </div>

                <!-- COLUMNA DERECHA: CATÁLOGO DE PRODUCTOS -->
                <div class="col-lg-6">
                    <div class="card card-outline card-primary shadow-sm h-100">
                        <div class="card-header bg-dark text-white py-2">
                            <div class="d-flex justify-content-between align-items-center gap-2"><h6 class="card-title m-0 fw-bold"><i class="fa-solid fa-boxes-stacked me-2"></i>Catálogo de Productos</h6><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalScannerCodigoVenta"><i class="fa-solid fa-barcode me-1"></i> Escanear código de barras</button></div>
                        </div>
                        <div class="card-body p-2">
                            <div class="catalogo-pos-wrapper">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped tablaVentasPOS w-100">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Código</th>
                                        <th>Descripción</th>
                                        <th>Presentación</th>
                                        <th>Stock</th>
                                        <th>Acción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $item = null;
                                    $valor = null;
                                    $productos = ControladorProductos::ctrMostrarProductos($item, $valor);

                                    if (!empty($productos)) {
                                        foreach ($productos as $key => $value) {

                                            $badgeStock = ($value["stock"] <= 10) ? "bg-danger" : "bg-success";
                                            $precioVenta = $value["precio_venta"] ?? $value["precio"] ?? 0;
                                            $unidadMedida = $value["unidad_medida"] ?? "Unidad";

                                            $codigo = htmlspecialchars((string) $value["codigo"], ENT_QUOTES, "UTF-8");
                                            $codigoBarras = htmlspecialchars((string) ($value["codigo_barras"] ?? ""), ENT_QUOTES, "UTF-8");
                                            $descripcion = htmlspecialchars((string) $value["descripcion"], ENT_QUOTES, "UTF-8");
                                            $unidadMedidaHtml = htmlspecialchars((string) $unidadMedida, ENT_QUOTES, "UTF-8");
                                            echo '<tr>
                                                <td>'.($key+1).'</td>
                                                <td class="fw-bold codigoProducto"><div>'.$codigo.'</div>'.($codigoBarras !== '' ? '<small class="text-muted codigoBarrasProducto"><i class="fa-solid fa-barcode me-1"></i>'.$codigoBarras.'</small>' : '').'</td>
                                                <td class="nombreProducto">'.$descripcion.'</td>
                                                <td><span class="badge bg-light text-primary border">'.$unidadMedidaHtml.'</span></td>
                                                <td><span class="badge '.$badgeStock.' fs-6">'.(int) $value["stock"].'</span></td>
                                                <td>
                                                    <button type="button" class="btn btn-primary btn-sm btnAgregarProducto" data-id-producto="'.(int) $value["id"].'" data-precio-venta="'.htmlspecialchars((string) $precioVenta, ENT_QUOTES, "UTF-8").'" data-unidad-medida="'.$unidadMedidaHtml.'">
                                                        <i class="fa-solid fa-plus me-1"></i>Agregar
                                                    </button>
                                                </td>
                                            </tr>';
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </section>
</div>

<!-- MODAL AGREGAR CLIENTE DESDE POS -->
<div class="modal fade" id="modalAgregarClientePOS" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="formModalCliente">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title fs-6 fw-bold"><i class="fa-solid fa-user-plus me-2"></i>Nuevo Cliente Rápido</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-2">
                        <label class="form-label fw-bold small">DNI / RUC *</label>
                        <input type="text" class="form-control form-control-sm" name="nuevoDocumento" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label fw-bold small">Nombre Completo / Razón Social *</label>
                        <input type="text" class="form-control form-control-sm" name="nuevoNombre" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label fw-bold small">Teléfono</label>
                        <input type="text" class="form-control form-control-sm" name="nuevoTelefono">
                    </div>
                    <div class="mb-2">
                        <label class="form-label fw-bold small">Email</label>
                        <input type="email" class="form-control form-control-sm" name="nuevoEmail">
                    </div>
                    <div class="mb-2">
                        <label class="form-label fw-bold small">Dirección</label>
                        <textarea class="form-control form-control-sm" name="nuevaDireccion" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer py-2">
                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-sm btn-primary"><i class="fa-solid fa-floppy-disk me-1"></i> Guardar Cliente</button>
                </div>
                <?php
                $crearCliente = new ControladorClientes();
                $crearCliente->ctrCrearCliente();
                ?>
            </form>
        </div>
    </div>
</div>

<!-- MODAL LECTOR QR -->
<div class="modal fade" id="modalScannerCodigoVenta" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content">
<div class="modal-header bg-success text-white"><h5 class="modal-title"><i class="fa-solid fa-barcode me-2"></i>Buscar producto por código de barras</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><div id="readerVentasCodigo" class="border rounded overflow-hidden mb-3"></div><div class="input-group"><input type="text" id="codigoBarrasVenta" class="form-control" placeholder="Código de barras leído o escribir código..."><button type="button" class="btn btn-success" id="btnBuscarCodigoBarrasVenta"><i class="fa-solid fa-magnifying-glass"></i></button></div><small class="text-muted d-block mt-2">Compatible con EAN-13, EAN-8, UPC, Code 128, Code 39, ITF y Codabar. La cámara requiere HTTPS o localhost.</small><div id="estadoCodigoBarrasVenta" class="small mt-2"></div></div>
</div></div></div>

<!-- LÓGICA JAVASCRIPT -->
<script>
$(document).ready(function() {

    // Capturar el ID del cliente seleccionado desde el Datalist
    $(document).on("input", "#inputBuscarCliente", function() {
        var val = $(this).val();
        var idEncontrado = "1"; // Por defecto '1' (Público General)

        $('#listaClientesPOS option').each(function() {
            if ($(this).val() === val) {
                idEncontrado = $(this).data('id');
            }
        });

        // Asignar el ID real al input oculto
        $("#seleccionarCliente").val(idEncontrado);
    });

    // 1. Inicializar DataTable en el Catálogo POS (con buscador activo)
    if ($.fn.DataTable.isDataTable('.tablaVentasPOS')) {
        $('.tablaVentasPOS').DataTable().destroy();
    }

    $('.tablaVentasPOS').DataTable({
        "pageLength": 6,
        "lengthChange": false,
        "responsive": false,
        "autoWidth": false,
        "columnDefs": [
            { "orderable": false, "targets": 5 }
        ],
        "language": {
            "sProcessing":     "Procesando...",
            "sZeroRecords":    "No se encontraron resultados",
            "sEmptyTable":     "Sin datos disponibles",
            "sInfo":           "Mostrando _START_ al _END_ de _TOTAL_",
            "sInfoEmpty":      "Mostrando 0 al 0 de 0",
            "sSearch":         "Buscar:",
            "oPaginate": {
                "sNext":     "›",
                "sPrevious": "‹"
            }
        }
    });

    // 2. Agregar producto al carrito (escucha el evento con delegation para soportar la paginación de DataTables)
    $(document).on("click", ".btnAgregarProducto", function(e) {
        e.preventDefault();

        var boton = $(this);
        var tr = boton.closest("tr");
        var descripcion = tr.find(".nombreProducto").text().trim();
        var idProducto = String(boton.data("id-producto") || boton.attr("data-id-producto") || "").trim();
        var precioVenta = parseFloat(boton.data("precio-venta") || boton.attr("data-precio-venta")) || 0.00;
        var unidadMedida = String(boton.data("unidad-medida") || boton.attr("data-unidad-medida") || "Unidad");

        if (!idProducto) {
            Swal.fire({
                icon: "error",
                title: "Producto inválido",
                text: "No se pudo identificar el producto seleccionado. Actualice la página e inténtelo nuevamente."
            });
            return;
        }

        var existe = false;
        $(".nuevoProducto tr").each(function() {
            if ($(this).attr("idProducto") == idProducto) {
                existe = true;
            }
        });

        if (existe) {
            Swal.fire({
                icon: 'warning',
                title: 'Producto ya agregado',
                text: 'Aumente la cantidad directamente en la tabla.',
                confirmButtonText: 'Entendido'
            });
            return;
        }

        var fila = `
            <tr idProducto="${idProducto}" unidadMedida="${unidadMedida}">
                <td class="descripcionProd fw-bold align-middle">${descripcion}<small class="text-muted d-block">(${unidadMedida})</small></td>
                <td>
                    <input type="number" class="form-control form-control-sm cantidadProducto" value="1" min="1">
                </td>
                <td>
                    <input type="number" class="form-control form-control-sm precioProducto" value="${precioVenta.toFixed(2)}" step="0.01">
                </td>
                <td class="fw-bold text-end align-middle subtotalProducto">
                    ${precioVenta.toFixed(2)}
                </td>
                <td class="text-center align-middle">
                    <button type="button" class="btn btn-outline-danger btn-sm quitarProducto border-0">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </td>
            </tr>
        `;

        $(".nuevoProducto").append(fila);
        calcularTotalesPOS();
    });

    // 3. Eliminar producto del carrito
    $(document).on("click", ".quitarProducto", function() {
        $(this).closest("tr").remove();
        calcularTotalesPOS();
    });

    // 4. Recalcular subtotal al modificar precio/cantidad
    $(document).on("change keyup", ".cantidadProducto, .precioProducto", function() {
        var tr = $(this).closest("tr");
        var cant = parseFloat(tr.find(".cantidadProducto").val()) || 1;
        var precio = parseFloat(tr.find(".precioProducto").val()) || 0;
        var subtotal = cant * precio;

        tr.find(".subtotalProducto").text(subtotal.toFixed(2));
        calcularTotalesPOS();
    });

    // 5. Función de Totales y Cambio
    function calcularTotalesPOS() {
        var total = 0;
        $(".subtotalProducto").each(function() {
            total += parseFloat($(this).text()) || 0;
        });

        var descuento = parseFloat($("#nuevoDescuentoVenta").val()) || 0;
        if (descuento < 0) descuento = 0;

        var totalFinal = Math.max(total - descuento, 0);

        $("#totalVentaTexto").text(totalFinal.toFixed(2));
        $("#nuevoTotalVenta").val(totalFinal.toFixed(2));
        $("#nuevoSubtotal").val(total.toFixed(2));

        var pagado = parseFloat($("#nuevoPagueCon").val()) || 0;
        var vuelto = pagado - totalFinal;
        if (vuelto < 0) vuelto = 0;
        $("#nuevoVuelto").val(vuelto.toFixed(2));
    }

    $(document).on("keyup change", "#nuevoPagueCon, #nuevoDescuentoVenta", function() {
        calcularTotalesPOS();
    });

    // El pago en efectivo solo se solicita cuando corresponde.
    function actualizarCamposPago() {
        var esEfectivo = $("#nuevoMetodoPago").val() === "Efectivo";
        $("#cajaEfectivo").toggle(esEfectivo);
        $("#nuevoPagueCon").prop("required", esEfectivo);
        if (!esEfectivo) {
            $("#nuevoPagueCon, #nuevoVuelto").val("0.00");
        }
        calcularTotalesPOS();
    }

    $(document).on("change", "#nuevoMetodoPago", actualizarCamposPago);
    actualizarCamposPago();

    // 6. Validar y procesar envío del formulario de venta
    $(".formularioVenta").submit(function(e) {
        var listaProductos = [];
        var filas = $(".nuevoProducto tr");

        if (filas.length == 0) {
            e.preventDefault();
            Swal.fire({
                icon: 'error',
                title: '¡Carrito vacío!',
                text: 'Debe agregar al menos un producto para procesar la venta.'
            });
            return false;
        }

        var totalVenta = parseFloat($("#nuevoTotalVenta").val()) || 0;
        if ($("#nuevoMetodoPago").val() === "Efectivo" && (parseFloat($("#nuevoPagueCon").val()) || 0) < totalVenta) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Pago insuficiente',
                text: 'El monto recibido no cubre el total de la venta.'
            });
            return false;
        }

        filas.each(function() {
            var id = $(this).attr("idProducto");
            var descripcion = $(this).find(".descripcionProd").text();
            var unidadMedida = $(this).attr("unidadMedida") || "Unidad";
            var cantidad = $(this).find(".cantidadProducto").val();
            var precio = $(this).find(".precioProducto").val();
            var total = $(this).find(".subtotalProducto").text();

            listaProductos.push({
                "id": id,
                "descripcion": descripcion,
                "unidad_medida": unidadMedida,
                "cantidad": cantidad,
                "precio": precio,
                "precio_unitario": precio,
                "total": total,
                "total_item": total
            });
        });

        var jsonString = JSON.stringify(listaProductos);
        $("#listaProductos").val(jsonString);
        $("#listaProductosJSON").val(jsonString);
    });

});

let scannerCodigoVenta=null;
function detenerScannerCodigoVenta(){if(scannerCodigoVenta){scannerCodigoVenta.stop().catch(function(){}).finally(function(){scannerCodigoVenta.clear();scannerCodigoVenta=null;});}}
function buscarYAgregarProductoVenta(codigo){codigo=String(codigo||"").trim();if(!codigo)return;const tabla=$('.tablaVentasPOS').DataTable();tabla.search(codigo).draw();setTimeout(function(){let boton=null;$('.tablaVentasPOS tbody tr').each(function(){const textoCodigo=$(this).find('.codigoProducto').text().trim().toLowerCase(); if(textoCodigo===codigo.toLowerCase() || textoCodigo.indexOf(codigo.toLowerCase())!==-1)boton=$(this).find('.btnAgregarProducto');});if(boton&&boton.length){boton.trigger('click');cerrarModalCodigoVenta();}else $('#estadoCodigoBarrasVenta').html('<span class="text-danger">No se encontró el código.</span>');},100);}
function iniciarScannerCodigoVenta(){if(typeof Html5Qrcode==="undefined"){return;}if(scannerCodigoVenta)return;scannerCodigoVenta=new Html5Qrcode("readerVentasCodigo");const formatos=[Html5QrcodeSupportedFormats.CODE_128,Html5QrcodeSupportedFormats.CODE_39,Html5QrcodeSupportedFormats.EAN_13,Html5QrcodeSupportedFormats.EAN_8,Html5QrcodeSupportedFormats.UPC_A,Html5QrcodeSupportedFormats.UPC_E,Html5QrcodeSupportedFormats.ITF,Html5QrcodeSupportedFormats.CODABAR];scannerCodigoVenta.start({facingMode:"environment"},{fps:10,qrbox:{width:320,height:120},formatsToSupport:formatos},function(t){$('#codigoBarrasVenta').val(t);buscarYAgregarProductoVenta(t);},function(){}).catch(function(){$('#estadoCodigoBarrasVenta').html('<span class="text-warning">No se pudo abrir la cámara. Usa HTTPS y concede permiso.</span>');});}
function cerrarModalCodigoVenta(){detenerScannerCodigoVenta();const m=bootstrap.Modal.getInstance(document.getElementById('modalScannerCodigoVenta'));if(m)m.hide();}
$(document).on('shown.bs.modal','#modalScannerCodigoVenta',function(){iniciarScannerCodigoVenta();});
$(document).on('hidden.bs.modal','#modalScannerCodigoVenta',function(){detenerScannerCodigoVenta();});
$(document).on('click','#btnBuscarCodigoBarrasVenta',function(){buscarYAgregarProductoVenta($('#codigoBarrasVenta').val());});
$(document).on('keydown','#codigoBarrasVenta',function(e){if(e.key==='Enter'){e.preventDefault();buscarYAgregarProductoVenta($(this).val());}});
</script>