<?php
/*=============================================
CARGA SEGURA DE MODELOS Y CONTROLADORES
=============================================*/
if (!class_exists("ModeloClientes")) {
    if (file_exists("modelos/clientes.modelo.php")) {
        require_once "modelos/clientes.modelo.php";
    }
}
if (!class_exists("ControladorClientes")) {
    if (file_exists("controladores/clientes.controlador.php")) {
        require_once "controladores/clientes.controlador.php";
    }
}

if (!class_exists("ModeloVentas")) {
    if (file_exists("modelos/ventas.modelo.php")) {
        require_once "modelos/ventas.modelo.php";
    }
}
if (!class_exists("ControladorVentas")) {
    if (file_exists("controladores/ventas.controlador.php")) {
        require_once "controladores/ventas.controlador.php";
    }
}

if (!class_exists("ModeloProductos")) {
    if (file_exists("modelos/productos.modelo.php")) {
        require_once "modelos/productos.modelo.php";
    }
}
if (!class_exists("ControladorProductos")) {
    if (file_exists("controladores/productos.controlador.php")) {
        require_once "controladores/productos.controlador.php";
    }
}

if (!class_exists("ModeloCategorias")) {
    if (file_exists("modelos/categorias.modelo.php")) {
        require_once "modelos/categorias.modelo.php";
    }
}
if (!class_exists("ControladorCategorias")) {
    if (file_exists("controladores/categorias.controlador.php")) {
        require_once "controladores/categorias.controlador.php";
    }
}

if (!class_exists("ModeloCompras")) {
    if (file_exists("modelos/compras.modelo.php")) {
        require_once "modelos/compras.modelo.php";
    }
}
if (!class_exists("ControladorCompras")) {
    if (file_exists("controladores/compras.controlador.php")) {
        require_once "controladores/compras.controlador.php";
    }
}

// Obtención de datos generales
$ventas = class_exists("ControladorVentas") ? ControladorVentas::ctrMostrarVentas(null, null) : [];
$productos = class_exists("ControladorProductos") ? ControladorProductos::ctrMostrarProductos(null, null) : [];
$clientes = class_exists("ControladorClientes") ? ControladorClientes::ctrMostrarClientes(null, null) : [];
$categorias = class_exists("ControladorCategorias") ? ControladorCategorias::ctrMostrarCategorias(null, null) : [];

// Cálculos Financieros
$totalVentasMonto = 0;
if (is_array($ventas)) {
    foreach ($ventas as $v) {
        $totalVentasMonto += isset($v["total"]) ? (float)$v["total"] : 0;
    }
}

$totalComprasMonto = class_exists("ControladorCompras") ? (float)ControladorCompras::ctrSumaTotalCompras() : 0;

// Ganancia Neta y Margen de Rentabilidad
$gananciaNeta = $totalVentasMonto - $totalComprasMonto;
$margenGanancia = ($totalVentasMonto > 0) ? ($gananciaNeta / $totalVentasMonto) * 100 : 0;

$totalProductos = is_array($productos) ? count($productos) : 0;
$totalClientes = is_array($clientes) ? count($clientes) : 0;
$totalCategorias = is_array($categorias) ? count($categorias) : 0;

// Estado de caja chica del día
$idUsuario = isset($_SESSION["id"]) ? $_SESSION["id"] : 1;
$cajaAbierta = class_exists("ModeloCaja") ? ModeloCaja::mdlObtenerCajaAbierta($idUsuario) : null;
$compras = class_exists("ControladorCompras") ? ControladorCompras::ctrMostrarCompras(null, null) : [];
$hoy = date("Y-m-d");
$saldoAperturaCaja = $cajaAbierta ? (float) $cajaAbierta["monto_inicial"] : 0;
$ingresosEfectivoDia = 0;
$egresosEfectivoDia = 0;
$ventasHoy = [];

if (is_array($ventas)) {
    foreach ($ventas as $venta) {
        $fechaVenta = isset($venta["fecha"]) ? date("Y-m-d", strtotime($venta["fecha"])) : null;
        if ($fechaVenta === $hoy) {
            $ventasHoy[] = $venta;
            if (isset($venta["metodo_pago"]) && strtolower(trim($venta["metodo_pago"])) === "efectivo") {
                $ingresosEfectivoDia += (float) ($venta["total"] ?? 0);
            }
        }
    }
}

if (is_array($compras)) {
    foreach ($compras as $compra) {
        $fechaCompra = isset($compra["fecha"]) ? date("Y-m-d", strtotime($compra["fecha"])) : null;
        if ($fechaCompra === $hoy && isset($compra["metodo_pago"]) && strtolower(trim($compra["metodo_pago"])) === "efectivo") {
            $egresosEfectivoDia += (float) ($compra["total"] ?? 0);
        }
    }
}

$saldoEstimadoCaja = $saldoAperturaCaja + $ingresosEfectivoDia - $egresosEfectivoDia;
$estadoCaja = $cajaAbierta ? "Abierta" : "Cerrada";
$claseEstadoCaja = $cajaAbierta ? "bg-success" : "bg-secondary";

$clientesMap = [];
if (is_array($clientes)) {
    foreach ($clientes as $cliente) {
        if (isset($cliente["id"])) {
            $clientesMap[$cliente["id"]] = $cliente["nombre"];
        }
    }
}

$ultimasVentas = [];
if (is_array($ventas)) {
    foreach (array_slice($ventas, 0, 5) as $venta) {
        $clienteId = $venta["id_cliente"] ?? 0;
        $nombreCliente = isset($clientesMap[$clienteId]) ? $clientesMap[$clienteId] : "Cliente #" . $clienteId;
        $codigoComprobante = $venta["codigo_factura"] ?? ($venta["codigo"] ?? ("TKT-" . ($venta["id"] ?? "")));

        $ultimasVentas[] = array(
            "codigo" => $codigoComprobante,
            "cliente" => $nombreCliente,
            "monto" => isset($venta["total"]) ? (float) $venta["total"] : 0,
            "estado" => isset($venta["estado"]) ? ucfirst($venta["estado"]) : "Completada"
        );
    }
}

$metodosPagoHoy = array(
    "Efectivo" => 0,
    "Yape/Plin" => 0,
    "Tarjeta" => 0
);

if (is_array($ventasHoy)) {
    foreach ($ventasHoy as $venta) {
        $metodo = isset($venta["metodo_pago"]) ? strtolower(trim($venta["metodo_pago"])) : "";
        $montoVenta = (float) ($venta["total"] ?? 0);

        if ($metodo === "efectivo") {
            $metodosPagoHoy["Efectivo"] += $montoVenta;
        } elseif ($metodo === "yape" || $metodo === "plin" || $metodo === "yape/plin") {
            $metodosPagoHoy["Yape/Plin"] += $montoVenta;
        } elseif ($metodo === "tarjeta" || $metodo === "debito" || $metodo === "credito") {
            $metodosPagoHoy["Tarjeta"] += $montoVenta;
        }
    }
}

$labelsMetodoPago = array_keys($metodosPagoHoy);
$datosMetodoPago = array_values($metodosPagoHoy);
$coloresMetodoPago = ["#198754", "#f39c12", "#0d6efd"];
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold"><i class="fa-solid fa-chart-pie me-2 text-primary"></i> Dashboard Principal</h3>
</div>

<!-- =============================================
TARJETAS DE RESUMEN FINANCIERO Y GANANCIA NETA
============================================= -->
<div class="row g-3 mb-4">

    <!-- Total Ventas (Ingresos) -->
    <div class="col-xl-3 col-md-6">
        <div class="card border-0 shadow-sm rounded-3 bg-success text-white h-100">
            <div class="card-body p-4 d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="text-white-50 fw-normal mb-1">Total Ventas (Ingresos)</h6>
                    <h3 class="fw-bold mb-0">S/ <?php echo number_format($totalVentasMonto, 2); ?></h3>
                </div>
                <div class="fs-1 text-white-50">
                    <i class="fa-solid fa-sack-dollar"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Total Compras (Egresos) -->
    <div class="col-xl-3 col-md-6">
        <div class="card border-0 shadow-sm rounded-3 bg-danger text-white h-100">
            <div class="card-body p-4 d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="text-white-50 fw-normal mb-1">Total Compras (Egresos)</h6>
                    <h3 class="fw-bold mb-0">S/ <?php echo number_format($totalComprasMonto, 2); ?></h3>
                </div>
                <div class="fs-1 text-white-50">
                    <i class="fa-solid fa-truck-ramp-box"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Ganancia / Utilidad Neta -->
    <div class="col-xl-3 col-md-6">
        <?php 
            $bgGananciaCard = ($gananciaNeta >= 0) ? 'bg-primary' : 'bg-danger';
        ?>
        <div class="card border-0 shadow-sm rounded-3 <?php echo $bgGananciaCard; ?> text-white h-100">
            <div class="card-body p-4 d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="text-white-50 fw-normal mb-1">Ganancia / Utilidad Neta</h6>
                    <h3 class="fw-bold mb-0">S/ <?php echo number_format($gananciaNeta, 2); ?></h3>
                </div>
                <div class="fs-1 text-white-50">
                    <i class="fa-solid fa-piggy-bank"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Margen de Rentabilidad -->
    <div class="col-xl-3 col-md-6">
        <div class="card border-0 shadow-sm rounded-3 bg-warning text-dark h-100">
            <div class="card-body p-4 d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="text-dark-50 fw-normal mb-1">Rentabilidad Neta</h6>
                    <h3 class="fw-bold mb-0"><?php echo number_format($margenGanancia, 1); ?> %</h3>
                </div>
                <div class="fs-1 text-dark-50">
                    <i class="fa-solid fa-chart-line"></i>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- =============================================
TARJETAS DE INFORME RÁPIDO (INVENTARIO Y ENTIDADES)
============================================= -->
<div class="row g-3 mb-4">
    
    <!-- Productos -->
    <div class="col-xl-4 col-md-4">
        <div class="card border-0 shadow-sm rounded-3 bg-white text-dark border-start border-4 border-success h-100">
            <div class="card-body p-3 d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted fw-bold small text-uppercase">Productos Registrados</span>
                    <h3 class="fw-bold text-success mb-0 mt-1"><?php echo $totalProductos; ?></h3>
                </div>
                <div class="bg-success bg-opacity-10 p-3 rounded-circle text-success">
                    <i class="fa-solid fa-box fa-2x"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Clientes -->
    <div class="col-xl-4 col-md-4">
        <div class="card border-0 shadow-sm rounded-3 bg-white text-dark border-start border-4 border-warning h-100">
            <div class="card-body p-3 d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted fw-bold small text-uppercase">Clientes Activos</span>
                    <h3 class="fw-bold text-warning mb-0 mt-1"><?php echo $totalClientes; ?></h3>
                </div>
                <div class="bg-warning bg-opacity-10 p-3 rounded-circle text-warning">
                    <i class="fa-solid fa-users fa-2x"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Categorías -->
    <div class="col-xl-4 col-md-4">
        <div class="card border-0 shadow-sm rounded-3 bg-white text-dark border-start border-4 border-info h-100">
            <div class="card-body p-3 d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted fw-bold small text-uppercase">Categorías</span>
                    <h3 class="fw-bold text-info mb-0 mt-1"><?php echo $totalCategorias; ?></h3>
                </div>
                <div class="bg-info bg-opacity-10 p-3 rounded-circle text-info">
                    <i class="fa-solid fa-tags fa-2x"></i>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- =============================================
SECCIÓN DE ALERTAS DE STOCK BAJO Y ACCESOS RÁPIDOS
============================================= -->
<div class="row g-4">
    
    <!-- Tabla Productos con Stock Bajo -->
    <div class="col-lg-8 col-12">
        <div class="card border-0 shadow-sm rounded-3 h-100">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="fw-bold mb-0 text-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i> Productos con Poco Stock (≤ 10)</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Código</th>
                                <th>Producto</th>
                                <th>Stock</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $productosPocoStock = 0;
                            if (is_array($productos)) {
                                foreach ($productos as $p) {
                                    if (isset($p["stock"]) && $p["stock"] <= 10) {
                                        $productosPocoStock++;
                                        echo '<tr>
                                            <td class="ps-4"><span class="badge bg-secondary">'.$p["codigo"].'</span></td>
                                            <td class="fw-bold">'.$p["descripcion"].'</td>
                                            <td><span class="badge bg-danger">'.$p["stock"].' unidades</span></td>
                                            <td><a href="productos" class="btn btn-outline-primary btn-sm"><i class="fa-solid fa-eye me-1"></i> Ir a Productos</a></td>
                                        </tr>';
                                    }
                                }
                            }

                            if ($productosPocoStock == 0) {
                                echo '<tr><td colspan="4" class="text-center py-4 text-muted"><i class="fa-solid fa-check-circle text-success me-1"></i> Todo el inventario tiene stock suficiente.</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Accesos Rápidos -->
    <div class="col-lg-4 col-12">
        <div class="card border-0 shadow-sm rounded-3 h-100">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="fw-bold mb-0"><i class="fa-solid fa-bolt me-2 text-warning"></i> Accesos Rápidos</h5>
            </div>
            <div class="card-body p-3 d-grid gap-2">
                <a href="ventas" class="btn btn-primary py-3 fw-bold text-start rounded-3">
                    <i class="fa-solid fa-cart-plus me-2 fs-5 align-middle"></i> Nueva Venta POS
                </a>
                <a href="compras" class="btn btn-success py-3 fw-bold text-start rounded-3">
                    <i class="fa-solid fa-truck-ramp-box me-2 fs-5 align-middle"></i> Registrar Nueva Compra
                </a>
                <a href="productos" class="btn btn-outline-dark py-3 fw-bold text-start rounded-3">
                    <i class="fa-solid fa-box-open me-2 fs-5 align-middle"></i> Gestionar Productos
                </a>
                <a href="clientes" class="btn btn-outline-dark py-3 fw-bold text-start rounded-3">
                    <i class="fa-solid fa-user-plus me-2 fs-5 align-middle"></i> Registrar Cliente
                </a>
                <a href="historial-ventas" class="btn btn-outline-dark py-3 fw-bold text-start rounded-3">
                    <i class="fa-solid fa-file-invoice-dollar me-2 fs-5 align-middle"></i> Historial de Ventas
                </a>
            </div>
        </div>
    </div>

</div>

<!-- =============================================
SECCIÓN DE CAJA, ÚLTIMAS VENTAS Y MÉTODOS DE PAGO
============================================= -->
<div class="row g-4 mb-4">

    <div class="col-xl-5 col-lg-12">
        <div class="card border-0 shadow-sm rounded-3 h-100">
            <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                <h5 class="fw-bold mb-0 text-success"><i class="fa-solid fa-wallet me-2"></i> Estado de Caja Chica del Día</h5>
                <span class="badge <?php echo $claseEstadoCaja; ?> px-3 py-2"><?php echo $estadoCaja; ?></span>
            </div>
            <div class="card-body">
                <div class="row g-3 text-center">
                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <small class="text-muted d-block mb-1">Saldo de apertura</small>
                            <h5 class="fw-bold mb-0">S/ <?php echo number_format($saldoAperturaCaja, 2); ?></h5>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <small class="text-muted d-block mb-1">Ingresos hoy</small>
                            <h5 class="fw-bold text-success mb-0">S/ <?php echo number_format($ingresosEfectivoDia, 2); ?></h5>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <small class="text-muted d-block mb-1">Egresos hoy</small>
                            <h5 class="fw-bold text-danger mb-0">S/ <?php echo number_format($egresosEfectivoDia, 2); ?></h5>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <small class="text-muted d-block mb-1">Saldo estimado</small>
                            <h5 class="fw-bold mb-0">S/ <?php echo number_format($saldoEstimadoCaja, 2); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-7 col-lg-12">
        <div class="card border-0 shadow-sm rounded-3 h-100">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="fw-bold mb-0 text-primary"><i class="fa-solid fa-clock-rotate-left me-2"></i> Últimas 5 Ventas Realizadas</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Comprobante</th>
                                <th>Cliente</th>
                                <th>Monto</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($ultimasVentas)): ?>
                                <tr>
                                    <td colspan="4" class="text-center py-4 text-muted">No hay ventas registradas aún.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($ultimasVentas as $venta): ?>
                                    <tr>
                                        <td class="ps-4"><span class="badge bg-secondary"><?php echo $venta["codigo"]; ?></span></td>
                                        <td class="fw-semibold"><?php echo $venta["cliente"]; ?></td>
                                        <td class="fw-bold text-success">S/ <?php echo number_format($venta["monto"], 2); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo strtolower($venta["estado"]) === "anulada" ? "danger" : "success"; ?>"><?php echo $venta["estado"]; ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm rounded-3 h-100">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="fw-bold mb-0 text-warning"><i class="fa-solid fa-chart-pie me-2"></i> Ventas por Método de Pago (Hoy)</h5>
            </div>
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-12">
                        <div style="height: 230px;">
                            <canvas id="graficoMetodosPagoDashboard"></canvas>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="list-group list-group-flush">
                            <?php foreach ($labelsMetodoPago as $index => $label): ?>
                                <div class="list-group-item border-0 px-0">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center">
                                            <span class="d-inline-block rounded-circle me-2" style="width: 12px; height: 12px; background: <?php echo $coloresMetodoPago[$index]; ?>;"></span>
                                            <span class="fw-semibold"><?php echo $label; ?></span>
                                        </div>
                                        <span class="fw-bold text-dark">S/ <?php echo number_format($datosMetodoPago[$index], 2); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- =============================================
TARJETAS DE INFORME RÁPIDO (INVENTARIO Y ENTIDADES)
============================================= -->

<script>
$(document).ready(function() {
    const ctxMetodoPago = document.getElementById('graficoMetodosPagoDashboard');
    if (ctxMetodoPago) {
        new Chart(ctxMetodoPago, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($labelsMetodoPago); ?>,
                datasets: [{
                    data: <?php echo json_encode($datosMetodoPago); ?>,
                    backgroundColor: <?php echo json_encode($coloresMetodoPago); ?>,
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '58%',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.label + ': S/ ' + Number(context.parsed).toFixed(2);
                            }
                        }
                    }
                }
            }
        });
    }
});
</script>