<?php
// Aseguramos que los controladores estén cargados para evitar que PHP falle
if (!class_exists("ControladorCategorias")) {
    if (file_exists("controladores/categorias.controlador.php")) {
        require_once "controladores/categorias.controlador.php";
    }
}
if (!class_exists("ModeloCategorias")) {
    if (file_exists("modelos/categorias.modelo.php")) {
        require_once "modelos/categorias.modelo.php";
    }
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold"><i class="fa-solid fa-box me-2 text-primary"></i> Gestión de Productos</h3>
    <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#modalAgregarProducto">
        <i class="fa-solid fa-plus me-1"></i> Agregar Producto
    </button>
</div>

<div class="card border-0 shadow-sm rounded-3">
    <div class="card-body p-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Código</th>
                        <th>Código de barras</th>
                        <th>Descripción</th>
                        <th>Presentación</th>
                        <th>Categoría</th>
                        <th>Stock</th>
                        <th>Precio Venta</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $productos = ControladorProductos::ctrMostrarProductos(null, null);

                    if (is_array($productos) && !empty($productos)) {
                        foreach ($productos as $key => $value) {
                            $id = isset($value["id"]) ? $value["id"] : "";
                            $codigo = isset($value["codigo"]) ? $value["codigo"] : "";
                            $codigoBarras = isset($value["codigo_barras"]) ? $value["codigo_barras"] : "";
                            $descripcion = isset($value["descripcion"]) ? $value["descripcion"] : "";
                            $unidadMedida = isset($value["unidad_medida"]) ? $value["unidad_medida"] : "Unidad";
                            $categoria = !empty($value["categoria"]) ? $value["categoria"] : "Sin Categoría";
                            $stock = isset($value["stock"]) ? $value["stock"] : 0;
                            $precio = isset($value["precio_venta"]) ? $value["precio_venta"] : 0;

                            echo '<tr>
                                <td>'.($key+1).'</td>
                                <td><span class="badge bg-secondary">'.$codigo.'</span></td>
                                <td>'.(!empty($codigoBarras) ? '<span class="badge bg-light text-dark border"><i class="fa-solid fa-barcode me-1"></i>'.htmlspecialchars($codigoBarras, ENT_QUOTES, "UTF-8").'</span>' : '<span class="text-muted small">Sin código</span>').'</td>
                                <td>'.$descripcion.'</td>
                                <td><span class="badge bg-light text-primary border">'.$unidadMedida.'</span></td>
                                <td><span class="badge bg-info text-dark">'.$categoria.'</span></td>
                                <td>';
                                if($stock <= 10){
                                    echo '<span class="badge bg-danger">'.$stock.'</span>';
                                } else {
                                    echo '<span class="badge bg-success">'.$stock.'</span>';
                                }
                                echo '</td>
                                <td>S/ '.number_format((float)$precio, 2).'</td>
                                <td>
                                    <button class="btn btn-warning btn-sm btnEditarProducto" idProducto="'.$id.'"><i class="fa-solid fa-pen-to-square"></i></button>
                                    <button class="btn btn-danger btn-sm btnEliminarProducto" idProducto="'.$id.'"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>';
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- =============================================
MODAL AGREGAR PRODUCTO
============================================= -->
<div class="modal fade" id="modalAgregarProducto" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title fw-bold">Agregar Producto</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    
                    <div class="mb-3">
                        <label class="form-label">Código (Autogenerado)</label>
                        <input type="text" class="form-control" name="nuevoCodigo" id="nuevoCodigo" value="<?php echo htmlspecialchars(ModeloProductos::mdlGenerarCodigoProducto('productos'), ENT_QUOTES, 'UTF-8'); ?>" data-codigo-preview="<?php echo htmlspecialchars(ModeloProductos::mdlGenerarCodigoProducto('productos'), ENT_QUOTES, 'UTF-8'); ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Código de barras <span class="text-muted fw-normal">(opcional)</span></label>
                        <div class="input-group">
                            <input type="text" class="form-control" name="nuevoCodigoBarras" id="nuevoCodigoBarras" placeholder="Escanea o escribe el código" maxlength="50" autocomplete="off">
                            <button type="button" class="btn btn-outline-secondary" id="btnEscanearCodigoBarrasProducto" title="Escanear con cámara"><i class="fa-solid fa-camera"></i></button>
                        </div>
                        <small class="text-muted">Si el producto no tiene código de barras, se utilizará el código interno automático.</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Categoría</label>
                        <select class="form-select" name="nuevaCategoria" required>
                            <option value="">Seleccionar categoría</option>
                            <?php
                            if (class_exists("ControladorCategorias")) {
                                $categorias = ControladorCategorias::ctrMostrarCategorias(null, null);
                                if (is_array($categorias) && !empty($categorias)) {
                                    foreach ($categorias as $key => $value) {
                                        $idCat = isset($value["id"]) ? $value["id"] : "";
                                        $nombreCat = isset($value["categoria"]) ? $value["categoria"] : "";
                                        echo '<option value="'.$idCat.'">'.$nombreCat.'</option>';
                                    }
                                }
                            }
                            ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Descripción</label>
                        <input type="text" class="form-control" name="nuevaDescripcion" placeholder="Nombre del producto" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Presentación / Unidad de medida</label>
                        <select class="form-select" name="nuevaUnidadMedida" required>
                            <option value="Unidad">Unidad</option>
                            <option value="Kilogramo">Kilogramo</option>
                            <option value="Gramo">Gramo</option>
                            <option value="Litro">Litro</option>
                            <option value="Mililitro">Mililitro</option>
                            <option value="Metro">Metro</option>
                            <option value="Centimetro">Centímetro</option>
                            <option value="Caja">Caja</option>
                            <option value="Paquete">Paquete</option>
                            <option value="Docena">Docena</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Stock</label>
                        <input type="number" class="form-control" name="nuevoStock" min="0" placeholder="0" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Precio de Venta (S/)</label>
                        <input type="number" step="0.01" class="form-control" name="nuevoPrecioVenta" placeholder="0.00" required>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar Producto</button>
                </div>
                <?php
                    if (method_exists("ControladorProductos", "ctrCrearProducto")) {
                        ControladorProductos::ctrCrearProducto();
                    }
                ?>
            </form>
        </div>
    </div>
</div>

<!-- =============================================
MODAL EDITAR PRODUCTO
============================================= -->
<div class="modal fade" id="modalEditarProducto" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title fw-bold">Editar Producto</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="idProducto" name="idProducto">

                    <div class="mb-3">
                        <label class="form-label">Código</label>
                        <input type="text" class="form-control" id="editarCodigo" name="editarCodigo" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Código de barras <span class="text-muted fw-normal">(opcional)</span></label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="editarCodigoBarras" name="editarCodigoBarras" maxlength="50" autocomplete="off" placeholder="Escanea o escribe el código">
                            <button type="button" class="btn btn-outline-secondary" id="btnEscanearCodigoBarrasEditar" title="Escanear con cámara"><i class="fa-solid fa-camera"></i></button>
                        </div>
                        <small class="text-muted">Déjalo vacío si deseas quitar el código de barras.</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Categoría</label>
                        <select class="form-select" id="editarCategoria" name="editarCategoria" required>
                            <option value="">Seleccionar categoría</option>
                            <?php
                            if (class_exists("ControladorCategorias")) {
                                $categorias = ControladorCategorias::ctrMostrarCategorias(null, null);
                                if (is_array($categorias) && !empty($categorias)) {
                                    foreach ($categorias as $key => $value) {
                                        $idCat = isset($value["id"]) ? $value["id"] : "";
                                        $nombreCat = isset($value["categoria"]) ? $value["categoria"] : "";
                                        echo '<option value="'.$idCat.'">'.$nombreCat.'</option>';
                                    }
                                }
                            }
                            ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Descripción</label>
                        <input type="text" class="form-control" id="editarDescripcion" name="editarDescripcion" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Presentación / Unidad de medida</label>
                        <select class="form-select" id="editarUnidadMedida" name="editarUnidadMedida" required>
                            <option value="Unidad">Unidad</option>
                            <option value="Kilogramo">Kilogramo</option>
                            <option value="Gramo">Gramo</option>
                            <option value="Litro">Litro</option>
                            <option value="Mililitro">Mililitro</option>
                            <option value="Metro">Metro</option>
                            <option value="Centimetro">Centímetro</option>
                            <option value="Caja">Caja</option>
                            <option value="Paquete">Paquete</option>
                            <option value="Docena">Docena</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Stock</label>
                        <input type="number" class="form-control" id="editarStock" name="editarStock" min="0" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Precio de Venta (S/)</label>
                        <input type="number" step="0.01" class="form-control" id="editarPrecioVenta" name="editarPrecioVenta" required>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-warning fw-bold">Guardar Cambios</button>
                </div>
                <?php
                    if (method_exists("ControladorProductos", "ctrEditarProducto")) {
                        ControladorProductos::ctrEditarProducto();
                    }
                ?>
            </form>
        </div>
    </div>
</div>

<?php
if (method_exists("ControladorProductos", "ctrBorrarProducto")) {
    ControladorProductos::ctrBorrarProducto();
}
?>

<div class="modal fade" id="modalScannerCodigoBarrasProducto" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title"><i class="fa-solid fa-barcode me-2"></i>Escanear código de barras</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="readerProductoCodigo" class="border rounded overflow-hidden mb-3"></div>
                <div class="input-group">
                    <input type="text" id="codigoBarrasEscaneadoProducto" class="form-control" placeholder="También puedes escribir el código">
                    <button type="button" class="btn btn-primary" id="btnAplicarCodigoBarrasProducto"><i class="fa-solid fa-check"></i></button>
                </div>
                <div id="estadoCodigoBarrasProducto" class="small mt-2"></div>
            </div>
        </div>
    </div>
</div>

<script>
let scannerCodigoBarrasProducto = null;
let campoCodigoBarrasActivo = null;
function detenerScannerProducto(){
    if(scannerCodigoBarrasProducto){
        scannerCodigoBarrasProducto.stop().catch(function(){}).finally(function(){
            scannerCodigoBarrasProducto.clear();
            scannerCodigoBarrasProducto=null;
        });
    }
}
function abrirScannerProducto(campo){
    campoCodigoBarrasActivo = campo;
    new bootstrap.Modal(document.getElementById('modalScannerCodigoBarrasProducto')).show();
}
$(document).on('shown.bs.modal','#modalScannerCodigoBarrasProducto',function(){
    if(typeof Html5Qrcode === 'undefined'){
        $('#estadoCodigoBarrasProducto').html('<span class="text-danger">No se encontró el lector de cámara.</span>'); return;
    }
    if(scannerCodigoBarrasProducto) return;
    scannerCodigoBarrasProducto = new Html5Qrcode('readerProductoCodigo');
    const formatos=[Html5QrcodeSupportedFormats.CODE_128,Html5QrcodeSupportedFormats.CODE_39,Html5QrcodeSupportedFormats.EAN_13,Html5QrcodeSupportedFormats.EAN_8,Html5QrcodeSupportedFormats.UPC_A,Html5QrcodeSupportedFormats.UPC_E,Html5QrcodeSupportedFormats.ITF,Html5QrcodeSupportedFormats.CODABAR];
    scannerCodigoBarrasProducto.start({facingMode:'environment'},{fps:10,qrbox:{width:320,height:120},formatsToSupport:formatos},function(texto){
        $('#codigoBarrasEscaneadoProducto').val(texto);
        if(campoCodigoBarrasActivo) $(campoCodigoBarrasActivo).val(texto);
        $('#estadoCodigoBarrasProducto').html('<span class="text-success"><i class="fa-solid fa-circle-check me-1"></i>Código leído correctamente.</span>');
        setTimeout(function(){ var m=bootstrap.Modal.getInstance(document.getElementById('modalScannerCodigoBarrasProducto')); if(m)m.hide(); },500);
    },function(){}).catch(function(){
        $('#estadoCodigoBarrasProducto').html('<span class="text-warning">No se pudo abrir la cámara. Usa localhost/HTTPS y concede permiso.</span>');
    });
});
$(document).on('hidden.bs.modal','#modalScannerCodigoBarrasProducto',function(){ detenerScannerProducto(); });
$(document).on('click','#btnEscanearCodigoBarrasProducto',function(){ abrirScannerProducto('#nuevoCodigoBarras'); });
$(document).on('click','#btnEscanearCodigoBarrasEditar',function(){ abrirScannerProducto('#editarCodigoBarras'); });
$(document).on('click','#btnAplicarCodigoBarrasProducto',function(){
    const v=$('#codigoBarrasEscaneadoProducto').val().trim();
    if(v && campoCodigoBarrasActivo) $(campoCodigoBarrasActivo).val(v);
    var m=bootstrap.Modal.getInstance(document.getElementById('modalScannerCodigoBarrasProducto')); if(m)m.hide();
});

$(document).on('show.bs.modal','#modalAgregarProducto',function(){
    $('#nuevoCodigo').val($('#nuevoCodigo').data('codigo-preview') || '');
    $('#nuevoCodigoBarras').val('');
});

$(document).on('hidden.bs.modal','#modalAgregarProducto',function(){
    const form=this.querySelector('form');
    if(form) form.reset();
});

$(document).on('hidden.bs.modal','#modalScannerCodigoBarrasProducto',function(){
    $('#codigoBarrasEscaneadoProducto').val('');
    $('#estadoCodigoBarrasProducto').empty();
    campoCodigoBarrasActivo=null;
});

/*=============================================
EDITAR PRODUCTO (AJAX)
=============================================*/
$(document).on("click", ".btnEditarProducto", function() {
    var idProducto = $(this).attr("idProducto");
    
    var datos = new FormData();
    datos.append("idProducto", idProducto);

    $.ajax({
        url: "ajax/productos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            if (Array.isArray(respuesta) && respuesta.length > 0) respuesta = respuesta[0];
            if (!respuesta || !respuesta.id) {
                Swal.fire({icon:"error",title:"No se pudo cargar el producto",text:"Actualiza la página e inténtalo nuevamente."});
                return;
            }

            $("#idProducto").val(respuesta["id"]);
            $("#editarCodigo").val(respuesta["codigo"]);
            $("#editarCodigoBarras").val(respuesta["codigo_barras"] || "");
            $("#editarCategoria").val(respuesta["id_categoria"]);
            $("#editarDescripcion").val(respuesta["descripcion"]);
            $("#editarUnidadMedida").val(respuesta["unidad_medida"] || "Unidad");
            $("#editarStock").val(respuesta["stock"]);
            $("#editarPrecioVenta").val(respuesta["precio_venta"] || respuesta["precio"]);

            var modalEditar = new bootstrap.Modal(document.getElementById('modalEditarProducto'));
            modalEditar.show();
        },
        error: function(jqXHR) {
            console.error("Error AJAX productos:", jqXHR.responseText);
            Swal.fire({icon:"error",title:"Error al cargar el producto",text:"El servidor no devolvió una respuesta válida."});
        }
    });
});

/*=============================================
ELIMINAR PRODUCTO
=============================================*/
$(document).on("click", ".btnEliminarProducto", function() {
    var idProducto = $(this).attr("idProducto");

    Swal.fire({
        title: '¿Está seguro de borrar el producto?',
        text: "¡Si no lo está puede cancelar la acción!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Sí, borrar producto!'
    }).then(function(result) {
        if (result.isConfirmed) {
            window.location = "index.php?ruta=productos&idProducto=" + idProducto;
        }
    });
});
</script>