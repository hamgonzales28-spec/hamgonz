<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold"><i class="fa-solid fa-users me-2 text-primary"></i> Gestión de Usuarios</h3>
    <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#modalAgregarUsuario">
        <i class="fa-solid fa-user-plus me-1"></i> Agregar Usuario
    </button>
</div>

<div class="card border-0 shadow-sm rounded-3">
    <div class="card-body p-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Usuario</th>
                        <th>Perfil</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $usuarios = ModeloUsuarios::mdlMostrarUsuarios("usuarios", null, null);

                    if (!empty($usuarios)) {
                        foreach ($usuarios as $key => $value) {
                            echo '<tr>
                                <td>'.($key+1).'</td>
                                <td>'.$value["nombre"].'</td>
                                <td><span class="badge bg-secondary">'.$value["usuario"].'</span></td>
                                <td><span class="badge bg-info text-dark">'.$value["perfil"].'</span></td>
                                <td>
                                    <button class="btn btn-warning btn-sm btnEditarUsuario" idUsuario="'.$value["id"].'" data-bs-toggle="modal" data-bs-target="#modalEditarUsuario" title="Editar"><i class="fa-solid fa-pen"></i></button>
                                    <a href="index.php?ruta=usuarios&idUsuario='.$value["id"].'" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                                </td>
                            </tr>';
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- MODAL AGREGAR USUARIO -->
<div class="modal fade" id="modalAgregarUsuario" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title fw-bold">Agregar Usuario</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nombre Completo</label>
                        <input type="text" class="form-control" name="nuevoNombre" placeholder="Ej: Juan Pérez" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nombre de Usuario</label>
                        <input type="text" class="form-control" name="nuevoUsuario" placeholder="Ej: jperez" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Contraseña</label>
                        <input type="password" class="form-control" name="nuevoPassword" placeholder="••••••••" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Perfil / Rol</label>
                        <select class="form-select" name="nuevoPerfil" required>
                            <option value="Administrador">Administrador</option>
                            <option value="Vendedor">Vendedor</option>
                            <option value="Almacenero">Almacenero</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar Usuario</button>
                </div>
                <?php
                    ControladorAuth::ctrCrearUsuario();
                ?>
            </form>
        </div>
    </div>
</div>

<!-- MODAL EDITAR USUARIO -->
<div class="modal fade" id="modalEditarUsuario" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title fw-bold">Editar Usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="idUsuario" id="idUsuario">
                    <div class="mb-3">
                        <label class="form-label">Nombre Completo</label>
                        <input type="text" class="form-control" name="editarNombre" id="editarNombre" placeholder="Ej: Juan Pérez" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nombre de Usuario</label>
                        <input type="text" class="form-control" name="editarUsuario" id="editarUsuario" placeholder="Ej: jperez" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Perfil / Rol</label>
                        <select class="form-select" name="editarPerfil" id="editarPerfil" required>
                            <option value="Administrador">Administrador</option>
                            <option value="Vendedor">Vendedor</option>
                            <option value="Almacenero">Almacenero</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-warning">Guardar Cambios</button>
                </div>
                <?php
                    ControladorAuth::ctrEditarUsuario();
                ?>
            </form>
        </div>
    </div>
</div>

<?php
  ControladorAuth::ctrBorrarUsuario();
?>

<script>
$(document).on("click", ".btnEditarUsuario", function() {
    var idUsuario = $(this).attr("idUsuario");
    
    $.ajax({
        url: "ajax/obtener_usuario.ajax.php",
        method: "POST",
        data: { idUsuario: idUsuario },
        dataType: "json",
        success: function(respuesta) {
            $("#idUsuario").val(respuesta["id"]);
            $("#editarNombre").val(respuesta["nombre"]);
            $("#editarUsuario").val(respuesta["usuario"]);
            $("#editarPerfil").val(respuesta["perfil"]);
        }
    });
});
</script>