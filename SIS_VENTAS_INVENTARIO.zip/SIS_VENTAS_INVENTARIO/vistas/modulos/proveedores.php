<?php
require_once "modelos/proveedores.modelo.php";
require_once "controladores/proveedores.controlador.php";
?>

<div class="content-wrapper p-3">

    <section class="content-header mb-3">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <h1><i class="fa-solid fa-truck-field me-2"></i>Gestión de Proveedores</h1>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAgregarProveedor">
                <i class="fa-solid fa-plus me-1"></i> Agregar Proveedor
            </button>
        </div>
    </section>

    <div class="row mb-3">
        <div class="col-md-4 ms-auto">
            <div class="input-group">
                <span class="input-group-text"><i class="fa-solid fa-magnifying-glass"></i></span>
                <input type="text" id="buscarTablaProveedor" class="form-control" placeholder="Buscar proveedor...">
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <div class="card shadow-sm">
                <div class="card-body">
                    <!-- TABLA RESPONSIVE -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped dt-responsive tablas w-100">
                            <thead class="table-dark">
                                <tr>
                                    <th style="width:10px">#</th>
                                    <th>DNI / RUC</th>
                                    <th>Razón Social / Nombre</th>
                                    <th>Contacto</th>
                                    <th>Teléfono</th>
                                    <th>Email</th>
                                    <th>Dirección</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $proveedores = ControladorProveedores::ctrMostrarProveedores(null, null);

                                foreach ($proveedores as $key => $value) {
                                    $dni = $value["doc_identidad"] ?? '-';
                                    $ruc = $value["ruc"] ?? '-';
                                    $doc_display = ($dni !== '-' ? $dni : $ruc);
                                    
                                    echo '<tr>
                                        <td>' . ($key + 1) . '</td>
                                        <td><span class="badge bg-secondary fs-6">' . $doc_display . '</span></td>
                                        <td>' . $value["razon_social"] . '</td>
                                        <td>' . ($value["contacto"] ? $value["contacto"] : "-") . '</td>
                                        <td>' . ($value["telefono"] ? $value["telefono"] : "-") . '</td>
                                        <td>' . ($value["email"] ? $value["email"] : "-") . '</td>
                                        <td>' . ($value["direccion"] ? $value["direccion"] : "-") . '</td>
                                        <td>
                                            <div class="btn-group flex-nowrap" role="group">
                                                <button class="btn btn-warning btn-sm btnEditarProveedor" idProveedor="' . $value["id"] . '" data-bs-toggle="modal" data-bs-target="#modalEditarProveedor" title="Editar">
                                                    <i class="fa-solid fa-pen text-white"></i>
                                                </button>
                                                <button class="btn btn-danger btn-sm btnEliminarProveedor" idProveedor="' . $value["id"] . '" title="Eliminar">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>

<!-- MODAL AGREGAR PROVEEDOR -->
<div class="modal fade" id="modalAgregarProveedor" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fa-solid fa-truck-field me-2"></i>Agregar Proveedor</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">DNI:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="nuevoDocIdentidad" id="nuevoDocIdentidad" placeholder="Ingrese DNI" maxlength="8">
                                <button class="btn btn-outline-primary btnBuscarProveedorApi" type="button" data-tipo="dni" data-input="#nuevoDocIdentidad" data-rs="#nuevaRazonSocial" data-contact="#nuevoContacto" data-dir="#nuevaDireccion">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">RUC:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="nuevoRuc" id="nuevoRuc" placeholder="Ingrese RUC" maxlength="11">
                                <button class="btn btn-outline-primary btnBuscarProveedorApi" type="button" data-tipo="ruc" data-input="#nuevoRuc" data-rs="#nuevaRazonSocial" data-contact="#nuevoContacto" data-dir="#nuevaDireccion">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Razón Social / Empresa (*):</label>
                            <input type="text" class="form-control" name="nuevaRazonSocial" id="nuevaRazonSocial" placeholder="Nombre de la empresa" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Persona de Contacto:</label>
                            <input type="text" class="form-control" name="nuevoContacto" id="nuevoContacto" placeholder="Ej. Juan Pérez">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Teléfono / WhatsApp:</label>
                            <input type="text" class="form-control" name="nuevoTelefono" placeholder="987654321">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Correo Electrónico:</label>
                            <input type="email" class="form-control" name="nuevoEmail" placeholder="contacto@empresa.com">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Dirección Fiscal:</label>
                            <input type="text" class="form-control" name="nuevaDireccion" id="nuevaDireccion" placeholder="Av. Principal 123">
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar Proveedor</button>
                </div>

                <?php
                $crearProveedor = new ControladorProveedores();
                $crearProveedor->ctrCrearProveedor();
                ?>
            </form>
        </div>
    </div>
</div>

<!-- MODAL EDITAR PROVEEDOR -->
<div class="modal fade" id="modalEditarProveedor" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title"><i class="fa-solid fa-pen me-2"></i>Editar Proveedor</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <input type="hidden" name="idProveedor" id="idProveedor">

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">DNI:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="editarDocIdentidad" id="editarDocIdentidad" maxlength="8">
                                <button class="btn btn-outline-primary btnBuscarProveedorApi" type="button" data-tipo="dni" data-input="#editarDocIdentidad" data-rs="#editarRazonSocial" data-contact="#editarContacto" data-dir="#editarDireccion">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">RUC</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="editarRuc" id="editarRuc" maxlength="11">
                                <button class="btn btn-outline-primary btnBuscarProveedorApi" type="button" data-tipo="ruc" data-input="#editarRuc" data-rs="#editarRazonSocial" data-contact="#editarContacto" data-dir="#editarDireccion">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Razón Social / Empresa (*):</label>
                            <input type="text" class="form-control" name="editarRazonSocial" id="editarRazonSocial" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Persona de Contacto:</label>
                            <input type="text" class="form-control" name="editarContacto" id="editarContacto">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Teléfono / WhatsApp:</label>
                            <input type="text" class="form-control" name="editarTelefono" id="editarTelefono">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Correo Electrónico:</label>
                            <input type="email" class="form-control" name="editarEmail" id="editarEmail">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Dirección Fiscal:</label>
                            <input type="text" class="form-control" name="editarDireccion" id="editarDireccion">
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-warning">Guardar Cambios</button>
                </div>

                <?php
                $editarProveedor = new ControladorProveedores();
                $editarProveedor->ctrEditarProveedor();
                $borrarProveedor = new ControladorProveedores();
                $borrarProveedor->ctrBorrarProveedor();
                ?>
            </form>
        </div>
    </div>
</div>

<script>
$(document).on("click", ".btnEditarProveedor", function() {
    var idProveedor = $(this).attr("idProveedor");
    var datos = new FormData();
    datos.append("idProveedor", idProveedor);

    $.ajax({
        url: "ajax/proveedores.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            $("#idProveedor").val(respuesta["id"]);
            if ($("#editarDocIdentidad").length) $("#editarDocIdentidad").val(respuesta["doc_identidad"]);
            $("#editarRuc").val(respuesta["ruc"]);
            $("#editarRazonSocial").val(respuesta["razon_social"]);
            $("#editarContacto").val(respuesta["contacto"]);
            $("#editarTelefono").val(respuesta["telefono"]);
            $("#editarEmail").val(respuesta["email"]);
            $("#editarDireccion").val(respuesta["direccion"]);
        }
    });
});

$(document).on("click", ".btnEliminarProveedor", function() {
    var idProveedor = $(this).attr("idProveedor");

    Swal.fire({
        title: '¿Está seguro de borrar el proveedor?',
        text: "¡Si no lo está puede cancelar la acción!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Si, borrar proveedor!'
    }).then(function(result) {
        if (result.isConfirmed) {
            window.location = "index.php?ruta=proveedores&idProveedor=" + idProveedor;
        }
    });
});

$(document).ready(function() {
    $("#buscarTablaProveedor").on("keyup", function() {
        var valor = $(this).val().toLowerCase();
        $(".tablas tbody tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(valor) > -1);
        });
    });
});

/*=============================================
CONSULTA API RENIEC / SUNAT PROVEEDORES
=============================================*/
$(document).on("click", ".btnBuscarProveedorApi", function() {
    var btn = $(this);
    var tipo = btn.data("tipo");
    var inputDoc = $(btn.data("input"));
    var documento = inputDoc.val().trim();
    var targetRs = $(btn.data("rs"));
    var targetContact = $(btn.data("contact"));
    var targetDir = $(btn.data("dir"));

    if (tipo === "dni" && documento.length !== 8) {
        Swal.fire('Atención', 'El DNI debe tener 8 dígitos', 'warning');
        return;
    }
    if (tipo === "ruc" && documento.length !== 11) {
        Swal.fire('Atención', 'El RUC debe tener 11 dígitos', 'warning');
        return;
    }

    btn.prop("disabled", true).html('<i class="fa-solid fa-spinner fa-spin"></i>');

    var datos = new FormData();
    datos.append("documento", documento);
    datos.append("tipo", tipo);

    $.ajax({
        url: "ajax/consulta_doc.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            btn.prop("disabled", false).html('<i class="fa-solid fa-magnifying-glass"></i>');

            var res = respuesta.data ? respuesta.data : respuesta;

            if (res.error || respuesta.error) {
                Swal.fire('Error', 'No se encontraron datos para el documento ingresado', 'error');
                return;
            }

            if (tipo === "dni") {
                var nombres = res.nombres || res.nombre || "";
                var apePaterno = res.apellidoPaterno || res.paterno || res.apellido_paterno || "";
                var apeMaterno = res.apellidoMaterno || res.materno || res.apellido_materno || "";
                
                var nombreCompleto = $.trim(nombres + " " + apePaterno + " " + apeMaterno);

                if (nombreCompleto === "") {
                    nombreCompleto = res.nombreCompleto || res.nombre_completo || res.razonSocial || res.razon_social || "No encontrado";
                }

                targetRs.val(nombreCompleto);
                if (targetContact) targetContact.val(nombreCompleto);
                if (targetDir && targetDir.length) targetDir.val(res.direccion || "");
            } else if (tipo === "ruc") {
                var razon = res.razonSocial || res.razon_social || res.company_name || res.nombre || res.name || "";
                var direccion = res.direccion || res.address || res.direccion_fiscal || res.domicilio_fiscal || "";

                targetRs.val(razon);
                if (targetContact) targetContact.val(razon);
                if (targetDir && targetDir.length) targetDir.val(direccion);
            }

            Swal.fire({
                icon: 'success',
                title: '¡Datos Autocompletados!',
                timer: 1200,
                showConfirmButton: false
            });
        },
        error: function() {
            btn.prop("disabled", false).html('<i class="fa-solid fa-magnifying-glass"></i>');
            Swal.fire('Error', 'No se pudo conectar con el servicio', 'error');
        }
    });
});
</script>