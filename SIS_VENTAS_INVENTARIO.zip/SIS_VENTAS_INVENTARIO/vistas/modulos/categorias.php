<?php
require_once "controladores/categorias.controlador.php";
require_once "modelos/categorias.modelo.php";

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold"><i class="fa-solid fa-tags me-2 text-primary"></i> Gestión de Categorías</h3>
    <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#modalAgregarCategoria">
        <i class="fa-solid fa-plus me-1"></i> Agregar Categoría
    </button>
</div>

<div class="card border-0 shadow-sm rounded-3">
    <div class="card-body p-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th style="width:10px">#</th>
                        <th>Categoría</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $categorias = ControladorCategorias::ctrMostrarCategorias(null, null);

                    if (is_array($categorias) && !empty($categorias)) {
                        foreach ($categorias as $key => $value) {
                            echo '<tr>
                                <td>'.($key+1).'</td>
                                <td class="fw-bold">'.$value["categoria"].'</td>
                                <td>
                                    <button class="btn btn-warning btn-sm btnEditarCategoria" idCategoria="'.$value["id"].'"><i class="fa-solid fa-pen-to-square"></i></button>
                                    <button class="btn btn-danger btn-sm btnEliminarCategoria" idCategoria="'.$value["id"].'"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>';
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- MODAL AGREGAR CATEGORÍA -->
<div class="modal fade" id="modalAgregarCategoria" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title fw-bold">Agregar Categoría</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nombre de la Categoría</label>
                        <input type="text" class="form-control" name="nuevaCategoria" placeholder="Ej: Electrónica, Ropa, etc." required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar Categoría</button>
                </div>
                <?php
                    ControladorCategorias::ctrCrearCategoria();
                ?>
            </form>
        </div>
    </div>
</div>

<!-- MODAL EDITAR CATEGORÍA -->
<div class="modal fade" id="modalEditarCategoria" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title fw-bold">Editar Categoría</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="idCategoria" name="idCategoria">
                    <div class="mb-3">
                        <label class="form-label">Nombre de la Categoría</label>
                        <input type="text" class="form-control" id="editarCategoria" name="editarCategoria" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-warning fw-bold">Guardar Cambios</button>
                </div>
                <?php
                    ControladorCategorias::ctrEditarCategoria();
                ?>
            </form>
        </div>
    </div>
</div>

<?php
  ControladorCategorias::ctrBorrarCategoria();
?>

<script>
/* EDITAR CATEGORIA (AJAX) */
$(document).on("click", ".btnEditarCategoria", function() {
    var idCategoria = $(this).attr("idCategoria");

    var datos = new FormData();
    datos.append("idCategoria", idCategoria);

    $.ajax({
        url: "ajax/categorias.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            $("#idCategoria").val(respuesta["id"]);
            $("#editarCategoria").val(respuesta["categoria"]);

            var modalEditar = new bootstrap.Modal(document.getElementById('modalEditarCategoria'));
            modalEditar.show();
        }
    });
});

/* ELIMINAR CATEGORIA */
$(document).on("click", ".btnEliminarCategoria", function() {
    var idCategoria = $(this).attr("idCategoria");

    Swal.fire({
        title: '¿Está seguro de borrar la categoría?',
        text: "¡Si no lo está puede cancelar la acción!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Sí, borrar categoría!'
    }).then(function(result) {
        if (result.isConfirmed) {
            window.location = "index.php?ruta=categorias&idCategoria=" + idCategoria;
        }
    });
});
</script>