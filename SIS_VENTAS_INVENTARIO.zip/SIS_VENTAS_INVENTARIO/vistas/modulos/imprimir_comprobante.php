<?php
// 1. Iniciar captura de buffer
ob_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once "../../config/conexion.php";

// 2. Localizar librería FPDF / Code128
$ruta_fpdf = __DIR__ . "/../extensiones/fpdf/code128.php";
if (!file_exists($ruta_fpdf)) {
    $ruta_fpdf = __DIR__ . "/../fpdf/code128.php";
}

if (!file_exists($ruta_fpdf)) {
    ob_end_clean();
    exit("<strong>Error de archivo:</strong> No se encontró <code>code128.php</code>.");
}

require_once $ruta_fpdf;

if (!isset($_GET["codigo"])) {
    ob_end_clean();
    exit("Error: Código de comprobante no especificado.");
}

// 3. Consultar Venta limpiando espacios
$codigo = trim($_GET["codigo"]);

$stmt = Conexion::conectar()->prepare("SELECT v.*, u.nombre as vendedor FROM ventas v INNER JOIN usuarios u ON v.id_usuario = u.id WHERE v.codigo_factura = :codigo");
$stmt->bindParam(":codigo", $codigo, PDO::PARAM_STR);
$stmt->execute();
$venta = $stmt->fetch();

if (!$venta) {
    ob_end_clean();
    exit("<strong style='font-family:sans-serif; color:red;'>Error:</strong> Comprobante <code>" . htmlspecialchars($codigo) . "</code> no encontrado.");
}

// 4. Consultar Detalle
$stmtDetalle = Conexion::conectar()->prepare("SELECT d.*, p.descripcion, p.unidad_medida FROM ventas_detalle d INNER JOIN productos p ON d.id_producto = p.id WHERE d.id_venta = :id_venta");
$stmtDetalle->bindParam(":id_venta", $venta["id"], PDO::PARAM_INT);
$stmtDetalle->execute();
$detalle = $stmtDetalle->fetchAll();

// 5. Dimensiones (80mm)
$ancho = 80;
$altoBase = 180;
$altoProductos = count($detalle) * 12;
$altoTotal = $altoBase + $altoProductos;

// 6. Generar PDF
$pdf = new PDF_Code128('P', 'mm', array($ancho, $altoTotal));
$pdf->SetMargins(4, 4, 4);
$pdf->SetAutoPageBreak(true, 4);
$pdf->AddPage();

$anchoUtil = 72;

// Encabezado
$pdf->SetFont('Arial', 'B', 11);
$nombreEmpresa = defined('SYSTEM_NAME') ? SYSTEM_NAME : 'SIS VENTAS';
$pdf->Cell($anchoUtil, 5, utf8_decode($nombreEmpresa), 0, 1, 'C');

$pdf->SetFont('Arial', '', 9);
$pdf->Cell($anchoUtil, 4, utf8_decode('==================='), 0, 1, 'C');
$pdf->Cell($anchoUtil, 4, utf8_decode('Teléfono: 123456789'), 0, 1, 'C');
$pdf->Cell($anchoUtil, 4, utf8_decode('Email: dsdfvbn@gmail.com'), 0, 1, 'C');

$pdf->Cell($anchoUtil, 3, '------------------------------------------------------------------', 0, 1, 'C');

$pdf->Cell($anchoUtil, 4, utf8_decode('Fecha: ' . date("d/m/Y h:i a", strtotime($venta["fecha"]))), 0, 1, 'C');
$pdf->Cell($anchoUtil, 4, utf8_decode('Caja Nro: 1'), 0, 1, 'C');
$pdf->Cell($anchoUtil, 4, utf8_decode('Cajero: ' . $venta["vendedor"]), 0, 1, 'C');

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell($anchoUtil, 5, utf8_decode(strtoupper($venta["tipo_comprobante"]) . ' NRO: ' . $venta["codigo_factura"]), 0, 1, 'C');

$pdf->SetFont('Arial', '', 9);
$pdf->Cell($anchoUtil, 3, '------------------------------------------------------------------', 0, 1, 'C');

// Tabla
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(12, 4, 'Cant.', 0, 0, 'C');
$pdf->Cell(34, 4, 'Product.', 0, 0, 'L');
$pdf->Cell(14, 4, 'Precio', 0, 0, 'R');
$pdf->Cell(14, 4, 'Total', 0, 1, 'R');

$pdf->Cell($anchoUtil, 3, '------------------------------------------------------------------', 0, 1, 'C');

$pdf->SetFont('Arial', '', 8);
foreach ($detalle as $item) {
    $descripcion = utf8_decode(substr($item["descripcion"], 0, 22));
    $unidadMedida = utf8_decode($item["unidad_medida"] ?? "Unidad");
    $precioItem = isset($item["precio_unitario"]) ? (float) $item["precio_unitario"] : 0;
    $totalItem = isset($item["total_item"]) ? (float) $item["total_item"] : 0;

    $pdf->Cell(12, 5, $item["cantidad"]." ".substr($unidadMedida, 0, 4), 0, 0, 'C');
    $pdf->Cell(34, 5, $descripcion, 0, 0, 'L');
    $pdf->Cell(14, 5, 'S/ ' . number_format($precioItem, 2), 0, 0, 'R');
    $pdf->Cell(14, 5, 'S/ ' . number_format($totalItem, 2), 0, 1, 'R');
    $pdf->Ln(1);
}

$pdf->Cell($anchoUtil, 3, '------------------------------------------------------------------', 0, 1, 'C');

// Totales, Pago y Vuelto
$subtotalVenta = isset($venta["subtotal"]) ? (float) $venta["subtotal"] : 0;
$totalVenta = isset($venta["total"]) ? (float) $venta["total"] : 0;
$descuentoVenta = max(0, $subtotalVenta - $totalVenta);

$pdf->Cell(38, 4, 'SUBTOTAL', 0, 0, 'R');
$pdf->Cell(34, 4, 'S/ ' . number_format($subtotalVenta, 2), 0, 1, 'R');

$pdf->Cell(38, 4, 'DESCUENTO', 0, 0, 'R');
$pdf->Cell(34, 4, '- S/ ' . number_format($descuentoVenta, 2), 0, 1, 'R');

$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell(38, 4, 'TOTAL', 0, 0, 'R');
$pdf->Cell(34, 4, 'S/ ' . number_format($totalVenta, 2), 0, 1, 'R');

$pagoCliente = isset($venta["pague_con"]) ? $venta["pague_con"] : $venta["total"];
$vueltoCliente = isset($venta["vuelto"]) ? $venta["vuelto"] : 0;

$pdf->SetFont('Arial', '', 9);
$pdf->Cell(38, 4, 'PAGADO', 0, 0, 'R');
$pdf->Cell(34, 4, 'S/ ' . number_format($pagoCliente, 2), 0, 1, 'R');

$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell(38, 4, 'VUELTO', 0, 0, 'R');
$pdf->Cell(34, 4, 'S/ ' . number_format($vueltoCliente, 2), 0, 1, 'R');

$pdf->Ln(3);

$pdf->Cell(38, 4, 'METODO DE PAGO', 0, 0, 'R');
$pdf->Cell(34, 4, utf8_decode($venta["metodo_pago"]), 0, 1, 'R');

$pdf->SetFont('Arial', '', 8);
$pdf->MultiCell($anchoUtil, 3.5, utf8_decode("*** Precios de productos incluyen impuestos. Para poder realizar un reclamo o devolución debe de presentar este ticket ***"), 0, 'C');

$pdf->Ln(2);
$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell($anchoUtil, 4, utf8_decode('Gracias por su compra'), 0, 1, 'C');
$pdf->Ln(2);

// Código de barras
$posX = ($ancho - 50) / 2;
$pdf->Code128($posX, $pdf->GetY(), $venta["codigo_factura"], 50, 10);

// Generar el PDF sin enviarlo a servicios externos.
$pdfContenido = $pdf->Output('S');
$nombreEmpresaArchivo = preg_replace('/[^a-zA-Z0-9_-]/', '_', $nombreEmpresa);
$nombreArchivo = 'Comprobante_' . $nombreEmpresaArchivo . '_' . $venta['codigo_factura'] . '.pdf';

// Salida limpia
ob_end_clean();
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="' . $nombreArchivo . '"');
header('Content-Length: ' . strlen($pdfContenido));
echo $pdfContenido;
exit();