<?php
require_once __DIR__ . '/../../modelos/clientes.modelo.php';
?>

<style>
    /* Optimizar tabla para móviles */
    @media (max-width: 768px) {
        .tablaHistorialVentas {
            font-size: 0.65rem;
        }
        .tablaHistorialVentas th,
        .tablaHistorialVentas td {
            padding: 0.3rem 0.2rem !important;
            white-space: nowrap;
            min-width: auto;
        }
        .tablaHistorialVentas .badge {
            display: inline-block;
            font-size: 0.50rem;
            white-space: nowrap;
        }
    }
</style>

<div class="content-wrapper p-3">

    <section class="content-header mb-3">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <h1><i class="fa-solid fa-list-check me-2"></i>Historial de Ventas</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="card shadow-sm">
            <div class="card-body">

                <!-- TABLA CON DATATABLES Y PAGINACIÓN -->
                <div class="table-responsive">
                <table class="table table-bordered table-striped tablaHistorialVentas w-100">
                    <thead class="table-dark">
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>N° Comprobante</th>
                            <th>Tipo</th>
                            <th>Vendedor</th>
                            <th>Método Pago</th>
                            <th>Subtotal</th>
                            <th>Descuento</th>
                            <th>Total</th>
                            <th>SUNAT</th>
                            <th>Fecha</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $ventas = ControladorVentas::ctrMostrarVentas();

                        foreach ($ventas as $key => $value) {
                            $telefonoCliente = '';
                            if (!empty($value['id_cliente']) && (int)$value['id_cliente'] > 1) {
                                $clienteVenta = ModeloClientes::mdlMostrarClientes('clientes', 'id', (int)$value['id_cliente']);
                                $telefonoCliente = preg_replace('/[^0-9]/', '', $clienteVenta['telefono'] ?? '');
                                if (strlen($telefonoCliente) === 9) {
                                    $telefonoCliente = '51' . $telefonoCliente;
                                }
                            }
                            // IMPORTANTE: no usar /vistas/tickets/Ticket_*.pdf aquí.
                            // Esos PDF solo existen si previamente fueron generados y, además,
                            // pueden provocar 404. El comprobante público se genera directamente
                            // desde la BD mediante comprobante.php y funciona también para ventas antiguas.
                            $codigoComprobante = (string)($value['codigo_factura'] ?? '');
                            $enlaceComprobante = ControladorVentas::ctrGenerarEnlaceComprobante($codigoComprobante);
                            $mensajeWhatsappTexto = 'Hola, aquí tienes tu comprobante de compra ' . $codigoComprobante . ".\n\nPuedes visualizarlo aquí: " . $enlaceComprobante;
                            $mensajeWhatsapp = rawurlencode($mensajeWhatsappTexto);
                            $enlaceWhatsapp = ($telefonoCliente !== ''
                                ? 'https://wa.me/' . rawurlencode($telefonoCliente)
                                : 'https://api.whatsapp.com/send') . '?text=' . $mensajeWhatsapp;
                            $descuento = (float) $value["subtotal"] - (float) $value["total"];
                            if ($descuento < 0) {
                                $descuento = 0;
                            }

                            echo '<tr>
                                <td>' . ($key + 1) . '</td>
                                <td><span class="badge bg-primary fs-6">' . $value["codigo_factura"] . '</span></td>
                                <td>' . $value["tipo_comprobante"] . '</td>
                                <td>' . (isset($value["vendedor"]) ? $value["vendedor"] : "Administrador") . '</td>
                                <td>' . $value["metodo_pago"] . '</td>
                                <td>S/ ' . number_format($value["subtotal"], 2) . '</td>
                                <td><span class="badge bg-warning text-dark">S/ ' . number_format($descuento, 2) . '</span></td>
                                <td><strong>S/ ' . number_format($value["total"], 2) . '</strong></td>
                                <td><span class="badge ' . (($value["sunat_estado"] ?? "NO_APLICA") === "ACEPTADO" ? "bg-success" : ((($value["sunat_estado"] ?? "NO_APLICA") === "RECHAZADO" || ($value["sunat_estado"] ?? "NO_APLICA") === "ENVIO") ? "bg-danger" : "bg-secondary")) . '">' . htmlspecialchars($value["sunat_estado"] ?? "NO_APLICA", ENT_QUOTES, "UTF-8") . '</span></td>
                                <td>' . date("d/m/Y H:i", strtotime($value["fecha"])) . '</td>
                                <td>
                                    <div class="btn-group" role="group">

                                        <!-- BOTÓN IMPRIMIR -->
                                        <button type="button" class="btn btn-info btn-sm btnImprimirTicket" data-codigo-venta="' . htmlspecialchars($value["codigo_factura"], ENT_QUOTES, "UTF-8") . '" title="Imprimir Comprobante">
                                            <i class="fa-solid fa-print text-white"></i>
                                        </button>

                                        <!-- BOTÓN WHATSAPP: comparte el comprobante público generado desde la venta -->
                                        ' . ($enlaceWhatsapp !== ''
                                            ? '<a href="' . htmlspecialchars($enlaceWhatsapp, ENT_QUOTES, 'UTF-8') . '" target="_blank" rel="noopener noreferrer" class="btn btn-success btn-sm" title="Enviar comprobante por WhatsApp">
                                            <i class="fa-brands fa-whatsapp"></i>
                                        </a>'
                                            : '') . '

                                        <!-- BOTÓN ELIMINAR / ANULAR -->
                                        <button type="button" class="btn btn-danger btn-sm btnAnularVenta" data-id-venta="' . (int)$value["id"] . '" data-codigo-venta="' . htmlspecialchars($value["codigo_factura"], ENT_QUOTES, "UTF-8") . '" title="Anular Venta">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>';
                        }
                        ?>
                    </tbody>
                </table>
                </div>

            </div>
        </div>
    </section>

</div>

<?php
// Ejecutar el controlador para eliminar/anular venta
$anularVenta = new ControladorVentas();
$anularVenta->ctrAnularVenta();
?>

<!-- JAVASCRIPT CON DELEGACIÓN DE EVENTOS Y PAGINACIÓN -->
<script>
$(document).ready(function() {

    // 1. INICIALIZAR DATATABLE CON PAGINACIÓN EN ESPAÑOL
    if (!$.fn.DataTable.isDataTable('.tablaHistorialVentas')) {
        $('.tablaHistorialVentas').DataTable({
            "paging": true,
            "pageLength": 5,
            "lengthChange": true,
            "lengthMenu": [[5, 10, 25, 50], [5, 10, 25, 50]],
            "pagingType": "full_numbers",
            "language": {
                "sProcessing":     "Procesando...",
                "sLengthMenu":     "Mostrar _MENU_ registros",
                "sZeroRecords":    "No se encontraron resultados",
                "sEmptyTable":     "Ningún dato disponible en esta tabla",
                "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                "sSearch":         "Buscar:",
                "oPaginate": {
                    "sFirst":    "Primero",
                    "sLast":     "Último",
                    "sNext":     "Siguiente",
                    "sPrevious": "Anterior"
                }
            },
            "order": [[ 0, "desc" ]] // Ordena los más recientes primero
        });
    }

    // 2. IMPRIMIR TICKET (Funciona en cualquier página)
    $(document).on("click", ".btnImprimirTicket", function(e){
        e.preventDefault();
        var codigo = $(this).data("codigo-venta") || $(this).attr("data-codigo-venta");
        if (!codigo) return;
        var url = "vistas/modulos/imprimir_comprobante.php?codigo=" + encodeURIComponent(codigo);
        window.open(url, "_blank", "width=450,height=650,scrollbars=yes");
    });

    // 3. ANULAR / ELIMINAR VENTA (Funciona en cualquier página)
    $(document).on("click", ".btnAnularVenta", function(e){
        e.preventDefault();
        var idVenta = $(this).data("id-venta") || $(this).attr("data-id-venta");
        var codigo = $(this).data("codigo-venta") || $(this).attr("data-codigo-venta");
        if (!idVenta) return;

        Swal.fire({
            title: '¿Está seguro de anular la venta?',
            text: "Se eliminará la venta " + codigo + " y el stock será devuelto a los productos.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sí, anular y eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                // Redirección con parámetro GET para procesar la eliminación
                window.location = "index.php?ruta=historial-ventas&idVentaAnular=" + encodeURIComponent(idVenta);
            }
        });
    });

    // Evitar que el botón parezca inactivo cuando Drive no pudo devolver el
    // archivo. No se envía localhost ni la carpeta: se informa el problema.
    $(document).on("click", ".btnWhatsAppSinDrive", function(e){
        e.preventDefault();
        var codigo = $(this).data("codigo-venta") || $(this).attr("data-codigo-venta");
        Swal.fire({
            icon: "warning",
            title: "Comprobante no disponible en Google Drive",
            text: "No se puede abrir WhatsApp para " + codigo + " porque Drive no devolvió el enlace del archivo. Verifique la autenticación de Google Drive.",
            confirmButtonText: "Cerrar"
        });
    });

});
</script>