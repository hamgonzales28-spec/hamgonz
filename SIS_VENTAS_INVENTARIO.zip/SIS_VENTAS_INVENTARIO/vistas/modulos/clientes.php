<?php
require_once "modelos/clientes.modelo.php";
require_once "controladores/clientes.controlador.php";
?>

<div class="content-wrapper p-3">

    <section class="content-header mb-3">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <h1><i class="fa-solid fa-users me-2"></i>Gestión de Clientes</h1>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAgregarCliente">
                <i class="fa-solid fa-user-plus me-1"></i> Agregar Cliente
            </button>
        </div>
    </section>

    <section class="content">
        <div class="card shadow-sm">
            <div class="card-body">

                <!-- TABLA RESPONSIVE -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped dt-responsive tablaClientes w-100">
                        <thead class="table-dark">
                            <tr>
                                <th style="width:10px">#</th>
                                <th>DNI / RUC</th>
                                <th>Nombre / Razón Social</th>
                                <th>Teléfono</th>
                                <th>Email</th>
                                <th>Dirección</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $clientes = ControladorClientes::ctrMostrarClientes(null, null);

                            foreach ($clientes as $key => $value) {
                                echo '<tr>
                                    <td>' . ($key + 1) . '</td>
                                    <td><span class="badge bg-secondary fs-6">' . $value["documento"] . '</span></td>
                                    <td>' . $value["nombre"] . '</td>
                                    <td>' . ($value["telefono"] ? $value["telefono"] : "-") . '</td>
                                    <td>' . ($value["email"] ? $value["email"] : "-") . '</td>
                                    <td>' . ($value["direccion"] ? $value["direccion"] : "-") . '</td>
                                    <td>
                                        <div class="btn-group flex-nowrap" role="group">
                                            <button class="btn btn-warning btn-sm btnEditarCliente" idCliente="' . $value["id"] . '" data-bs-toggle="modal" data-bs-target="#modalEditarCliente" title="Editar">
                                                <i class="fa-solid fa-pen text-white"></i>
                                            </button>
                                            <button class="btn btn-danger btn-sm btnEliminarCliente" idCliente="' . $value["id"] . '" title="Eliminar">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </section>

</div>

<!-- MODAL AGREGAR CLIENTE -->
<div class="modal fade" id="modalAgregarCliente" tabindex="-1" aria-labelledby="modalAgregarClienteLabel">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalAgregarClienteLabel"><i class="fa-solid fa-user-plus me-2"></i>Nuevo Cliente</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">DNI:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="nuevoDniCliente" placeholder="8 dígitos" maxlength="8">
                                <button class="btn btn-outline-primary btnBuscarApi" type="button" data-tipo="dni" data-input="#nuevoDniCliente" data-target-nombre="#nuevoNombre" data-target-dir="#nuevaDireccion">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">RUC:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="nuevoRucCliente" placeholder="11 dígitos" maxlength="11">
                                <button class="btn btn-outline-primary btnBuscarApi" type="button" data-tipo="ruc" data-input="#nuevoRucCliente" data-target-nombre="#nuevoNombre" data-target-dir="#nuevaDireccion">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>

                        <input type="hidden" name="nuevoDocumento" id="nuevoDocumentoCliente">

                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">Nombre Completo / Razón Social *</label>
                            <input type="text" class="form-control" name="nuevoNombre" id="nuevoNombre" placeholder="Nombre completo o Razón Social" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Teléfono</label>
                            <input type="text" class="form-control" name="nuevoTelefono" placeholder="Número celular o fijo">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" class="form-control" name="nuevoEmail" placeholder="correo@ejemplo.com">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">Dirección</label>
                            <textarea class="form-control" name="nuevaDireccion" id="nuevaDireccion" rows="2" placeholder="Dirección de domicilio o fiscal"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk me-1"></i> Guardar Cliente</button>
                </div>
                <?php
                $crearCliente = new ControladorClientes();
                $crearCliente->ctrCrearCliente();
                ?>
            </form>
        </div>
    </div>
</div>

<!-- MODAL EDITAR CLIENTE -->
<div class="modal fade" id="modalEditarCliente" tabindex="-1" aria-labelledby="modalEditarClienteLabel">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title" id="modalEditarClienteLabel"><i class="fa-solid fa-user-pen me-2"></i>Editar Cliente</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="idCliente" id="idCliente">
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">DNI:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="editarDniCliente" placeholder="8 dígitos" maxlength="8">
                                <button class="btn btn-outline-primary btnBuscarApi" type="button" data-tipo="dni" data-input="#editarDniCliente" data-target-nombre="#editarNombre" data-target-dir="#editarDireccion">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">RUC:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="editarRucCliente" placeholder="11 dígitos" maxlength="11">
                                <button class="btn btn-outline-primary btnBuscarApi" type="button" data-tipo="ruc" data-input="#editarRucCliente" data-target-nombre="#editarNombre" data-target-dir="#editarDireccion">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>

                        <input type="hidden" name="editarDocumento" id="editarDocumento">

                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">Nombre Completo / Razón Social *</label>
                            <input type="text" class="form-control" name="editarNombre" id="editarNombre" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Teléfono</label>
                            <input type="text" class="form-control" name="editarTelefono" id="editarTelefono">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" class="form-control" name="editarEmail" id="editarEmail">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">Dirección</label>
                            <textarea class="form-control" name="editarDireccion" id="editarDireccion" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-warning text-white"><i class="fa-solid fa-floppy-disk me-1"></i> Actualizar</button>
                </div>
                <?php
                $editarCliente = new ControladorClientes();
                $editarCliente->ctrEditarCliente();
                ?>
            </form>
        </div>
    </div>
</div>

<?php
$eliminarCliente = new ControladorClientes();
$eliminarCliente->ctrEliminarCliente();
?>

<script>
$(document).ready(function() {

    // Prevenir advertencia de foco en aria-hidden al ocultar modales
    $('.modal').on('hidden.bs.modal', function () {
        if (document.activeElement && document.activeElement instanceof HTMLElement) {
            document.activeElement.blur();
        }
    });

    $('.modal').on('show.bs.modal', function () {
        if (document.activeElement && document.activeElement instanceof HTMLElement) {
            document.activeElement.blur();
        }
    });

    if (!$.fn.DataTable.isDataTable('.tablaClientes')) {
        $('.tablaClientes').DataTable({
            "responsive": true,
            "autoWidth": false,
            "pageLength": 10,
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/2.0.8/i18n/es-ES.json"
            }
        });
    }

    $(document).on("click", ".btnEditarCliente", function(){
        var idCliente = $(this).attr("idCliente");
        var datos = new FormData();
        datos.append("idCliente", idCliente);

        $.ajax({
            url: "ajax/clientes.ajax.php",
            method: "POST",
            data: datos,
            cache: false,
            contentType: false,
            processData: false,
            dataType: "json",
            success: function(respuesta){
                $("#idCliente").val(respuesta["id"]);
                $("#editarDocumento").val(respuesta["documento"]);
                
                if(respuesta["documento"] && respuesta["documento"].length === 8) {
                    $("#editarDniCliente").val(respuesta["documento"]);
                    $("#editarRucCliente").val("");
                } else if(respuesta["documento"] && respuesta["documento"].length === 11) {
                    $("#editarRucCliente").val(respuesta["documento"]);
                    $("#editarDniCliente").val("");
                }

                $("#editarNombre").val(respuesta["nombre"]);
                $("#editarTelefono").val(respuesta["telefono"]);
                $("#editarEmail").val(respuesta["email"]);
                $("#editarDireccion").val(respuesta["direccion"]);
            }
        });
    });

    $(document).on("click", ".btnEliminarCliente", function(){
        var idCliente = $(this).attr("idCliente");

        Swal.fire({
            title: '¿Está seguro de eliminar el cliente?',
            text: "¡Esta acción no se puede deshacer!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location = "index.php?ruta=clientes&idClienteEliminar=" + idCliente;
            }
        });
    });

    /*=============================================
    CONSULTA API RENIEC / SUNAT CLIENTES
    =============================================*/
    $(document).on("click", ".btnBuscarApi", function() {

        var btn = $(this);
        var tipo = btn.data("tipo");
        var inputDoc = $(btn.data("input"));
        var documento = inputDoc.val().trim();
        var targetNombre = $(btn.data("target-nombre"));
        var targetDir = $(btn.data("target-dir"));

        if (tipo === "dni" && documento.length !== 8) {
            Swal.fire('Atención', 'El DNI debe tener 8 dígitos', 'warning');
            return;
        }
        if (tipo === "ruc" && documento.length !== 11) {
            Swal.fire('Atención', 'El RUC debe tener 11 dígitos', 'warning');
            return;
        }

        btn.prop("disabled", true).html('<i class="fa-solid fa-spinner fa-spin"></i>');

        var datos = new FormData();
        datos.append("documento", documento);
        datos.append("tipo", tipo);

        $.ajax({
            url: "ajax/consulta_doc.ajax.php",
            method: "POST",
            data: datos,
            cache: false,
            contentType: false,
            processData: false,
            dataType: "json",
            success: function(respuesta) {
                btn.prop("disabled", false).html('<i class="fa-solid fa-magnifying-glass"></i>');

                var res = respuesta.data ? respuesta.data : respuesta;

                if (res.error || respuesta.error) {
                    Swal.fire('Error', 'No se encontraron datos para el documento ingresado', 'error');
                    return;
                }

                if (tipo === "dni") {
                    var nombres = res.nombres || res.nombre || "";
                    var apePaterno = res.apellidoPaterno || res.paterno || res.apellido_paterno || "";
                    var apeMaterno = res.apellidoMaterno || res.materno || res.apellido_materno || "";
                    
                    var nombreCompleto = $.trim(nombres + " " + apePaterno + " " + apeMaterno);

                    if (nombreCompleto === "") {
                        nombreCompleto = res.nombreCompleto || res.nombre_completo || res.razonSocial || res.razon_social || "No encontrado";
                    }

                    targetNombre.val(nombreCompleto);
                    if (targetDir && targetDir.length) {
                        targetDir.val(res.direccion || "");
                    }
                    $("#nuevoDocumentoCliente, #editarDocumento").val(documento);
                } else if (tipo === "ruc") {
                    var razon = res.razonSocial || res.razon_social || res.company_name || res.nombre || res.name || "";
                    var direccion = res.direccion || res.address || res.direccion_fiscal || res.domicilio_fiscal || "";

                    targetNombre.val(razon);
                    if (targetDir && targetDir.length) {
                        targetDir.val(direccion);
                    }
                    $("#nuevoDocumentoCliente, #editarDocumento").val(documento);
                }

                Swal.fire({
                    icon: 'success',
                    title: '¡Datos Autocompletados!',
                    timer: 1200,
                    showConfirmButton: false
                });
            },
            error: function() {
                btn.prop("disabled", false).html('<i class="fa-solid fa-magnifying-glass"></i>');
                Swal.fire('Error', 'No se pudo conectar con el servicio', 'error');
            }
        });

    });

});
</script>