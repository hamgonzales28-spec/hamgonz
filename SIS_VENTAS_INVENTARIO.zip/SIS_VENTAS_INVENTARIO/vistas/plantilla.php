<?php
if (!isset($_SESSION["iniciarSesion"]) || $_SESSION["iniciarSesion"] !== "ok") {
    include "vistas/login.php";
    exit();
}
$rutaActual = $_GET["ruta"] ?? "dashboard";
$menuItems = [
    ["ruta" => "dashboard", "icono" => "fa-chart-pie", "texto" => "Dashboard"],
    ["ruta" => "categorias", "icono" => "fa-tags", "texto" => "Categorías"],
    ["ruta" => "productos", "icono" => "fa-box", "texto" => "Productos"],
    ["ruta" => "compras", "icono" => "fa-truck-ramp-box", "texto" => "Compras"],
    ["ruta" => "ventas", "icono" => "fa-cart-shopping", "texto" => "Ventas POS"],
    ["ruta" => "caja", "icono" => "fa-cash-register", "texto" => "Caja chica"],
    ["ruta" => "historial-ventas", "icono" => "fa-clock-rotate-left", "texto" => "Historial de ventas"],
    ["ruta" => "facturacion", "icono" => "fa-file-invoice-dollar", "texto" => "Facturación SUNAT"],
    ["ruta" => "clientes", "icono" => "fa-users", "texto" => "Clientes"],
    ["ruta" => "proveedores", "icono" => "fa-truck-field", "texto" => "Proveedores"],
    ["ruta" => "usuarios", "icono" => "fa-user-gear", "texto" => "Usuarios"],
    ["ruta" => "reportes", "icono" => "fa-file-invoice-dollar", "texto" => "Reportes"]
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SYSTEM_NAME; ?></title>

    <!-- 1. CSS ESTILOS BASE -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

    <!-- ESTILOS PERSONALIZADOS RESPONSIVE -->
    <style>
        :root {
            --bg-soft: #f3f6ff;
            --primary: #4f6ef7;
            --primary-2: #7c5cff;
            --sidebar: linear-gradient(180deg, #0f172a 0%, #111827 50%, #0b1220 100%);
            --panel: rgba(255,255,255,0.8);
            --border: rgba(148, 163, 184, 0.22);
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #edf3ff 0%, #f9fafc 35%, #eef2ff 100%);
            overflow-x: hidden;
            font-family: "Segoe UI", sans-serif;
        }

        .app-container {
            min-height: 100vh;
            background: transparent;
        }

        .sidebar {
            width: 278px;
            height: 100vh;
            background: var(--sidebar);
            border-right: 1px solid rgba(255,255,255,0.06);
            box-shadow: 14px 0 30px rgba(15, 23, 42, 0.3);
            transition: all 0.35s ease-in-out;
            z-index: 1045;
            position: fixed;
            top: 0;
            left: 0;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: rgba(148,163,184,0.35) transparent;
            justify-content: flex-start !important;
        }

        .sidebar + div {
            width: calc(100% - 278px) !important;
            margin-left: 278px;
        }

        .sidebar::before {
            content: "";
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at top left, rgba(79,110,247,0.28), transparent 36%);
            pointer-events: none;
        }

        .sidebar > * {
            position: relative;
            z-index: 1;
        }

        .sidebar a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            padding: 11px 14px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-radius: 12px;
            transition: all 0.25s ease;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .sidebar-brand {
            padding: 4px 8px 18px;
        }

        .sidebar-brand a {
            padding: 0;
            margin: 0;
        }

        .brand-lockup {
            min-width: 0;
        }

        .sidebar-brand a:hover {
            background: transparent;
            box-shadow: none;
            transform: none;
        }

        .sidebar-brand small {
            display: block;
            color: rgba(255,255,255,0.48);
            font-size: 0.68rem;
            letter-spacing: 0.14em;
            margin: 5px 0 0 38px;
            text-transform: uppercase;
        }

        .menu-label {
            color: rgba(255,255,255,0.42);
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.14em;
            margin: 18px 12px 9px;
            text-transform: uppercase;
        }

        .sidebar a i {
            width: 34px;
            height: 34px;
            min-width: 34px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            text-align: center;
            border-radius: 10px;
            background: linear-gradient(135deg, #4f6ef7, #7c5cff);
            box-shadow: 0 5px 14px rgba(79,110,247,.22);
            transition: color 0.25s ease, transform .25s ease, box-shadow .25s ease, background .25s ease;
        }

        /* Iconos del menú: cada módulo tiene un color propio para identificarlo rápidamente */
        .sidebar .nav-item:nth-child(1) a i { background: linear-gradient(135deg,#4f46e5,#7c3aed); }
        .sidebar .nav-item:nth-child(2) a i { background: linear-gradient(135deg,#ec4899,#f43f5e); }
        .sidebar .nav-item:nth-child(3) a i { background: linear-gradient(135deg,#0ea5e9,#2563eb); }
        .sidebar .nav-item:nth-child(4) a i { background: linear-gradient(135deg,#f59e0b,#f97316); }
        .sidebar .nav-item:nth-child(5) a i { background: linear-gradient(135deg,#10b981,#059669); }
        .sidebar .nav-item:nth-child(6) a i { background: linear-gradient(135deg,#14b8a6,#0d9488); }
        .sidebar .nav-item:nth-child(7) a i { background: linear-gradient(135deg,#06b6d4,#0284c7); }
        .sidebar .nav-item:nth-child(8) a i { background: linear-gradient(135deg,#f97316,#ef4444); }
        .sidebar .nav-item:nth-child(9) a i { background: linear-gradient(135deg,#8b5cf6,#6366f1); }
        .sidebar .nav-item:nth-child(10) a i { background: linear-gradient(135deg,#64748b,#475569); }
        .sidebar .nav-item:nth-child(11) a i { background: linear-gradient(135deg,#f43f5e,#be123c); }
        .sidebar .nav-item:nth-child(12) a i { background: linear-gradient(135deg,#22c55e,#16a34a); }

        .sidebar a:hover i, .sidebar a.active i {
            color: #fff;
            transform: translateY(-1px) scale(1.05);
            box-shadow: 0 8px 18px rgba(15,23,42,.28);
        }

        .sidebar a.active i {
            box-shadow: 0 0 0 2px rgba(255,255,255,.18), 0 8px 22px rgba(15,23,42,.32);
        }

        .sidebar a:hover, .sidebar a.active {
            color: #fff;
            background: linear-gradient(135deg, rgba(79,110,247,0.35), rgba(124,92,255,0.25));
            box-shadow: inset 0 0 0 1px rgba(255,255,255,0.05);
            transform: translateX(3px);
        }

        .sidebar a.active::after {
            content: "";
            width: 4px;
            height: 24px;
            margin-left: auto;
            border-radius: 8px;
            background: #67e8f9;
            box-shadow: 0 0 14px rgba(103,232,249,0.8);
        }

        .sidebar-user {
            padding: 13px 12px;
            margin-top: 12px;
            border: 1px solid rgba(255,255,255,0.09);
            border-radius: 16px;
            background: rgba(255,255,255,0.06);
        }

        .sidebar-user .user-name {
            color: #fff;
            font-size: 0.86rem;
            font-weight: 700;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .sidebar-user .user-role {
            color: rgba(255,255,255,0.48);
            font-size: 0.72rem;
        }

        .sidebar-user a {
            margin-top: 12px;
            padding: 9px 10px;
            color: #fecdd3;
            border: 1px solid rgba(251,113,133,0.28);
            background: rgba(251,113,133,0.08);
        }

        .sidebar-user a:hover {
            background: rgba(251,113,133,0.18);
            box-shadow: none;
            transform: none;
        }

        .nav-pills .nav-item { margin: 0; }

        .navbar {
            background: rgba(255,255,255,0.7) !important;
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(148,163,184,0.15) !important;
            position: sticky;
            top: 0;
            z-index: 10;
            min-height: 70px;
        }

        .navbar-title {
            color: #0f172a;
            font-size: 1rem;
            font-weight: 800;
        }

        .navbar-subtitle {
            color: #64748b;
            display: block;
            font-size: 0.72rem;
            font-weight: 500;
        }

        .tenant-badge {
            align-items: center;
            background: #eff6ff;
            border: 1px solid #dbeafe;
            color: #1d4ed8;
            display: inline-flex;
            gap: 6px;
            padding: 0.55rem 0.85rem;
        }

        .navbar-brand {
            letter-spacing: 0.04em;
        }

        .card {
            border: 1px solid var(--border);
            border-radius: 18px !important;
            box-shadow: 0 10px 20px rgba(15, 23, 42, 0.05);
            transition: transform 0.22s ease, box-shadow 0.22s ease;
            overflow: hidden;
            background: rgba(255,255,255,0.8);
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 18px 30px rgba(15, 23, 42, 0.08);
        }

        .table {
            --bs-table-bg: transparent;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: 14px;
            overflow: hidden;
        }

        .table thead th {
            background: linear-gradient(135deg, #061d8f 0%, #0c34c6 38%, #0d2f9c 100%);
            color: #f8fafc;
            font-size: 0.78rem;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            border-bottom: 1px solid rgba(148,163,184,0.20);
            padding-top: 0.9rem;
            padding-bottom: 0.9rem;
            font-weight: 700;
        }

        .table thead th:first-child {
            border-top-left-radius: 14px;
        }

        .table thead th:last-child {
            border-top-right-radius: 14px;
        }

        .table thead {
            box-shadow: 0 8px 18px rgba(12, 52, 198, 0.18);
        }

        .table tbody td {
            padding-top: 0.85rem;
            padding-bottom: 0.85rem;
            border-color: rgba(148,163,184,0.14);
            background: rgba(255,255,255,0.32);
            vertical-align: middle;
        }

        .table-hover tbody tr:hover td {
            background: rgba(79,110,247,0.04);
        }

        .table-striped > tbody > tr:nth-of-type(odd) > td {
            background: rgba(148,163,184,0.03);
        }

        .table-responsive {
            border-radius: 16px;
            overflow: hidden;
            border: 1px solid rgba(148,163,184,0.18);
            box-shadow: 0 10px 18px rgba(15,23,42,0.04);
        }

        .badge {
            border-radius: 999px;
            padding: 0.45em 0.75em;
            font-weight: 600;
            letter-spacing: 0.02em;
        }

        /* Sistema de iconos coloridos: botones, tarjetas y accesos rápidos */
        .btn i.fa-solid, .btn i.fa-regular, .btn i.fa-brands {
            transition: transform .2s ease, filter .2s ease;
        }
        .btn:hover i.fa-solid, .btn:hover i.fa-regular, .btn:hover i.fa-brands {
            transform: scale(1.08);
        }
        .btn-outline-primary i { color: #2563eb; }
        .btn-outline-success i { color: #16a34a; }
        .btn-outline-danger i { color: #dc2626; }
        .btn-outline-warning i { color: #d97706; }
        .btn-outline-info i { color: #0891b2; }
        .btn-outline-secondary i { color: #475569; }
        .btn-primary i, .btn-success i, .btn-danger i, .btn-warning i, .btn-info i { color: #fff; }
        .card-header i.fa-solid, .card-header i.fa-regular { color: #4f46e5; }

        /* Acciones de tablas: iconos más visibles y compactos */
        .table .btn i {
            font-size: .88rem;
        }
        .table .btn.btn-light i { color: #2563eb; }
        .table .btn.btn-success i { color: #fff; }
        .table .btn.btn-danger i { color: #fff; }
        .table .btn.btn-warning i { color: #fff; }

        /* Botones de navegación móvil */
        #btnToggleSidebar i { color: #2563eb; }
        #btnCloseSidebar i { color: #fb7185; }

        /* Estilos responsivos para tablas en móviles - Ver todo el contenido */
        @media (max-width: 768px) {
            /* Tablas responsivas: mostrar TODO con scroll horizontal */
            .table {
                font-size: 0.70rem;
                margin-bottom: 0;
            }
            
            .table th, .table td {
                padding: 0.35rem 0.25rem !important;
                white-space: nowrap;
            }
            
            .table-responsive {
                border-radius: 12px;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
            
            /* No ocultar columnas: permitir scroll horizontal */
            .table thead,
            .table tbody {
                display: table;
                width: 100%;
            }
            
            /* Botones compactos en móvil */
            .btn-sm {
                padding: 0.25rem 0.4rem;
                font-size: 0.65rem;
            }
            
            /* Botones de acciones ajustados */
            .btn-group {
                gap: 0.15rem;
                flex-wrap: wrap;
                white-space: nowrap;
            }
            
            /* Badge responsive */
            .badge {
                font-size: 0.60rem;
                padding: 0.25rem 0.4rem !important;
            }
        }

        @media (max-width: 991.98px) {
            .app-container { flex-direction: column; }
            .sidebar {
                position: fixed;
                top: 0;
                left: -278px;
                height: 100%;
                box-shadow: 12px 0 24px rgba(15, 23, 42, 0.3);
            }
            .sidebar + div {
                width: 100% !important;
                margin-left: 0;
            }
            .sidebar.show { left: 0; }
            .sidebar-overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                background: rgba(15, 23, 42, 0.45);
                z-index: 1040;
            }
            .sidebar-overlay.show { display: block; }

            /* ESTILOS PARA TARJETAS MÓVILES */
            .card.border-left-primary {
                border-left: 4px solid #4f6ef7;
                border-radius: 0.5rem;
            }
            .card.border-left-primary .card-body {
                padding: 1rem;
            }
        }
    </style>

    <!-- 2. SCRIPTS CORE -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>

</head>

<body>
    <!-- Capa oscura para ocultar el menú al tocar fuera (Móviles) -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="d-flex app-container">
        
        <!-- Sidebar -->
        <aside class="sidebar p-3 d-flex flex-column justify-content-between" id="sidebarMenu">
            <div>
                <div class="sidebar-brand d-flex align-items-center justify-content-between">
                    <div class="brand-lockup">
                        <a href="dashboard" class="d-flex align-items-center text-white text-decoration-none">
                            <i class="fa-solid fa-boxes-stacked fs-4 me-2 text-primary"></i>
                            <span class="fs-5 fw-bold"><?php echo htmlspecialchars(SYSTEM_NAME); ?></span>
                        </a>
                        <small>Gestión inteligente</small>
                    </div>
                    <button class="btn text-white-50 d-lg-none p-0" id="btnCloseSidebar" aria-label="Cerrar menú">
                        <i class="fa-solid fa-xmark fs-4"></i>
                    </button>
                </div>
                <div class="menu-label">Menú principal</div>
                <ul class="nav nav-pills flex-column mb-auto">
                    <?php foreach ($menuItems as $item): ?>
                        <li class="nav-item">
                            <a href="<?php echo $item['ruta']; ?>" class="<?php echo $rutaActual === $item['ruta'] ? 'active' : ''; ?>">
                                <i class="fa-solid <?php echo $item['icono']; ?>"></i>
                                <span><?php echo htmlspecialchars($item['texto']); ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="mt-3">
                <div class="sidebar-user">
                    <div class="user-name"><i class="fa-solid fa-circle-user me-2 text-info"></i><?php echo htmlspecialchars($_SESSION["nombre"] ?? "Usuario"); ?></div>
                    <div class="user-role ms-4"><?php echo htmlspecialchars($_SESSION["perfil"] ?? "Usuario"); ?></div>
                    <a href="salir" class="btn btn-sm w-100"><i class="fa-solid fa-power-off me-1"></i> Cerrar sesión</a>
                </div>
            </div>
        </aside>

        <!-- Contenido principal -->
        <div class="w-100 min-vh-100">
            <!-- Navbar de la Aplicación (con Botón Hamburgesa para móviles) -->
            <nav class="navbar navbar-light bg-white border-bottom px-3 px-lg-4">
                <button class="btn btn-light d-lg-none me-2" id="btnToggleSidebar" aria-label="Abrir menú">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <div>
                    <span class="navbar-title">Panel de administración</span>
                    <span class="navbar-subtitle">Todo bajo control, en un solo lugar</span>
                </div>
            </nav>
            
            <div class="container-fluid p-3 p-md-4">
                <?php
                if (isset($_GET["ruta"])) {
                    $ruta = $_GET["ruta"];
                    if (in_array(
                        $ruta, ["dashboard",
                        "categorias",
                        "productos",
                        "compras",
                        "ventas", 
                        "caja", 
                        "historial-ventas",
                        "facturacion", 
                        "clientes",
                        "proveedores",
                        "reportes", 
                        "usuarios", 
                        "salir"])) 
                    {
                        include "vistas/modulos/" . $ruta . ".php";
                    } else {
                        include "vistas/modulos/404.php";
                    }
                } else {
                    include "vistas/modulos/dashboard.php";
                }
                ?>
            </div>
        </div>
    </div>

    <!-- SCRIPT JS PARA EL CONTROL DEL MENÚ RESPONSIVE -->
    <script>
        $(document).ready(function() {
            // Abrir / Cerrar Menú
            $('#btnToggleSidebar, #btnCloseSidebar, #sidebarOverlay').on('click', function() {
                $('#sidebarMenu').toggleClass('show');
                $('#sidebarOverlay').toggleClass('show');
            });

            $('#sidebarMenu a:not([href="salir"])').on('click', function() {
                $('#sidebarMenu, #sidebarOverlay').removeClass('show');
            });
        });
    </script>
</body>
</html>