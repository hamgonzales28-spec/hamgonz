<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ingreso - <?php echo SYSTEM_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --violet: #8b5cf6;
            --blue: #3b82f6;
            --cyan: #22d3ee;
            --pink: #ec4899;
            --lime: #a3e635;
            --amber: #fbbf24;
            --red: #fb7185;
            --dark-1: #0f172a;
            --dark-2: #1e293b;
            --glass: rgba(255,255,255,0.72);
            --muted: #475569;
        }

        * { box-sizing: border-box; }

        html, body {
            margin: 0;
            height: 100%;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background:
                radial-gradient(circle at 15% 15%, rgba(236, 72, 153, 0.28), transparent 18%),
                radial-gradient(circle at 80% 10%, rgba(59, 130, 246, 0.28), transparent 22%),
                radial-gradient(circle at 55% 80%, rgba(34, 211, 238, 0.26), transparent 22%),
                linear-gradient(135deg, #fef3c7 0%, #dbeafe 22%, #f5f3ff 50%, #ecfeff 100%);
            font-family: "Segoe UI", sans-serif;
            overflow: hidden;
            position: relative;
        }

        .bg-orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(20px);
            opacity: 0.7;
            animation: drift 14s ease-in-out infinite alternate;
            pointer-events: none;
        }

        .bg-orb.one {
            width: 260px; height: 260px;
            background: rgba(236, 72, 153, 0.18);
            left: 8%; top: 10%;
        }

        .bg-orb.two {
            width: 220px; height: 220px;
            background: rgba(59, 130, 246, 0.18);
            right: 12%; top: 18%;
            animation-delay: 1s;
        }

        .bg-orb.three {
            width: 300px; height: 300px;
            background: rgba(34, 211, 238, 0.18);
            left: 45%; bottom: 6%;
            animation-delay: 1.6s;
        }

        @keyframes drift {
            0% { transform: translateY(0px) translateX(0px) scale(1); }
            100% { transform: translateY(-26px) translateX(20px) scale(1.08); }
        }

        .login-shell {
            position: relative;
            z-index: 1;
            width: min(96vw, 1000px);
            display: grid;
            grid-template-columns: 1.08fr 0.92fr;
            border-radius: 32px;
            overflow: hidden;
            background: rgba(255,255,255,0.72);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(148,163,184,0.18);
            box-shadow: 0 30px 80px rgba(30,41,59,0.12);
        }

        .login-info {
            padding: 48px 42px;
            background: linear-gradient(135deg, #0f172a 0%, #1d4ed8 32%, #8b5cf6 62%, #ec4899 100%);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .tag {
            display: inline-flex;
            align-items: center;
            width: fit-content;
            padding: 0.62rem 0.9rem;
            border-radius: 999px;
            background: rgba(255,255,255,0.12);
            border: 1px solid rgba(255,255,255,0.18);
            color: #ffffff;
            font-size: 0.72rem;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            font-weight: 700;
        }

        .login-info h1 {
            margin-top: 1.2rem;
            margin-bottom: 0.8rem;
            font-size: clamp(2.2rem, 3vw, 3.4rem);
            line-height: 1.02;
            font-weight: 900;
            color: white;
        }

        .login-info p {
            margin: 0;
            color: #e0f2fe;
            font-size: 1.02rem;
            line-height: 1.8;
            max-width: 520px;
        }

        .login-visual {
            display: flex;
            align-items: flex-end;
            gap: 0.55rem;
            height: 92px;
            margin-top: 1.8rem;
            padding: 1rem 1.1rem 0;
            border-radius: 20px;
            background: linear-gradient(180deg, rgba(255,255,255,0.13), rgba(255,255,255,0.04));
            border: 1px solid rgba(255,255,255,0.18);
            box-shadow: inset 0 1px rgba(255,255,255,0.12);
        }

        .chart-bar {
            flex: 1;
            min-width: 12px;
            height: var(--bar-height);
            border-radius: 8px 8px 3px 3px;
            background: linear-gradient(180deg, #a5f3fc, #38bdf8 48%, #8b5cf6);
            box-shadow: 0 0 14px rgba(165,243,252,0.35);
            animation: chart-rise 0.9s ease both;
        }

        .chart-bar:nth-child(2) { animation-delay: 0.08s; }
        .chart-bar:nth-child(3) { animation-delay: 0.16s; }
        .chart-bar:nth-child(4) { animation-delay: 0.24s; }
        .chart-bar:nth-child(5) { animation-delay: 0.32s; }
        .chart-bar:nth-child(6) { animation-delay: 0.4s; }

        @keyframes chart-rise {
            from { opacity: 0; transform: scaleY(0); transform-origin: bottom; }
            to { opacity: 1; transform: scaleY(1); transform-origin: bottom; }
        }

        .stats {
            margin-top: 2rem;
            display: grid;
            grid-template-columns: repeat(3, minmax(100px, 1fr));
            gap: 0.85rem;
        }

        .stat {
            padding: 0.9rem 0.8rem;
            border-radius: 18px;
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.12);
        }

        .stat strong {
            display: block;
            font-size: 1.12rem;
            color: white;
            margin-bottom: 0.2rem;
        }

        .stat span {
            color: #bae6fd;
            font-size: 0.74rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        .auth-card {
            position: relative;
            padding: 2.1rem 1.5rem;
            background: rgba(255,255,255,0.80);
            display: flex;
            align-items: center;
            justify-content: center;
            animation: rise 0.8s ease both;
        }

        @keyframes rise {
            from { opacity: 0; transform: translateY(18px) scale(0.98); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        .auth-box {
            width: min(100%, 360px);
        }

        .brand-badge {
            width: 86px;
            height: 86px;
            margin: 0 auto 1rem;
            display: grid;
            place-items: center;
            border-radius: 24px;
            background: linear-gradient(135deg, var(--amber), var(--pink), var(--violet), var(--blue));
            box-shadow: 0 18px 30px rgba(139,92,246,0.22);
        }

        .brand-badge i {
            font-size: 2rem;
            color: white;
        }

        .auth-card h4 {
            color: #1d4ed8;
            font-weight: 900;
            letter-spacing: 0.3px;
            margin-bottom: 0.25rem;
        }

        .auth-card .subtitle {
            color: var(--muted);
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }

        .input-group-text {
            background: #eff6ff;
            border: 1px solid rgba(148,163,184,0.35);
            border-right: none;
            color: #7c3aed;
            padding-left: 1rem;
        }

        .form-control {
            background: #ffffff;
            color: #0f172a;
            border: 1px solid rgba(148,163,184,0.35);
            border-left: none;
            height: 50px;
            transition: all 0.2s ease;
        }

        .form-control::placeholder {
            color: #94a3b8;
        }

        .form-control:focus {
            box-shadow: 0 0 0 0.2rem rgba(59,130,246,0.14);
            background: white;
            color: #0f172a;
        }

        .btn-login {
            border: none;
            border-radius: 16px;
            height: 52px;
            font-weight: 700;
            background: linear-gradient(135deg, #f59e0b, #ec4899, #8b5cf6, #3b82f6);
            box-shadow: 0 18px 28px rgba(59,130,246,0.22);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            letter-spacing: 0.02em;
        }

        .btn-login:hover {
            transform: translateY(-1px);
            box-shadow: 0 20px 32px rgba(139,92,246,0.26);
        }

        label {
            color: #334155;
            font-weight: 600;
            margin-bottom: 0.55rem;
        }

        @media (max-width: 820px) {
            body {
                overflow: auto;
                padding: 2rem 1rem;
            }

            .login-shell {
                grid-template-columns: 1fr;
                width: min(100%, 520px);
            }

            .login-info {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="bg-orb one"></div>
    <div class="bg-orb two"></div>
    <div class="bg-orb three"></div>

    <div class="login-shell">
        <div class="login-info">
            <div class="tag"><i class="fa-solid fa-sparkles me-2"></i>Ham_G Tech</div>
            <h1><?php echo SYSTEM_NAME; ?></h1>
            <p>Gestiona ventas, inventario, clientes y caja desde una plataforma rápida, clara y llena de energía.</p>

            <div class="login-visual" aria-label="Gráfica decorativa de crecimiento">
                <span class="chart-bar" style="--bar-height: 34%"></span>
                <span class="chart-bar" style="--bar-height: 52%"></span>
                <span class="chart-bar" style="--bar-height: 43%"></span>
                <span class="chart-bar" style="--bar-height: 72%"></span>
                <span class="chart-bar" style="--bar-height: 61%"></span>
                <span class="chart-bar" style="--bar-height: 88%"></span>
            </div>

            <div class="stats">
                <div class="stat">
                    <strong>24/7</strong>
                    <span>Control</span>
                </div>
                <div class="stat">
                    <strong>+120</strong>
                    <span>Productos</span>
                </div>
                <div class="stat">
                    <strong>99%</strong>
                    <span>Rendimiento</span>
                </div>
            </div>
        </div>

        <div class="auth-card">
            <div class="auth-box">
                <div class="text-center mb-4">
                    <div class="brand-badge">
                        <i class="fa-solid fa-boxes-stacked"></i>
                    </div>
                    <h4><?php echo SYSTEM_NAME; ?></h4>
                    <p class="subtitle">Acceso al sistema</p>
                </div>

                <form method="post" autocomplete="on">
                    <div class="mb-3">
                        <label>Usuario</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fa-solid fa-user"></i></span>
                            <input type="text" class="form-control" name="ingUsuario" placeholder="Ej: admin" required autofocus>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label>Contraseña</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fa-solid fa-key"></i></span>
                            <input type="password" class="form-control" name="ingPassword" placeholder="••••••••" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-login w-100">
                        <i class="fa-solid fa-right-to-bracket me-2"></i>Ingresar
                    </button>
                    <?php ControladorAuth::ctrIngresoUsuario(); ?>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>