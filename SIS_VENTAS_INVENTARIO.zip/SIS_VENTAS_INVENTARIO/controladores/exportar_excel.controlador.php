<?php
class ControladorExportarExcel {
    public static function ctrExportarExcel() {
        if (!isset($_SESSION["iniciarSesion"]) || $_SESSION["iniciarSesion"] !== "ok") {
            header("Location: " . BASE_URL . "login");
            exit();
        }

        header("Content-Type: application/vnd.ms-excel; charset=utf-8");
        header("Content-Disposition: attachment; filename=reporte_inventario_" . date('Y-m-d') . ".xls");
        header("Pragma: no-cache");
        header("Expires: 0");

        echo "\xEF\xBB\xBF"; // UTF-8 BOM

        $stmt = Conexion::conectar()->prepare("SELECT * FROM productos ORDER BY id DESC");
        $stmt->execute();
        $productos = $stmt->fetchAll();

        echo "<table border='1'>";
        echo "<tr style='background-color:#0d6efd; color:#ffffff;'>";
        echo "<th>ID</th><th>Código</th><th>Descripción</th><th>Stock</th><th>Precio Venta (S/)</th>";
        echo "</tr>";

        foreach ($productos as $p) {
            echo "<tr>";
            echo "<td>{$p['id']}</td>";
            echo "<td>{$p['codigo']}</td>";
            echo "<td>{$p['descripcion']}</td>";
            echo "<td>{$p['stock']}</td>";
            echo "<td>S/ " . number_format($p['precio_venta'], 2) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        exit();
    }
}