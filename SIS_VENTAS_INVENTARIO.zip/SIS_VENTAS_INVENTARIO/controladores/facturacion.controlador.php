<?php
require_once __DIR__ . "/../modelos/facturacion.modelo.php";
require_once __DIR__ . "/../modelos/ventas.modelo.php";

class ControladorFacturacion {
    public static function ctrConfig() {
        try {
            return ModeloFacturacion::config();
        } catch (Throwable $e) {
            return ['__error' => $e->getMessage()];
        }
    }

    public static function ctrGuardarConfig() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['guardarSunat'])) return;
        $datos = [
            'ruc'=>trim($_POST['ruc'] ?? ''), 'razon_social'=>trim($_POST['razon_social'] ?? ''),
            'nombre_comercial'=>trim($_POST['nombre_comercial'] ?? ''), 'direccion'=>trim($_POST['direccion'] ?? ''),
            'ubigeo'=>trim($_POST['ubigeo'] ?? ''), 'departamento'=>trim($_POST['departamento'] ?? ''),
            'provincia'=>trim($_POST['provincia'] ?? ''), 'distrito'=>trim($_POST['distrito'] ?? ''),
            'sol_usuario'=>trim($_POST['sol_usuario'] ?? ''), 'sol_clave'=>$_POST['sol_clave'] ?? '',
            'certificado_path'=>trim($_POST['certificado_path'] ?? ''), 'certificado_clave'=>$_POST['certificado_clave'] ?? '',
            'ambiente'=>($_POST['ambiente'] ?? 'beta') === 'produccion' ? 'produccion' : 'beta',
            'serie_factura'=>strtoupper(trim($_POST['serie_factura'] ?? 'F001')), 'serie_boleta'=>strtoupper(trim($_POST['serie_boleta'] ?? 'B001')),
            'igv'=>(float)($_POST['igv'] ?? 18), 'activo'=>isset($_POST['activo']) ? 1 : 0
        ];

        try {
            $resp = ModeloFacturacion::guardarConfig($datos);
            $ok = $resp === 'ok';
            echo '<script>Swal.fire({icon:"'.($ok?'success':'error').'",title:"'.($ok?'Configuración guardada':'Error'). '",text:"'.($ok?'SUNAT quedó configurado.':'No se pudo guardar la configuración.').'"});</script>';
        } catch (Throwable $e) {
            $texto = json_encode($e->getMessage(), JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP);
            echo '<script>Swal.fire({icon:"error",title:"No se pudo guardar la configuración",html:'.$texto.'});</script>';
        }
    }
}
