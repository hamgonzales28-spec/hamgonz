<?php

class ControladorCaja {

    /*=============================================
    PROCESAR APERTURA DE CAJA
    =============================================*/
    public static function ctrAbrirCaja() {
        if (isset($_POST["montoInicial"])) {
            $idUsuario = isset($_SESSION["id"]) ? $_SESSION["id"] : 1;
            
            $datos = array(
                "id_usuario" => $idUsuario,
                "monto_inicial" => $_POST["montoInicial"]
            );

            $respuesta = ModeloCaja::mdlAbrirCaja($datos);

            if ($respuesta == "ok") {
                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡Caja Aperturada!",
                        text: "Se ha registrado el saldo inicial correctamente.",
                        confirmButtonText: "Continuar"
                    }).then(function(){
                        window.location = "caja";
                    });
                </script>';
            }
        }
    }

    /*=============================================
    PROCESAR CIERRE DE CAJA (ARQUEO)
    =============================================*/
    public static function ctrCerrarCaja() {
        if (isset($_POST["montoReal"])) {
            
            $idCaja = $_POST["idCaja"];
            $montoInicial = floatval($_POST["montoInicialOculto"]);
            $ventasEfectivo = floatval($_POST["ventasEfectivoOculto"]);
            
            // 1. Obtener compras en efectivo (desde input oculto o directamente desde el Modelo)
            if (isset($_POST["comprasEfectivoOculto"])) {
                $comprasEfectivo = floatval($_POST["comprasEfectivoOculto"]);
            } else {
                // Si tienes la fecha de apertura, la consultas directamente
                $cajaActiva = ModeloCaja::mdlObtenerCajaAbierta($_SESSION["id"] ?? 1);
                $comprasEfectivo = ModeloCaja::mdlObtenerComprasEfectivo($cajaActiva["fecha_apertura"]);
            }

            $montoReal = floatval($_POST["montoReal"]);

            // 2. FÓRMULA CORREGIDA (Resta compras)
            $montoEsperado = ($montoInicial + $ventasEfectivo) - $comprasEfectivo;
            $diferencia = $montoReal - $montoEsperado;

            // 3. Preparar matriz para ModeloCaja::mdlCerrarCaja
            $datos = array(
                "id_caja"          => $idCaja,
                "ventas_efectivo"  => $ventasEfectivo,
                "compras_efectivo" => $comprasEfectivo,
                "esperado"         => $montoEsperado,
                "real"             => $montoReal,
                "diferencia"       => $diferencia
            );

            $respuesta = ModeloCaja::mdlCerrarCaja($datos);

            if ($respuesta == "ok") {
                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡Caja Cerrada Exitosamente!",
                        html: "<div class=\"text-start ms-4\">" +
                              "<b>(+) Monto Inicial:</b> S/ ' . number_format($montoInicial, 2) . '<br>" +
                              "<b>(+) Ventas Efectivo:</b> S/ ' . number_format($ventasEfectivo, 2) . '<br>" +
                              "<b>(-) Compras Efectivo:</b> S/ ' . number_format($comprasEfectivo, 2) . '<hr class=\"my-1\">" +
                              "<b>Esperado en caja:</b> S/ ' . number_format($montoEsperado, 2) . '<br>" +
                              "<b>Contado en efectivo:</b> S/ ' . number_format($montoReal, 2) . '<br>" +
                              "<b>Diferencia:</b> S/ ' . number_format($diferencia, 2) . '</div>",
                        confirmButtonText: "Aceptar"
                    }).then(function(){
                        window.location = "caja";
                    });
                </script>';
            }
        }
    }
}