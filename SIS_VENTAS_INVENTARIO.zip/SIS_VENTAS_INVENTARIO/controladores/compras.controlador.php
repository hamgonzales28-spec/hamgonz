<?php

class ControladorCompras {

    /*=============================================
    MOSTRAR COMPRAS
    =============================================*/
    static public function ctrMostrarCompras($item, $valor) {
        $tabla = "compras";
        return ModeloCompras::mdlMostrarCompras($tabla, $item, $valor);
    }

    /*=============================================
    CREAR COMPRA, DETALLE, ACTUALIZAR STOCK Y CAJA
    =============================================*/
    static public function ctrCrearCompra() {

        if (isset($_POST["nuevaCompra"])) {

            /* 1. Guardar la compra general */
            $tablaCompras = "compras";
            $datosCompra = array(
                "codigo" => $_POST["nuevaCompra"],
                "proveedor" => $_POST["nuevoProveedor"],
                "metodo_pago" => $_POST["nuevoMetodoPago"],
                "total" => $_POST["totalCompra"]
            );

            $listaProductos = json_decode($_POST["listaProductos"] ?? "", true);

            // Validación del servidor: nunca registrar una compra sin productos.
            if (!is_array($listaProductos) || count($listaProductos) === 0) {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "Compra inválida",
                        text: "Debe agregar al menos un producto antes de guardar la compra.",
                        confirmButtonText: "Cerrar"
                    });
                </script>';
                return;
            }

            // Normalizar cantidades/precios y calcular el total real a partir del detalle.
            $totalCalculado = 0;
            $listaValida = [];

            foreach ($listaProductos as $producto) {
                $idProducto = filter_var($producto["id"] ?? null, FILTER_VALIDATE_INT);
                $cantidad = (int) ($producto["cantidad"] ?? 0);
                $precio = (float) ($producto["precio"] ?? 0);

                if (!$idProducto || $cantidad <= 0 || $precio < 0) {
                    continue;
                }

                $totalItem = round($cantidad * $precio, 2);
                $producto["id"] = $idProducto;
                $producto["cantidad"] = $cantidad;
                $producto["precio"] = $precio;
                $producto["total"] = $totalItem;
                $totalCalculado += $totalItem;
                $listaValida[] = $producto;
            }

            if (count($listaValida) === 0 || $totalCalculado <= 0) {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "Compra inválida",
                        text: "Los productos, cantidades y precios de la compra no son válidos.",
                        confirmButtonText: "Cerrar"
                    });
                </script>';
                return;
            }

            $datosCompra["total"] = number_format($totalCalculado, 2, ".", "");
            $idCompra = ModeloCompras::mdlIngresarCompra($tablaCompras, $datosCompra);

            if ($idCompra != "error") {

                $listaProductos = $listaValida;

                if (is_array($listaProductos)) {
                    foreach ($listaProductos as $key => $value) {

                        /* 2. Guardar el detalle (Precio unidad y Total por producto) */
                        $tablaDetalle = "detalle_compras";
                        $datosDetalle = array(
                            "id_compra" => $idCompra,
                            "id_producto" => $value["id"],
                            "cantidad" => $value["cantidad"],
                            "precio_unitario" => $value["precio"],
                            "total_producto" => $value["total"]
                        );

                        ModeloCompras::mdlIngresarDetalleCompra($tablaDetalle, $datosDetalle);

                        /* 3. Actualizar Stock y Precio de Compra en el Producto */
                        $tablaProductos = "productos";
                        $traerProducto = ModeloProductos::mdlMostrarProductos($tablaProductos, "id", $value["id"]);

                        if (!$traerProducto) {
                            continue;
                        }

                        $nuevoStock = (int) $traerProducto["stock"] + (int) $value["cantidad"];
                        $nuevoPrecioCompra = $value["precio"];

                        $stmt = Conexion::conectar()->prepare("UPDATE $tablaProductos SET stock = :stock, precio_compra = :precio_compra WHERE id = :id");
                        $stmt->bindParam(":stock", $nuevoStock, PDO::PARAM_INT);
                        $stmt->bindParam(":precio_compra", $nuevoPrecioCompra, PDO::PARAM_STR);
                        $stmt->bindParam(":id", $value["id"], PDO::PARAM_INT);
                        $stmt->execute();
                    }
                }

                /* 4. IMPACTO EN CAJA CHICA (Solo si el pago fue en Efectivo) */
                if ($_POST["nuevoMetodoPago"] == "Efectivo") {
                    
                    // Se busca la caja con estado 'abierta'
                    $stmtCaja = Conexion::conectar()->prepare("SELECT * FROM cajas WHERE estado = 'abierta' ORDER BY id DESC LIMIT 1");
                    $stmtCaja->execute();
                    $cajaAbierta = $stmtCaja->fetch(PDO::FETCH_ASSOC);

                    if ($cajaAbierta) {
                        $idCaja = $cajaAbierta["id"];
                        $montoCompra = floatval($_POST["totalCompra"]);
                        
                        // Sumar la compra al acumulado de compras en efectivo
                        $montoComprasEfectivoActual = floatval($cajaAbierta["monto_compras_efectivo"] ?? 0);
                        $nuevoMontoComprasEfectivo = $montoComprasEfectivoActual + $montoCompra;

                        // Recalcular el monto final esperado: (Monto Inicial + Ventas Efectivo) - Compras Efectivo
                        $montoInicial = floatval($cajaAbierta["monto_inicial"] ?? 0);
                        $montoVentas = floatval($cajaAbierta["monto_ventas_efectivo"] ?? 0);
                        $nuevoMontoEsperado = ($montoInicial + $montoVentas) - $nuevoMontoComprasEfectivo;

                        // Actualizar la caja activa
                        $stmtUpdateCaja = Conexion::conectar()->prepare("UPDATE cajas SET monto_compras_efectivo = :monto_compras, monto_final_esperado = :monto_esperado WHERE id = :id");
                        $stmtUpdateCaja->bindParam(":monto_compras", $nuevoMontoComprasEfectivo, PDO::PARAM_STR);
                        $stmtUpdateCaja->bindParam(":monto_esperado", $nuevoMontoEsperado, PDO::PARAM_STR);
                        $stmtUpdateCaja->bindParam(":id", $idCaja, PDO::PARAM_INT);
                        $stmtUpdateCaja->execute();
                    }
                }

                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡Compra registrada con éxito!",
                        text: "Se guardó la compra, el stock fue actualizado y se descontó del saldo de Caja Chica.",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    }).then(function(result){
                        if (result.value) {
                            window.location = "compras";
                        }
                    });
                </script>';
            } else {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "No se pudo registrar la compra",
                        text: "La compra no fue guardada en la base de datos.",
                        confirmButtonText: "Cerrar"
                    });
                </script>';
            }
        }
    }

    /*=============================================
    SUMA TOTAL COMPRAS
    =============================================*/
    static public function ctrSumaTotalCompras() {
        $tabla = "compras";
        $respuesta = ModeloCompras::mdlSumaTotalCompras($tabla);
        return $respuesta["total"] ?? 0;
    }

}