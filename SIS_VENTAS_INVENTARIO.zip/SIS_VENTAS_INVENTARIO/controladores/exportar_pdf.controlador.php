<?php
class ControladorExportarPdf {
    public static function ctrExportarPdf() {
        // Estructura lista para implementar librerías como FPDF o Dompdf
        if (!isset($_SESSION["iniciarSesion"]) || $_SESSION["iniciarSesion"] !== "ok") {
            header("Location: " . BASE_URL . "login");
            exit();
        }
    }
}