<?php

class ControladorProveedores {

    /*=============================================
    MOSTRAR PROVEEDORES
    =============================================*/
    public static function ctrMostrarProveedores($item, $valor) {
        $tabla = "proveedores";
        return ModeloProveedores::mdlMostrarProveedores($tabla, $item, $valor);
    }

    /*=============================================
    CREAR PROVEEDOR
    =============================================*/
    public static function ctrCrearProveedor() {
        if (isset($_POST["nuevaRazonSocial"])) {

            $tabla = "proveedores";
            $datos = array(
                "doc_identidad" => $_POST["nuevoDocIdentidad"],
                "ruc"          => $_POST["nuevoRuc"],
                "razon_social" => $_POST["nuevaRazonSocial"],
                "contacto"     => $_POST["nuevoContacto"],
                "telefono"     => $_POST["nuevoTelefono"],
                "email"        => $_POST["nuevoEmail"],
                "direccion"    => $_POST["nuevaDireccion"]
            );

            $respuesta = ModeloProveedores::mdlIngresarProveedor($tabla, $datos);

            if ($respuesta == "ok") {
                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡Proveedor registrado con éxito!",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    }).then(function(result){
                        if (result.value) {
                            window.location = "proveedores";
                        }
                    });
                </script>';
            }
        }
    }

    /*=============================================
    EDITAR PROVEEDOR
    =============================================*/
    public static function ctrEditarProveedor() {
        if (isset($_POST["editarRazonSocial"])) {

            $tabla = "proveedores";
            $datos = array(
                "id"           => $_POST["idProveedor"],
                "doc_identidad" => $_POST["editarDocIdentidad"],
                "ruc"          => $_POST["editarRuc"],
                "razon_social" => $_POST["editarRazonSocial"],
                "contacto"     => $_POST["editarContacto"],
                "telefono"     => $_POST["editarTelefono"],
                "email"        => $_POST["editarEmail"],
                "direccion"    => $_POST["editarDireccion"]
            );

            $respuesta = ModeloProveedores::mdlEditarProveedor($tabla, $datos);

            if ($respuesta == "ok") {
                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡Proveedor actualizado con éxito!",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    }).then(function(result){
                        if (result.value) {
                            window.location = "proveedores";
                        }
                    });
                </script>';
            }
        }
    }

    /*=============================================
    BORRAR PROVEEDOR
    =============================================*/
    public static function ctrBorrarProveedor() {
        if (isset($_GET["idProveedor"])) {

            $tabla = "proveedores";
            $datos = $_GET["idProveedor"];

            $respuesta = ModeloProveedores::mdlBorrarProveedor($tabla, $datos);

            if ($respuesta == "ok") {
                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡Proveedor eliminado correctamente!",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    }).then(function(result){
                        if (result.value) {
                            window.location = "proveedores";
                        }
                    });
                </script>';
            }
        }
    }
}