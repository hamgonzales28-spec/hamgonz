<?php
class ControladorProductos {

    public static function ctrMostrarProductos($item, $valor) {
        return ModeloProductos::mdlMostrarProductos('productos', $item, $valor);
    }

    private static function limpiarCodigoBarras($valor) {
        $valor = trim((string)$valor);
        if ($valor === '') return null;
        return preg_replace('/\s+/', '', $valor);
    }

    private static function validarDatos($categoria, $descripcion, $stock, $precio) {
        if (!is_numeric($categoria) || (int)$categoria <= 0) return 'Selecciona una categoría válida.';
        if (trim((string)$descripcion) === '') return 'La descripción es obligatoria.';
        if (!is_numeric($stock) || (int)$stock < 0) return 'El stock debe ser mayor o igual a 0.';
        if (!is_numeric($precio) || (float)$precio < 0) return 'El precio debe ser mayor o igual a 0.';
        return null;
    }

    private static function validarCodigoBarras($codigo, $tabla, $id=null) {
        if ($codigo === null) return null;
        if (!preg_match('/^[A-Za-z0-9._-]{4,50}$/', $codigo)) return 'El código de barras debe tener entre 4 y 50 caracteres y no contener espacios.';
        if (ModeloProductos::mdlExisteCodigoBarras($tabla, $codigo, $id)) return 'Ese código de barras ya está asignado a otro producto.';
        return null;
    }

    private static function alerta($icon, $titulo, $texto='') {
        echo '<script>Swal.fire({icon:'.json_encode($icon).',title:'.json_encode($titulo).',text:'.json_encode($texto).',confirmButtonText:"Cerrar"});</script>';
    }

    public static function ctrCrearProducto() {
        if (!isset($_POST['nuevaDescripcion'], $_POST['nuevaCategoria'])) return;

        $tabla='productos';
        $error=self::validarDatos($_POST['nuevaCategoria'],$_POST['nuevaDescripcion'],$_POST['nuevoStock'] ?? 0,$_POST['nuevoPrecioVenta'] ?? 0);
        if ($error) { self::alerta('warning','No se puede guardar',$error); return; }

        // Siempre se genera en servidor para evitar códigos vacíos o repetidos.
        $codigo=ModeloProductos::mdlGenerarCodigoProducto($tabla);
        $codigoBarras=self::limpiarCodigoBarras($_POST['nuevoCodigoBarras'] ?? '');
        $error=self::validarCodigoBarras($codigoBarras,$tabla);
        if ($error) { self::alerta('warning','Código de barras no válido',$error); return; }

        $datos=[
            'id_categoria'=>(int)$_POST['nuevaCategoria'],
            'codigo'=>$codigo,
            'codigo_barras'=>$codigoBarras,
            'descripcion'=>trim((string)$_POST['nuevaDescripcion']),
            'unidad_medida'=>trim((string)($_POST['nuevaUnidadMedida'] ?? 'Unidad')) ?: 'Unidad',
            'stock'=>(int)$_POST['nuevoStock'],
            'precio_venta'=>(float)$_POST['nuevoPrecioVenta']
        ];

        $respuesta=ModeloProductos::mdlIngresarProducto($tabla,$datos);
        if ($respuesta==='ok') {
            $mensaje=json_encode('Código interno: '.$codigo);
            echo '<script>Swal.fire({icon:"success",title:"Producto guardado correctamente",text:'.$mensaje.',confirmButtonText:"Continuar"}).then(function(){window.location="productos";});</script>';
        } else {
            self::alerta('error','No se pudo guardar el producto','Verifica los datos y que el código de barras no esté siendo usado.');
        }
    }

    public static function ctrEditarProducto() {
        if (!isset($_POST['idProducto'],$_POST['editarDescripcion'])) return;

        $tabla='productos';
        $id=(int)$_POST['idProducto'];
        if ($id<=0) { self::alerta('error','Producto inválido'); return; }

        $error=self::validarDatos($_POST['editarCategoria'] ?? 0,$_POST['editarDescripcion'],$_POST['editarStock'] ?? 0,$_POST['editarPrecioVenta'] ?? 0);
        if ($error) { self::alerta('warning','No se puede actualizar',$error); return; }

        $actual=ModeloProductos::mdlMostrarProductos($tabla,'id',$id);
        if (!$actual) { self::alerta('error','Producto no encontrado'); return; }
        $codigo=trim((string)($_POST['editarCodigo'] ?? '')) ?: $actual['codigo'];

        $codigoBarras=self::limpiarCodigoBarras($_POST['editarCodigoBarras'] ?? '');
        $error=self::validarCodigoBarras($codigoBarras,$tabla,$id);
        if ($error) { self::alerta('warning','Código de barras no válido',$error); return; }

        $datos=[
            'id'=>$id,
            'codigo'=>$codigo,
            'codigo_barras'=>$codigoBarras,
            'id_categoria'=>(int)$_POST['editarCategoria'],
            'descripcion'=>trim((string)$_POST['editarDescripcion']),
            'unidad_medida'=>trim((string)($_POST['editarUnidadMedida'] ?? 'Unidad')) ?: 'Unidad',
            'stock'=>(int)$_POST['editarStock'],
            'precio_venta'=>(float)$_POST['editarPrecioVenta']
        ];

        $respuesta=ModeloProductos::mdlEditarProducto($tabla,$datos);
        if ($respuesta==='ok') {
            echo '<script>Swal.fire({icon:"success",title:"Producto actualizado correctamente",confirmButtonText:"Continuar"}).then(function(){window.location="productos";});</script>';
        } else {
            self::alerta('error','No se pudo actualizar el producto','Verifica los datos y que el código de barras no esté siendo usado.');
        }
    }

    public static function ctrBorrarProducto() {
        if (isset($_GET['idProducto'])) {
            $respuesta=ModeloProductos::mdlBorrarProducto('productos',$_GET['idProducto']);
            if ($respuesta==='ok') echo '<script>Swal.fire({icon:"success",title:"Producto eliminado correctamente",confirmButtonText:"Cerrar"}).then(function(){window.location="productos";});</script>';
            else self::alerta('error','No se pudo eliminar el producto');
        }
    }
}
