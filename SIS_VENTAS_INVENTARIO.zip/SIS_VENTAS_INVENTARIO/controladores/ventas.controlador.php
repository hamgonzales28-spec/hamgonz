<?php

class ControladorVentas {

    public static function ctrGuardarComprobanteLocal($codigoFactura) {
        $rutaTickets = __DIR__ . "/../vistas/tickets";
        if (!file_exists($rutaTickets) && !mkdir($rutaTickets, 0777, true)) {
            return '';
        }

        $archivoPdf = $rutaTickets . "/Ticket_" . $codigoFactura . ".pdf";
        $urlPdf = rtrim(BASE_URL, '/') . '/vistas/modulos/imprimir_comprobante.php?codigo=' . rawurlencode($codigoFactura) . '&no_drive=1';
        $contextoPdf = stream_context_create(['http' => ['timeout' => 8]]);
        $contenido = @file_get_contents($urlPdf, false, $contextoPdf);

        if ($contenido === false || strncmp($contenido, '%PDF', 4) !== 0 || file_put_contents($archivoPdf, $contenido) === false) {
            return '';
        }

        return rtrim(BASE_URL, '/') . '/vistas/tickets/Ticket_' . rawurlencode($codigoFactura) . '.pdf';
    }

    /*=============================================
    ENLACE PÚBLICO DEL COMPROBANTE (WhatsApp - opción A)
    =============================================*/
    public static function ctrGenerarEnlaceComprobante($codigoFactura) {
        // Si se configuró un dominio público, usarlo para WhatsApp.
        if (defined('PUBLIC_BASE_URL') && trim(PUBLIC_BASE_URL) !== '') {
            $base = rtrim(PUBLIC_BASE_URL, '/');
        } else {
            // En local conserva BASE_URL. Para que el cliente lo abra desde su celular
            // el sistema debe publicarse en Internet o usar una IP accesible desde el celular.
            $base = rtrim(BASE_URL, '/');
        }
        return $base . '/comprobante.php?codigo=' . rawurlencode($codigoFactura);
    }

    public static function ctrNormalizarTelefonoWhatsApp($telefono) {
        $telefono = preg_replace('/[^0-9]/', '', (string)$telefono);
        if (strlen($telefono) === 9 && substr($telefono, 0, 1) === '9') return '51' . $telefono;
        if (strlen($telefono) === 10 && substr($telefono, 0, 1) === '9') return '51' . $telefono;
        return $telefono;
    }

    /*=============================================
    REGISTRAR VENTA
    =============================================*/
    public static function ctrCrearVenta() {

        // Validamos si se recibe la lista por listaProductosJSON o listaProductos
        if (isset($_POST["listaProductosJSON"]) || isset($_POST["listaProductos"])) {

            // 1. Verificación de seguridad de Caja
            $idUsuario = isset($_SESSION["id"]) ? $_SESSION["id"] : 1;
            $cajaAbierta = ModeloCaja::mdlObtenerCajaAbierta($idUsuario);

            if (!$cajaAbierta) {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "Acción Denegada",
                        text: "No hay una caja chica abierta. Abra la caja antes de registrar ventas.",
                        confirmButtonText: "Ir a Caja"
                    }).then(function(){
                        window.location = "caja";
                    });
                </script>';
                return;
            }

            $tablaVentas = "ventas";
            
            // Decodificar el JSON recibido de cualquiera de los dos campos
            $jsonRecibido = isset($_POST["listaProductosJSON"]) ? $_POST["listaProductosJSON"] : $_POST["listaProductos"];
            $listaProductos = json_decode($jsonRecibido, true);

            if (empty($listaProductos) || !is_array($listaProductos)) {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "¡Error!",
                        text: "El carrito de compras está vacío.",
                        confirmButtonText: "Cerrar"
                    });
                </script>';
                return;
            }

            $totalPublicado = max(0, (float) ($_POST["nuevoTotalVenta"] ?? 0));
            $subtotalPublicado = max(0, (float) ($_POST["nuevoSubtotal"] ?? 0));
            if ($totalPublicado <= 0 || $subtotalPublicado <= 0) {
                echo '<script>Swal.fire({icon: "error", title: "Venta inválida", text: "El total de la venta debe ser mayor que cero."});</script>';
                return;
            }

            // Numeración electrónica SUNAT cuando está habilitada; los Tickets conservan su numeración local.
            $tipoComprobante = isset($_POST["nuevoTipoComprobante"]) ? $_POST["nuevoTipoComprobante"] : "Ticket";
            $sunatCfg = ModeloFacturacion::config();
            if (!empty($sunatCfg["activo"]) && in_array($tipoComprobante, ["Factura", "Boleta"], true)) {
                $serie = $tipoComprobante === "Factura" ? ($sunatCfg["serie_factura"] ?: "F001") : ($sunatCfg["serie_boleta"] ?: "B001");
                $num = ModeloFacturacion::siguienteNumero($tipoComprobante, $serie);
                $codigoFactura = $serie . "-" . str_pad((string)$num, 8, "0", STR_PAD_LEFT);
            } else {
                $prefijo = $tipoComprobante === "Boleta" ? "BOL-" : ($tipoComprobante === "Factura" ? "FAC-" : "TKT-");
                $codigoFactura = $prefijo . date("Ymd") . "-" . rand(100, 999);
            }

            // Obtener pago y vuelto asegurando formato flotante
            $metodoPago = !empty($_POST["nuevoMetodoPago"]) ? $_POST["nuevoMetodoPago"] : "Efectivo";
            $pagueCon   = isset($_POST["nuevoPagueCon"]) && $_POST["nuevoPagueCon"] !== "" ? floatval($_POST["nuevoPagueCon"]) : 0;
            $vuelto     = isset($_POST["nuevoVuelto"]) && $_POST["nuevoVuelto"] !== ""     ? floatval($_POST["nuevoVuelto"])   : 0;

            $datosVenta = array(
                "codigo_factura"   => $codigoFactura,
                "tipo_comprobante" => $tipoComprobante,
                "id_usuario"       => $idUsuario,
                "id_cliente"        => isset($_POST["seleccionarCliente"]) ? $_POST["seleccionarCliente"] : 1,
                "subtotal"         => $subtotalPublicado,
                "total"            => $totalPublicado,
                "pague_con"        => $pagueCon,
                "vuelto"           => $vuelto,
                "metodo_pago"      => $metodoPago
            );

            // Insertar en Base de Datos
            $respuesta = ModeloVentas::mdlIngresarVenta($tablaVentas, $datosVenta, $listaProductos);

            if (strpos((string)$respuesta, "ok:") === 0) {

                $idVentaRegistrada = (int)substr((string)$respuesta, 3);
                $resultadoSunat = ["ok"=>true,"estado"=>"NO_APLICA","mensaje"=>""];
                if (!empty($sunatCfg["activo"]) && in_array($tipoComprobante, ["Factura", "Boleta"], true)) {
                    $resultadoSunat = SunatFacturacion::emitirVenta($idVentaRegistrada);
                }

                $urlComprobante = self::ctrGenerarEnlaceComprobante($codigoFactura);

                $idClienteVenta = isset($datosVenta["id_cliente"]) ? (int)$datosVenta["id_cliente"] : 1;
                $telefonoCliente = "";
                if ($idClienteVenta > 1) {
                    $clienteVenta = ModeloClientes::mdlMostrarClientes("clientes", "id", $idClienteVenta);
                    if (!empty($clienteVenta["telefono"])) {
                        $telefonoCliente = self::ctrNormalizarTelefonoWhatsApp($clienteVenta["telefono"]);
                    }
                }

                $mensajeWhatsapp = "Hola, aquí tienes tu comprobante de compra " . $codigoFactura . ".\n\nPuedes visualizarlo aquí: " . $urlComprobante;
                $linkWhatsApp = "https://api.whatsapp.com/send?text=" . rawurlencode($mensajeWhatsapp);
                if (!empty($telefonoCliente)) {
                    $linkWhatsApp = "https://wa.me/" . rawurlencode($telefonoCliente) . "?text=" . rawurlencode($mensajeWhatsapp);
                }

                $linkWhatsAppJs = json_encode($linkWhatsApp);
                $urlComprobanteJs = json_encode($urlComprobante);
                $codigoFacturaJs = json_encode($codigoFactura);
                $sunatMensajeHtml = '';
                if (!empty($sunatCfg["activo"]) && in_array($tipoComprobante, ["Factura", "Boleta"], true)) {
                    $sunatMensajeHtml = ($resultadoSunat["ok"] ?? false)
                        ? '<br><span class="text-success">SUNAT: Aceptado.</span>'
                        : '<br><span class="text-warning">SUNAT: ' . htmlspecialchars($resultadoSunat["mensaje"] ?? "pendiente", ENT_QUOTES, "UTF-8") . '</span>';
                }
                $sunatMensajeJs = json_encode($sunatMensajeHtml);

                echo '<script>
                    var codigoVenta = ' . $codigoFacturaJs . ';
                    var comprobanteLink = ' . $urlComprobanteJs . ';
                    var whatsappLink = ' . $linkWhatsAppJs . ';
                    Swal.fire({
                        icon: "success",
                        title: "¡Venta realizada con éxito!",
                        html: "Comprobante: <strong>" + codigoVenta + "</strong><br><small>El cliente podrá verlo desde el enlace público.</small>" + ' . $sunatMensajeJs . ',
                        showConfirmButton: true,
                        confirmButtonText: "<i class=\"fa-solid fa-print\"></i> Imprimir",
                        showDenyButton: true,
                        denyButtonText: "<i class=\"fa-brands fa-whatsapp\"></i> WhatsApp",
                        denyButtonColor: "#25D366",
                        showCancelButton: true,
                        cancelButtonText: "Ver comprobante",
                        allowOutsideClick: false,
                        reverseButtons: true
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.open("vistas/modulos/imprimir_comprobante.php?codigo=" + encodeURIComponent(codigoVenta), "_blank", "width=450,height=650,scrollbars=yes");
                        } else if (result.isDenied) {
                            window.open(whatsappLink, "_blank", "noopener,noreferrer");
                        } else if (result.dismiss === Swal.DismissReason.cancel) {
                            window.open(comprobanteLink, "_blank", "noopener,noreferrer");
                        }
                        window.location = "ventas";
                    });
                </script>';

            } else {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "Error al guardar",
                        text: "Ocurrió un problema al guardar la venta en la base de datos.",
                        confirmButtonText: "Cerrar"
                    });
                </script>';
            }
        }
    }

    /*=============================================
    MOSTRAR VENTAS
    =============================================*/
    public static function ctrMostrarVentas() {
        return ModeloVentas::mdlMostrarVentas("ventas");
    }

    /*=============================================
    ANULAR VENTA Y RESTAURAR STOCK
    =============================================*/
    public static function ctrAnularVenta() {

        if (isset($_GET["idVentaAnular"])) {

            $tabla = "ventas";
            $idVenta = $_GET["idVentaAnular"];

            $respuesta = ModeloVentas::mdlAnularVenta($tabla, $idVenta);

            if ($respuesta == "ok") {

                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡Venta Anulada!",
                        text: "La venta se eliminó correctamente y el stock ha sido restaurado.",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    }).then(function(result){
                        if (result.value) {
                            window.location = "historial-ventas";
                        }
                    });
                </script>';

            } else {

                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "Error",
                        text: "Ocurrió un error al intentar anular la venta.",
                        confirmButtonText: "Cerrar"
                    });
                </script>';

            }

        }

    }

    /*=============================================
    OBTENER SUMA DE VENTAS POR FECHA
    =============================================*/
    public static function ctrSumaTotalVentasPorFecha() {
        return ModeloVentas::mdlSumaTotalVentasPorFecha("ventas");
    }

    /*=============================================
    OBTENER PRODUCTOS MÁS VENDIDOS
    =============================================*/
    public static function ctrProductosMasVendidos() {
        return ModeloVentas::mdlProductosMasVendidos();
    }


    /*=============================================
RANGO FECHAS VENTAS
=============================================*/
static public function ctrRangoFechasVentas($fechaInicial, $fechaFinal) {

    $tabla = "ventas";

    $respuesta = ModeloVentas::mdlRangoFechasVentas($tabla, $fechaInicial, $fechaFinal);

    return $respuesta;

}


/*=============================================
SUMA TOTAL VENTAS
=============================================*/
static public function ctrSumaTotalVentas() {
    $tabla = "ventas";
    $respuesta = ModeloVentas::mdlSumaTotalVentas($tabla);
    return $respuesta["total"] ?? 0;
}

    

} // Cierra la clase ControladorVentas