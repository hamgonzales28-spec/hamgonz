<?php

class ControladorClientes {

    /*=============================================
    MOSTRAR CLIENTES
    =============================================*/
    public static function ctrMostrarClientes($item, $valor) {
        $tabla = "clientes";
        return ModeloClientes::mdlMostrarClientes($tabla, $item, $valor);
    }

    /*=============================================
    CREAR CLIENTE
    =============================================*/
    public static function ctrCrearCliente() {

        if (isset($_POST["nuevoDocumento"])) {

            $tabla = "clientes";

            $datos = array(
                "documento" => $_POST["nuevoDocumento"],
                "nombre"    => $_POST["nuevoNombre"],
                "email"     => $_POST["nuevoEmail"],
                "telefono"  => $_POST["nuevoTelefono"],
                "direccion" => $_POST["nuevaDireccion"]
            );

            $respuesta = ModeloClientes::mdlIngresarCliente($tabla, $datos);

            if ($respuesta == "ok") {

                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡Cliente Guardado!",
                        text: "El cliente ha sido registrado correctamente.",
                        confirmButtonText: "Cerrar"
                    }).then(function(result){
                        if (result.value) {
                            window.location = "clientes";
                        }
                    });
                </script>';

            }

        }

    }

    /*=============================================
    EDITAR CLIENTE
    =============================================*/
    public static function ctrEditarCliente() {

        if (isset($_POST["editarDocumento"])) {

            $tabla = "clientes";
            $datos = array(
                "id"        => $_POST["idCliente"],
                "documento" => $_POST["editarDocumento"],
                "nombre"    => $_POST["editarNombre"],
                "email"     => $_POST["editarEmail"],
                "telefono"  => $_POST["editarTelefono"],
                "direccion" => $_POST["editarDireccion"]
            );

            $respuesta = ModeloClientes::mdlEditarCliente($tabla, $datos);

            if ($respuesta == "ok") {

                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡Cliente Actualizado!",
                        text: "Los datos del cliente se modificaron correctamente.",
                        confirmButtonText: "Cerrar"
                    }).then(function(result){
                        if (result.value) {
                            window.location = "clientes";
                        }
                    });
                </script>';

            }

        }

    }

    /*=============================================
    ELIMINAR CLIENTE
    =============================================*/
    public static function ctrEliminarCliente() {

        if (isset($_GET["idClienteEliminar"])) {

            $tabla = "clientes";
            $id = $_GET["idClienteEliminar"];

            $respuesta = ModeloClientes::mdlEliminarCliente($tabla, $id);

            if ($respuesta == "ok") {

                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡Cliente Eliminado!",
                        text: "El cliente fue eliminado con éxito.",
                        confirmButtonText: "Cerrar"
                    }).then(function(result){
                        if (result.value) {
                            window.location = "clientes";
                        }
                    });
                </script>';

            }

        }

    }

}