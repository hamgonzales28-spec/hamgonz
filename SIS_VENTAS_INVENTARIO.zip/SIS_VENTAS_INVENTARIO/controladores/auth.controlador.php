<?php
class ControladorAuth {

    public static function ctrIngresoUsuario() {
        if (!isset($_POST["ingUsuario"])) return;

        $respuesta = ModeloUsuarios::mdlMostrarUsuarios("usuarios", "usuario", $_POST["ingUsuario"]);

        if ($respuesta && $respuesta["usuario"] === $_POST["ingUsuario"]) {
            $passwordOk = password_verify($_POST["ingPassword"], $respuesta["password"]) || $_POST["ingPassword"] == $respuesta["password"];
            if ($passwordOk) {
                $_SESSION["iniciarSesion"] = "ok";
                $_SESSION["id"] = $respuesta["id"];
                $_SESSION["nombre"] = $respuesta["nombre"];
                $_SESSION["usuario"] = $respuesta["usuario"];
                $_SESSION["perfil"] = $respuesta["perfil"];
                session_regenerate_id(true);
                echo '<script>window.location = "dashboard";</script>';
                return;
            }
            echo '<div class="alert alert-danger text-center mt-3">Contraseña incorrecta.</div>';
            return;
        }

        echo '<div class="alert alert-danger text-center mt-3">El usuario no existe.</div>';
    }

    public static function ctrCrearUsuario() {
        if (isset($_POST["nuevoUsuario"])) {
            $datos = [
                "nombre" => $_POST["nuevoNombre"],
                "usuario" => $_POST["nuevoUsuario"],
                "password" => password_hash($_POST["nuevoPassword"], PASSWORD_BCRYPT),
                "perfil" => $_POST["nuevoPerfil"]
            ];
            $respuesta = ModeloUsuarios::mdlIngresarUsuario("usuarios", $datos);
            if ($respuesta == "ok") {
                echo '<script>Swal.fire({icon:"success",title:"¡Usuario registrado correctamente!",confirmButtonText:"Cerrar"}).then(()=>location="usuarios");</script>';
            }
        }
    }

    public static function ctrEditarUsuario() {
        if (isset($_POST["idUsuario"])) {
            $datos = [
                "id" => $_POST["idUsuario"],
                "nombre" => $_POST["editarNombre"],
                "usuario" => $_POST["editarUsuario"],
                "perfil" => $_POST["editarPerfil"]
            ];
            $respuesta = ModeloUsuarios::mdlEditarUsuario("usuarios", $datos);
            if ($respuesta == "ok") {
                echo '<script>Swal.fire({icon:"success",title:"¡Usuario actualizado correctamente!",confirmButtonText:"Cerrar"}).then(()=>location="usuarios");</script>';
            }
        }
    }

    public static function ctrBorrarUsuario() {
        if (isset($_GET["idUsuario"])) {
            $respuesta = ModeloUsuarios::mdlBorrarUsuario("usuarios", $_GET["idUsuario"]);
            if ($respuesta == "ok") {
                echo '<script>Swal.fire({icon:"success",title:"¡Usuario eliminado correctamente!",confirmButtonText:"Cerrar"}).then(()=>location="usuarios");</script>';
            }
        }
    }
}
