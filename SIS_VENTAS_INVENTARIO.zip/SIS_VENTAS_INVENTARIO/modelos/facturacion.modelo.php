<?php
require_once __DIR__ . "/../config/conexion.php";

class ModeloFacturacion {
    /**
     * Verifica que la estructura SUNAT haya sido instalada manualmente.
     * El sistema NO crea ni modifica tablas SUNAT automáticamente.
     */
    private static function verificarEstructura() {
        $pdo = Conexion::conectar();
        $tablas = ['sunat_configuracion', 'sunat_correlativos'];
        $faltantes = [];

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :tabla");
        foreach ($tablas as $tabla) {
            $stmt->execute([':tabla' => $tabla]);
            if (!(int)$stmt->fetchColumn()) {
                $faltantes[] = $tabla;
            }
        }

        $columnas = [
            'sunat_estado', 'sunat_codigo', 'sunat_mensaje', 'sunat_ticket',
            'sunat_xml', 'sunat_cdr', 'sunat_hash', 'sunat_fecha_envio'
        ];
        $check = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS
                                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ventas' AND COLUMN_NAME = :col");
        foreach ($columnas as $columna) {
            $check->execute([':col' => $columna]);
            if (!(int)$check->fetchColumn()) {
                $faltantes[] = 'ventas.' . $columna;
            }
        }

        if ($faltantes) {
            throw new RuntimeException(
                "La estructura de Facturación SUNAT no está instalada. " .
                "Ejecuta manualmente el archivo database/sunat.sql desde phpMyAdmin y vuelve a ingresar. " .
                "Elementos faltantes: " . implode(', ', $faltantes)
            );
        }

        return $pdo;
    }

    public static function config() {
        $stmt = self::verificarEstructura()->query("SELECT * FROM sunat_configuracion WHERE id=1 LIMIT 1");
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }

    public static function guardarConfig($datos) {
        $sql = "INSERT INTO sunat_configuracion
                (id,ruc,razon_social,nombre_comercial,direccion,ubigeo,departamento,provincia,distrito,sol_usuario,sol_clave,certificado_path,certificado_clave,ambiente,serie_factura,serie_boleta,igv,activo)
                VALUES (1,:ruc,:razon_social,:nombre_comercial,:direccion,:ubigeo,:departamento,:provincia,:distrito,:sol_usuario,:sol_clave,:certificado_path,:certificado_clave,:ambiente,:serie_factura,:serie_boleta,:igv,:activo)
                ON DUPLICATE KEY UPDATE
                ruc=VALUES(ruc),razon_social=VALUES(razon_social),nombre_comercial=VALUES(nombre_comercial),direccion=VALUES(direccion),ubigeo=VALUES(ubigeo),departamento=VALUES(departamento),provincia=VALUES(provincia),distrito=VALUES(distrito),sol_usuario=VALUES(sol_usuario),sol_clave=VALUES(sol_clave),certificado_path=VALUES(certificado_path),certificado_clave=VALUES(certificado_clave),ambiente=VALUES(ambiente),serie_factura=VALUES(serie_factura),serie_boleta=VALUES(serie_boleta),igv=VALUES(igv),activo=VALUES(activo)";
        $stmt = self::verificarEstructura()->prepare($sql);
        foreach ($datos as $k=>$v) $stmt->bindValue(":$k", $v);
        return $stmt->execute() ? "ok" : "error";
    }

    public static function siguienteNumero($tipo, $serie) {
        $pdo = self::verificarEstructura();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("INSERT INTO sunat_correlativos (tipo,serie,numero) VALUES (:tipo,:serie,LAST_INSERT_ID(1)) ON DUPLICATE KEY UPDATE numero=LAST_INSERT_ID(numero+1)");
            $stmt->execute([':tipo'=>$tipo, ':serie'=>$serie]);
            $numero = (int)$pdo->lastInsertId();
            $pdo->commit();
            return $numero;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }

    public static function actualizarVentaSunat($idVenta, $datos) {
        $stmt = self::verificarEstructura()->prepare("UPDATE ventas SET sunat_estado=:estado,sunat_codigo=:codigo,sunat_mensaje=:mensaje,sunat_ticket=:ticket,sunat_xml=:xml,sunat_cdr=:cdr,sunat_hash=:hash,sunat_fecha_envio=NOW() WHERE id=:id");
        $stmt->execute([
            ':estado'=>$datos['estado'] ?? 'PENDIENTE', ':codigo'=>$datos['codigo'] ?? null,
            ':mensaje'=>$datos['mensaje'] ?? null, ':ticket'=>$datos['ticket'] ?? null,
            ':xml'=>$datos['xml'] ?? null, ':cdr'=>$datos['cdr'] ?? null, ':hash'=>$datos['hash'] ?? null, ':id'=>$idVenta
        ]);
    }

    public static function obtenerVentaCompleta($idVenta) {
        $pdo = Conexion::conectar();
        $stmt = $pdo->prepare("SELECT v.*, c.documento cliente_documento, c.nombre cliente_nombre, c.email cliente_email, c.direccion cliente_direccion, c.telefono cliente_telefono FROM ventas v LEFT JOIN clientes c ON c.id=v.id_cliente WHERE v.id=:id LIMIT 1");
        $stmt->execute([':id'=>$idVenta]);
        $venta = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$venta) return null;
        $stmt = $pdo->prepare("SELECT d.*, p.codigo, p.descripcion, p.unidad_medida FROM ventas_detalle d INNER JOIN productos p ON p.id=d.id_producto WHERE d.id_venta=:id ORDER BY d.id");
        $stmt->execute([':id'=>$idVenta]);
        $venta['detalle'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $venta;
    }
}
