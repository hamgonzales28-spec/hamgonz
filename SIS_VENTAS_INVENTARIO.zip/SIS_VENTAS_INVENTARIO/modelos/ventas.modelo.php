<?php

// Incluir la conexión desde config de manera relativa y segura
require_once __DIR__ . "/../config/conexion.php";

class ModeloVentas {

    /*=============================================
    MOSTRAR VENTAS
    =============================================*/
    public static function mdlMostrarVentas($tabla, $item = null, $valor = null) {

        if ($item != null) {
            $stmt = Conexion::conectar()->prepare("SELECT v.*, u.nombre as vendedor FROM $tabla v INNER JOIN usuarios u ON v.id_usuario = u.id WHERE v.$item = :$item ORDER BY v.id DESC");
            $stmt->bindParam(":" . $item, $valor, PDO::PARAM_STR);
            $stmt->execute();
            return $stmt->fetch();
        } else {
            $stmt = Conexion::conectar()->prepare("SELECT v.*, u.nombre as vendedor FROM $tabla v INNER JOIN usuarios u ON v.id_usuario = u.id ORDER BY v.id DESC");
            $stmt->execute();
            return $stmt->fetchAll();
        }

        $stmt = null;
    }

/*=============================================
REGISTRAR VENTA
=============================================*/
/*=============================================
REGISTRAR VENTA (MODO DIAGNÓSTICO DE ERRORES)
=============================================*/
public static function mdlIngresarVenta($tabla, $datos, $listaProductos) {

    $link = Conexion::conectar();

    // Habilitar errores explícitos en PDO
    $link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    try {
        $idUsuario = isset($datos["id_usuario"]) ? $datos["id_usuario"] : $_SESSION["id"];

        // 1. Sentencia SQL con el orden exacto de tu tabla
        $stmt = $link->prepare("INSERT INTO $tabla(
            codigo_factura, 
            tipo_comprobante, 
            id_usuario, 
            id_cliente, 
            subtotal, 
            total, 
            pague_con, 
            vuelto, 
            metodo_pago
        ) VALUES (
            :codigo_factura, 
            :tipo_comprobante, 
            :id_usuario, 
            :id_cliente, 
            :subtotal, 
            :total, 
            :pague_con, 
            :vuelto, 
            :metodo_pago
        )");

        $stmt->bindParam(":codigo_factura", $datos["codigo_factura"], PDO::PARAM_STR);
        $stmt->bindParam(":tipo_comprobante", $datos["tipo_comprobante"], PDO::PARAM_STR);
        $stmt->bindParam(":id_usuario", $idUsuario, PDO::PARAM_INT);
        $stmt->bindParam(":id_cliente", $datos["id_cliente"], PDO::PARAM_INT);
        $stmt->bindParam(":subtotal", $datos["subtotal"], PDO::PARAM_STR);
        $stmt->bindParam(":total", $datos["total"], PDO::PARAM_STR);
        $stmt->bindParam(":pague_con", $datos["pague_con"], PDO::PARAM_STR);
        $stmt->bindParam(":vuelto", $datos["vuelto"], PDO::PARAM_STR);
        $stmt->bindParam(":metodo_pago", $datos["metodo_pago"], PDO::PARAM_STR);

        $link->beginTransaction();
        $stmt->execute();
        $idVenta = $link->lastInsertId();

        // --- VERIFICACIÓN DE CONEXIÓN Y REGISTRO --

        // 2. Insertar detalle de productos
        foreach ($listaProductos as $value) {

            $idProducto = isset($value["id"]) ? (int) $value["id"] : (isset($value["id_producto"]) ? (int) $value["id_producto"] : null);
            $precioUnitario = isset($value["precio"]) ? (float) $value["precio"] : (isset($value["precio_unitario"]) ? (float) $value["precio_unitario"] : 0);
            $cantidad = isset($value["cantidad"]) ? (int) $value["cantidad"] : 1;
            $totalItem = $cantidad * $precioUnitario;

            if ($idProducto !== null && $idProducto > 0 && $cantidad > 0 && $precioUnitario >= 0) {

                // Insertar en ventas_detalle
                $stmtDetalle = $link->prepare("INSERT INTO ventas_detalle(id_venta, id_producto, cantidad, precio_unitario, total_item) VALUES (:id_venta, :id_producto, :cantidad, :precio_unitario, :total_item)");

                $stmtDetalle->bindParam(":id_venta", $idVenta, PDO::PARAM_INT);
                $stmtDetalle->bindParam(":id_producto", $idProducto, PDO::PARAM_INT);
                $stmtDetalle->bindParam(":cantidad", $cantidad, PDO::PARAM_INT);
                $stmtDetalle->bindParam(":precio_unitario", $precioUnitario, PDO::PARAM_STR);
                $stmtDetalle->bindParam(":total_item", $totalItem, PDO::PARAM_STR);

                $stmtDetalle->execute();

                // Actualizar el stock solo si hay unidades suficientes.
                $stmtProducto = $link->prepare("UPDATE productos SET stock = stock - :cantidad_update WHERE id = :id AND stock >= :cantidad_stock");

                $stmtProducto->bindParam(":cantidad_update", $cantidad, PDO::PARAM_INT);
                $stmtProducto->bindParam(":cantidad_stock", $cantidad, PDO::PARAM_INT);
                $stmtProducto->bindParam(":id", $idProducto, PDO::PARAM_INT);

                $stmtProducto->execute();
                if ($stmtProducto->rowCount() !== 1) {
                    throw new RuntimeException("Stock insuficiente para el producto " . $idProducto);
                }
            } else {
                throw new RuntimeException("Detalle de producto inválido");
            }
        }

        $link->commit();
        return "ok:" . $idVenta;

    } catch (Throwable $e) {
        if ($link->inTransaction()) {
            $link->rollBack();
        }
        error_log("Error al registrar venta: " . $e->getMessage());
        return "error";
    }
}
    /*=============================================
    ELIMINAR VENTA
    =============================================*/
    public static function mdlEliminarVenta($tabla, $idVenta) {
        $stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");
        $stmt->bindParam(":id", $idVenta, PDO::PARAM_INT);

        if ($stmt->execute()) {
            return "ok";
        } else {
            return "error";
        }

        $stmt = null;
    }



/*=======================================*/




/*=============================================
ANULAR VENTA Y RESTAURAR STOCK
=============================================*/
public static function mdlAnularVenta($tabla, $idVenta) {

    $link = Conexion::conectar();

    try {
        $link->beginTransaction();

        // 1. Obtener los productos de la venta para devolver el stock
        $stmtDetalle = $link->prepare("SELECT id_producto, cantidad FROM ventas_detalle WHERE id_venta = :id_venta");
        $stmtDetalle->bindParam(":id_venta", $idVenta, PDO::PARAM_INT);
        $stmtDetalle->execute();
        $productos = $stmtDetalle->fetchAll(PDO::FETCH_ASSOC);

        // 2. Devolver el stock a cada producto
        foreach ($productos as $item) {
            $stmtStock = $link->prepare("UPDATE productos SET stock = stock + :cantidad WHERE id = :id");
            $stmtStock->bindParam(":cantidad", $item["cantidad"], PDO::PARAM_INT);
            $stmtStock->bindParam(":id", $item["id_producto"], PDO::PARAM_INT);
            $stmtStock->execute();
        }

        // 3. Eliminar el detalle de la venta
        $stmtDelDetalle = $link->prepare("DELETE FROM ventas_detalle WHERE id_venta = :id_venta");
        $stmtDelDetalle->bindParam(":id_venta", $idVenta, PDO::PARAM_INT);
        $stmtDelDetalle->execute();

        // 4. Eliminar la cabecera de la venta
        $stmtDelVenta = $link->prepare("DELETE FROM $tabla WHERE id = :id_venta");
        $stmtDelVenta->bindParam(":id_venta", $idVenta, PDO::PARAM_INT);
        $stmtDelVenta->execute();

        $link->commit();
        return "ok";

    } catch (Exception $e) {
        $link->rollBack();
        return "error: " . $e->getMessage();
    }
}


/*=============================================
SUMA TOTAL DE VENTAS POR FECHAS / DÍAS
=============================================*/
public static function mdlSumaTotalVentasPorFecha($tabla) {

    $stmt = Conexion::conectar()->prepare("SELECT DATE(fecha) as fecha_corta, SUM(total) as total_dia 
                                           FROM $tabla 
                                           GROUP BY DATE(fecha) 
                                           ORDER BY fecha_corta DESC 
                                           LIMIT 7");
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/*=============================================
PRODUCTOS MÁS VENDIDOS
=============================================*/
public static function mdlProductosMasVendidos() {

    $stmt = Conexion::conectar()->prepare("SELECT p.descripcion, SUM(d.cantidad) as total_vendido 
                                           FROM ventas_detalle d 
                                           INNER JOIN productos p ON d.id_producto = p.id 
                                           GROUP BY d.id_producto 
                                           ORDER BY total_vendido DESC 
                                           LIMIT 5");
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


/*=============================================
RANGO FECHAS O MOSTRAR VENTAS
=============================================*/
static public function mdlRangoFechasVentas($tabla, $fechaInicial, $fechaFinal) {

    if ($fechaInicial == null) {

        $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla ORDER BY id DESC");
        $stmt->execute();
        return $stmt->fetchAll();

    } else if ($fechaInicial == $fechaFinal) {

        $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE fecha LIKE :fecha ORDER BY id DESC");
        $stmt->bindValue(":fecha", "%$fechaFinal%", PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchAll();

    } else {

        // Se suma 1 día a la fecha final para incluir registros de todo el día límite
        $fechaFinal2 = new DateTime($fechaFinal);
        $fechaFinal2->add(new DateInterval("P1D"));
        $fechaFinal2MasUno = $fechaFinal2->format("Y-m-d");

        $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE fecha BETWEEN :fechaInicial AND :fechaFinal ORDER BY id DESC");
        $stmt->bindParam(":fechaInicial", $fechaInicial, PDO::PARAM_STR);
        $stmt->bindParam(":fechaFinal", $fechaFinal2MasUno, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchAll();

    }

    $stmt = null;
}

/*=============================================
SUMAR TOTAL DE VENTAS
=============================================*/
static public function mdlSumaTotalVentas($tabla) {

    $stmt = Conexion::conectar()->prepare("SELECT SUM(total) as total FROM $tabla");
    $stmt->execute();

    return $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = null;
}




}