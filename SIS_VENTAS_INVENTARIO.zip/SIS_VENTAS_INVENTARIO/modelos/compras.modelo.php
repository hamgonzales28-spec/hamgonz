<?php

//require_once "conexion.php";
require_once "config/conexion.php"; // <--- Cambiar 'conexion.php' por 'modelos/conexion.php'
class ModeloCompras {

    /*=============================================
    MOSTRAR COMPRAS (ÉSTE ES EL MÉTODO QUE FALTABA)
    =============================================*/
    static public function mdlMostrarCompras($tabla, $item, $valor) {

        if ($item != null) {
            $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item = :$item ORDER BY id DESC");
            $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla ORDER BY id DESC");
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        $stmt = null;
    }

    /*=============================================
    REGISTRAR COMPRA Y RETORNAR ID INSERTADO
    =============================================*/
    static public function mdlIngresarCompra($tabla, $datos) {

        $link = Conexion::conectar();
        $stmt = $link->prepare("INSERT INTO $tabla(codigo, proveedor, metodo_pago, total) VALUES (:codigo, :proveedor, :metodo_pago, :total)");

        $stmt->bindParam(":codigo", $datos["codigo"], PDO::PARAM_STR);
        $stmt->bindParam(":proveedor", $datos["proveedor"], PDO::PARAM_STR);
        $stmt->bindParam(":metodo_pago", $datos["metodo_pago"], PDO::PARAM_STR);
        $stmt->bindParam(":total", $datos["total"], PDO::PARAM_STR);

        if ($stmt->execute()) {
            return $link->lastInsertId(); // Retorna el ID de la compra registrada
        } else {
            return "error";
        }

        $stmt = null;
    }

    /*=============================================
    REGISTRAR DETALLE DE COMPRA (PRECIO UNIDAD Y TOTAL POR PRODUCTO)
    =============================================*/
    static public function mdlIngresarDetalleCompra($tabla, $datos) {

        $stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(id_compra, id_producto, cantidad, precio_unitario, total_producto) VALUES (:id_compra, :id_producto, :cantidad, :precio_unitario, :total_producto)");

        $stmt->bindParam(":id_compra", $datos["id_compra"], PDO::PARAM_INT);
        $stmt->bindParam(":id_producto", $datos["id_producto"], PDO::PARAM_INT);
        $stmt->bindParam(":cantidad", $datos["cantidad"], PDO::PARAM_INT);
        $stmt->bindParam(":precio_unitario", $datos["precio_unitario"], PDO::PARAM_STR);
        $stmt->bindParam(":total_producto", $datos["total_producto"], PDO::PARAM_STR);

        return $stmt->execute();

        $stmt = null;
    }


/*=============================================
SUMAR TOTAL DE COMPRAS
=============================================*/
static public function mdlSumaTotalCompras($tabla) {

    $stmt = Conexion::conectar()->prepare("SELECT SUM(total) as total FROM $tabla");
    $stmt->execute();

    return $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = null;
}

}