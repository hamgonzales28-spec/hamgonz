<?php
require_once __DIR__ . "/../config/conexion.php";

class ModeloProductos {

    private static function asegurarEstructura($tabla) {
        if ($tabla !== 'productos') return;
        $pdo = Conexion::conectar();
        $q = $pdo->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='productos' AND COLUMN_NAME='codigo_barras'");
        if ((int)$q->fetchColumn() === 0) {
            $pdo->exec("ALTER TABLE productos ADD COLUMN codigo_barras VARCHAR(50) NULL AFTER codigo");
        }
        $q = $pdo->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='productos' AND INDEX_NAME='uk_productos_codigo_barras'");
        if ((int)$q->fetchColumn() === 0) {
            try {
                $pdo->exec("ALTER TABLE productos ADD UNIQUE KEY uk_productos_codigo_barras (codigo_barras)");
            } catch (PDOException $e) {
                // La validación de duplicados del controlador sigue funcionando aunque
                // el usuario de BD no pueda crear el índice automáticamente.
                error_log('Productos - índice de código de barras: '.$e->getMessage());
            }
        }
    }

    static public function mdlMostrarProductos($tabla, $item, $valor) {
        self::asegurarEstructura($tabla);
        $pdo = Conexion::conectar();
        if ($item != null) {
            $stmt = $pdo->prepare("SELECT p.*, c.categoria FROM $tabla p LEFT JOIN categorias c ON p.id_categoria=c.id WHERE p.$item=:valor LIMIT 1");
            $stmt->bindValue(':valor', $valor);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        $stmt = $pdo->prepare("SELECT p.*, c.categoria FROM $tabla p LEFT JOIN categorias c ON p.id_categoria=c.id ORDER BY p.id DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    static public function mdlIngresarProducto($tabla, $datos) {
        try {
            self::asegurarEstructura($tabla);
            $stmt = Conexion::conectar()->prepare("INSERT INTO $tabla (id_categoria,codigo,codigo_barras,descripcion,unidad_medida,stock,precio_venta) VALUES (:id_categoria,:codigo,:codigo_barras,:descripcion,:unidad_medida,:stock,:precio_venta)");
            $stmt->bindValue(':id_categoria', (int)$datos['id_categoria'], PDO::PARAM_INT);
            $stmt->bindValue(':codigo', trim($datos['codigo']), PDO::PARAM_STR);
            $barcode = $datos['codigo_barras'] ?? null;
            $stmt->bindValue(':codigo_barras', ($barcode === null || $barcode === '') ? null : trim($barcode), ($barcode === null || $barcode === '') ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmt->bindValue(':descripcion', trim($datos['descripcion']), PDO::PARAM_STR);
            $stmt->bindValue(':unidad_medida', trim($datos['unidad_medida']) ?: 'Unidad', PDO::PARAM_STR);
            $stmt->bindValue(':stock', (int)$datos['stock'], PDO::PARAM_INT);
            $stmt->bindValue(':precio_venta', number_format((float)$datos['precio_venta'],2,'.',''), PDO::PARAM_STR);
            return $stmt->execute() ? 'ok' : 'error';
        } catch (PDOException $e) {
            error_log('Productos - insertar: '.$e->getMessage());
            return 'error';
        }
    }

    static public function mdlEditarProducto($tabla, $datos) {
        try {
            self::asegurarEstructura($tabla);
            $stmt = Conexion::conectar()->prepare("UPDATE $tabla SET codigo=:codigo,codigo_barras=:codigo_barras,id_categoria=:id_categoria,descripcion=:descripcion,unidad_medida=:unidad_medida,stock=:stock,precio_venta=:precio_venta WHERE id=:id");
            $stmt->bindValue(':codigo', trim($datos['codigo']), PDO::PARAM_STR);
            $barcode = $datos['codigo_barras'] ?? null;
            $stmt->bindValue(':codigo_barras', ($barcode === null || $barcode === '') ? null : trim($barcode), ($barcode === null || $barcode === '') ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmt->bindValue(':id_categoria', (int)$datos['id_categoria'], PDO::PARAM_INT);
            $stmt->bindValue(':descripcion', trim($datos['descripcion']), PDO::PARAM_STR);
            $stmt->bindValue(':unidad_medida', trim($datos['unidad_medida']) ?: 'Unidad', PDO::PARAM_STR);
            $stmt->bindValue(':stock', (int)$datos['stock'], PDO::PARAM_INT);
            $stmt->bindValue(':precio_venta', number_format((float)$datos['precio_venta'],2,'.',''), PDO::PARAM_STR);
            $stmt->bindValue(':id', (int)$datos['id'], PDO::PARAM_INT);
            return $stmt->execute() ? 'ok' : 'error';
        } catch (PDOException $e) {
            error_log('Productos - editar: '.$e->getMessage());
            return 'error';
        }
    }

    static public function mdlBorrarProducto($tabla, $datos) {
        try {
            $stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id=:id");
            $stmt->bindValue(':id', (int)$datos, PDO::PARAM_INT);
            return $stmt->execute() ? 'ok' : 'error';
        } catch (PDOException $e) {
            error_log('Productos - borrar: '.$e->getMessage());
            return 'error';
        }
    }

    static public function mdlGenerarCodigoProducto($tabla) {
        $stmt = Conexion::conectar()->prepare("SELECT COALESCE(MAX(CAST(SUBSTRING(codigo,6) AS UNSIGNED)),0) ultimo FROM $tabla WHERE codigo REGEXP '^PROD-[0-9]+$'");
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return 'PROD-'.str_pad((string)(((int)($row['ultimo'] ?? 0))+1),4,'0',STR_PAD_LEFT);
    }

    static public function mdlExisteCodigoBarras($tabla, $codigoBarras, $id=null) {
        self::asegurarEstructura($tabla);
        $pdo = Conexion::conectar();
        if ($id !== null) {
            $stmt = $pdo->prepare("SELECT id FROM $tabla WHERE codigo_barras=:codigo_barras AND id<>:id LIMIT 1");
            $stmt->bindValue(':id',(int)$id,PDO::PARAM_INT);
        } else {
            $stmt = $pdo->prepare("SELECT id FROM $tabla WHERE codigo_barras=:codigo_barras LIMIT 1");
        }
        $stmt->bindValue(':codigo_barras',trim((string)$codigoBarras),PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
