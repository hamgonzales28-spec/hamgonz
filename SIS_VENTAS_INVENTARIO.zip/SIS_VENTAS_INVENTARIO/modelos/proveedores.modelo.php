<?php

require_once __DIR__ . "/../config/conexion.php";

class ModeloProveedores {

    /*=============================================
    MOSTRAR PROVEEDORES
    =============================================*/
    public static function mdlMostrarProveedores($tabla, $item, $valor) {
        if ($item != null) {
            $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item = :$item");
            $stmt->bindParam(":" . $item, $valor, PDO::PARAM_STR);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla ORDER BY id DESC");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    /*=============================================
    INGRESAR PROVEEDOR
    =============================================*/
    public static function mdlIngresarProveedor($tabla, $datos) {
        $stmt = Conexion::conectar()->prepare("INSERT INTO $tabla( doc_identidad,ruc, razon_social, contacto, telefono, email, direccion) VALUES (:doc_identidad, :ruc, :razon_social, :contacto, :telefono, :email, :direccion)");

        $stmt->bindParam(":doc_identidad", $datos["doc_identidad"], PDO::PARAM_STR);
        $stmt->bindParam(":ruc", $datos["ruc"], PDO::PARAM_STR);
        $stmt->bindParam(":razon_social", $datos["razon_social"], PDO::PARAM_STR);
        $stmt->bindParam(":contacto", $datos["contacto"], PDO::PARAM_STR);
        $stmt->bindParam(":telefono", $datos["telefono"], PDO::PARAM_STR);
        $stmt->bindParam(":email", $datos["email"], PDO::PARAM_STR);
        $stmt->bindParam(":direccion", $datos["direccion"], PDO::PARAM_STR);

        if ($stmt->execute()) {
            return "ok";
        } else {
            return "error";
        }
    }

    /*=============================================
    EDITAR PROVEEDOR
    =============================================*/
    public static function mdlEditarProveedor($tabla, $datos) {
        $stmt = Conexion::conectar()->prepare("UPDATE $tabla SET doc_identidad = :doc_identidad, ruc = :ruc, razon_social = :razon_social, contacto = :contacto, telefono = :telefono, email = :email, direccion = :direccion WHERE id = :id");

        $stmt->bindParam(":doc_identidad", $datos["doc_identidad"], PDO::PARAM_STR);
        $stmt->bindParam(":ruc", $datos["ruc"], PDO::PARAM_STR);
        $stmt->bindParam(":razon_social", $datos["razon_social"], PDO::PARAM_STR);
        $stmt->bindParam(":contacto", $datos["contacto"], PDO::PARAM_STR);
        $stmt->bindParam(":telefono", $datos["telefono"], PDO::PARAM_STR);
        $stmt->bindParam(":email", $datos["email"], PDO::PARAM_STR);
        $stmt->bindParam(":direccion", $datos["direccion"], PDO::PARAM_STR);
        $stmt->bindParam(":id", $datos["id"], PDO::PARAM_INT);

        if ($stmt->execute()) {
            return "ok";
        } else {
            return "error";
        }
    }

    /*=============================================
    BORRAR PROVEEDOR
    =============================================*/
    public static function mdlBorrarProveedor($tabla, $datos) {
        $stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");
        $stmt->bindParam(":id", $datos, PDO::PARAM_INT);

        if ($stmt->execute()) {
            return "ok";
        } else {
            return "error";
        }
    }
}