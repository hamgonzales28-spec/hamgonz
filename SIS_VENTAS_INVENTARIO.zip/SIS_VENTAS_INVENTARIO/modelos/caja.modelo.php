<?php

require_once __DIR__ . "/../config/conexion.php";

class ModeloCaja {

    /*=============================================
    CONSULTAR CAJA ABIERTA POR USUARIO (O GENERAL)
    =============================================*/
    public static function mdlObtenerCajaAbierta($idUsuario) {
        $stmt = Conexion::conectar()->prepare("SELECT * FROM cajas WHERE id_usuario = :id_usuario AND estado = 'abierta' ORDER BY id DESC LIMIT 1");
        $stmt->bindParam(":id_usuario", $idUsuario, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /*=============================================
    ABRIR CAJA
    =============================================*/
    public static function mdlAbrirCaja($datos) {
        $stmt = Conexion::conectar()->prepare("INSERT INTO cajas(id_usuario, monto_inicial) VALUES (:id_usuario, :monto_inicial)");
        $stmt->bindParam(":id_usuario", $datos["id_usuario"], PDO::PARAM_INT);
        $stmt->bindParam(":monto_inicial", $datos["monto_inicial"], PDO::PARAM_STR);

        if ($stmt->execute()) {
            return "ok";
        } else {
            return "error";
        }
    }

    /*=============================================
    CALCULAR VENTAS EN EFECTIVO DESDE LA APERTURA
    =============================================*/
    public static function mdlObtenerVentasEfectivo($fechaApertura, $idUsuario) {
        $stmt = Conexion::conectar()->prepare("SELECT SUM(total) as total_efectivo 
                                               FROM ventas 
                                               WHERE id_usuario = :id_usuario 
                                                 AND metodo_pago = 'Efectivo' 
                                                 AND fecha >= :fecha_apertura");
        $stmt->bindParam(":id_usuario", $idUsuario, PDO::PARAM_INT);
        $stmt->bindParam(":fecha_apertura", $fechaApertura, PDO::PARAM_STR);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

        return $resultado["total_efectivo"] ? $resultado["total_efectivo"] : 0.00;
    }

    /*=============================================
    NUEVO: CALCULAR COMPRAS EN EFECTIVO DESDE LA APERTURA
    =============================================*/
    public static function mdlObtenerComprasEfectivo($fechaApertura) {
        $stmt = Conexion::conectar()->prepare("SELECT SUM(total) as total_compras_efectivo 
                                               FROM compras 
                                               WHERE metodo_pago = 'Efectivo' 
                                                 AND fecha >= :fecha_apertura");
        $stmt->bindParam(":fecha_apertura", $fechaApertura, PDO::PARAM_STR);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

        return $resultado["total_compras_efectivo"] ? $resultado["total_compras_efectivo"] : 0.00;
    }

    /*=============================================
    CERRAR CAJA / ARQUEO (INCLUYENDO COMPRAS)
    =============================================*/
    public static function mdlCerrarCaja($datos) {
        $stmt = Conexion::conectar()->prepare("UPDATE cajas SET 
            monto_ventas_efectivo = :ventas_efectivo,
            monto_compras_efectivo = :compras_efectivo,
            monto_final_esperado = :esperado,
            monto_final_real = :real,
            diferencia = :diferencia,
            fecha_cierre = NOW(),
            estado = 'cerrada'
            WHERE id = :id_caja");

        $stmt->bindParam(":ventas_efectivo", $datos["ventas_efectivo"], PDO::PARAM_STR);
        $stmt->bindParam(":compras_efectivo", $datos["compras_efectivo"], PDO::PARAM_STR);
        $stmt->bindParam(":esperado", $datos["esperado"], PDO::PARAM_STR);
        $stmt->bindParam(":real", $datos["real"], PDO::PARAM_STR);
        $stmt->bindParam(":diferencia", $datos["diferencia"], PDO::PARAM_STR);
        $stmt->bindParam(":id_caja", $datos["id_caja"], PDO::PARAM_INT);

        if ($stmt->execute()) {
            return "ok";
        } else {
            return "error";
        }
    }

    /*=============================================
    ACTUALIZAR COMPRAS EN EFECTIVO EN TIEMPO REAL
    =============================================*/
    public static function mdlActualizarComprasCaja($idCaja, $montoCompras, $montoEsperado) {
        $stmt = Conexion::conectar()->prepare("UPDATE cajas SET 
            monto_compras_efectivo = :monto_compras, 
            monto_final_esperado = :monto_esperado 
            WHERE id = :id");

        $stmt->bindParam(":monto_compras", $montoCompras, PDO::PARAM_STR);
        $stmt->bindParam(":monto_esperado", $montoEsperado, PDO::PARAM_STR);
        $stmt->bindParam(":id", $idCaja, PDO::PARAM_INT);

        return $stmt->execute();
    }
}