<?php
/**
 * SEE - Del Contribuyente (SUNAT Perú) - Facturación electrónica directa.
 * Genera UBL 2.1, firma XML con certificado X.509 y envía por SOAP sendBill.
 */
require_once __DIR__ . "/modelos/facturacion.modelo.php";

class SunatFacturacion {
    const NS_CBC = 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2';
    const NS_CAC = 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2';
    const NS_INV = 'urn:oasis:names:specification:ubl:schema:xsd:Invoice-2';
    const NS_DS = 'http://www.w3.org/2000/09/xmldsig#';

    public static function emitirVenta($idVenta) {
        $cfg = ModeloFacturacion::config();
        if (empty($cfg['activo'])) return ['ok'=>false,'estado'=>'DESACTIVADO','mensaje'=>'Facturación electrónica desactivada.'];
        $venta = ModeloFacturacion::obtenerVentaCompleta($idVenta);
        if (!$venta) return ['ok'=>false,'estado'=>'ERROR','mensaje'=>'Venta no encontrada.'];
        if (!in_array($venta['tipo_comprobante'], ['Factura','Boleta'], true)) return ['ok'=>false,'estado'=>'NO_APLICA','mensaje'=>'El Ticket no se envía a SUNAT.'];
        $ruc = preg_replace('/\D/','',$cfg['ruc'] ?? '');
        if (strlen($ruc)!==11) return self::errorVenta($idVenta,'CONFIGURACION','El RUC del emisor debe tener 11 dígitos.');
        if ($venta['tipo_comprobante']==='Factura' && strlen(preg_replace('/\D/','',$venta['cliente_documento'] ?? ''))!==11) return self::errorVenta($idVenta,'VALIDACION','La factura requiere cliente con RUC de 11 dígitos.');
        if (empty($cfg['sol_usuario']) || $cfg['sol_clave']==='') return self::errorVenta($idVenta,'CONFIGURACION','Faltan credenciales SOL.');
        if (empty($cfg['certificado_path']) || !is_file($cfg['certificado_path'])) return self::errorVenta($idVenta,'CONFIGURACION','No se encontró el certificado digital configurado.');

        $tipo = $venta['tipo_comprobante']==='Factura' ? '01' : '03';
        $serie = $venta['tipo_comprobante']==='Factura' ? ($cfg['serie_factura'] ?: 'F001') : ($cfg['serie_boleta'] ?: 'B001');
        $partes = explode('-', (string)$venta['codigo_factura'], 2);
        if (count($partes) === 2 && preg_match('/^[FB][0-9]{3}$/', $partes[0])) {
            $serie = $partes[0];
            $numeroStr = str_pad((string)(int)$partes[1], 8, '0', STR_PAD_LEFT);
            $codigo = $serie . '-' . $numeroStr;
        } else {
            $numeroStr = '00000001';
            $codigo = $serie . '-' . $numeroStr;
        }
        $venta['codigo_factura'] = $codigo;
        $xml = self::generarXml($venta, $cfg, $tipo, $serie, $numeroStr);
        if (!$xml) return self::errorVenta($idVenta,'ERROR','No se pudo generar el XML UBL 2.1.');
        $xmlFirmado = self::firmarXml($xml, $cfg['certificado_path'], $cfg['certificado_clave'] ?? '');
        if (!$xmlFirmado) return self::errorVenta($idVenta,'FIRMA','No se pudo firmar el XML. Verifique certificado y contraseña.');

        $storage = __DIR__.'/storage/sunat';
        if (!is_dir($storage)) @mkdir($storage,0775,true);
        $xmlName = $ruc.'-'.$tipo.'-'.$serie.'-'.$numeroStr.'.xml';
        $zipName = $ruc.'-'.$tipo.'-'.$serie.'-'.$numeroStr.'.zip';
        $xmlPath = $storage.'/'.$xmlName;
        $zipPath = $storage.'/'.$zipName;
        file_put_contents($xmlPath,$xmlFirmado);
        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true) return self::errorVenta($idVenta,'ZIP','No se pudo crear el ZIP.');
        $zip->addFromString($xmlName,$xmlFirmado); $zip->close();

        $endpoint = ($cfg['ambiente']==='produccion') ? 'https://e-factura.sunat.gob.pe/ol-ti-itcpfegem/billService?wsdl' : 'https://e-beta.sunat.gob.pe/ol-ti-itcpfegem-beta/billService?wsdl';
        try {
            $soap = new SoapClient($endpoint, ['trace'=>1,'exceptions'=>true,'cache_wsdl'=>WSDL_CACHE_NONE,'connection_timeout'=>30]);
            $auth = trim($ruc).trim($cfg['sol_usuario']);
            $headerXml = '<wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"><wsse:UsernameToken><wsse:Username>'.htmlspecialchars($auth,ENT_XML1).'</wsse:Username><wsse:Password>'.htmlspecialchars($cfg['sol_clave'],ENT_XML1).'</wsse:Password></wsse:UsernameToken></wsse:Security>';
            $header = new SoapHeader('http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd','Security',new SoapVar($headerXml,XSD_ANYXML),true);
            $soap->__setSoapHeaders([$header]);
            $result = $soap->sendBill($zipName, file_get_contents($zipPath));
            $cdr = self::decodeCdr($result->applicationResponse ?? '');
            $cdrPath = '';
            if ($cdr['zip']) { $cdrPath=$storage.'/'.$ruc.'-'.$tipo.'-'.$serie.'-'.$numeroStr.'-CDR.zip'; file_put_contents($cdrPath,$cdr['zip']); }
            $estado = $cdr['codigo']==='0' ? 'ACEPTADO' : 'RECHAZADO';
            ModeloFacturacion::actualizarVentaSunat($idVenta,['estado'=>$estado,'codigo'=>$cdr['codigo'],'mensaje'=>$cdr['mensaje'],'xml'=>$xmlPath,'cdr'=>$cdrPath,'hash'=>hash('sha256',$xmlFirmado)]);
            if ($estado==='ACEPTADO') {
                $pdo=Conexion::conectar(); $st=$pdo->prepare('UPDATE ventas SET codigo_factura=:codigo WHERE id=:id'); $st->execute([':codigo'=>$codigo,':id'=>$idVenta]);
            }
            return ['ok'=>$estado==='ACEPTADO','estado'=>$estado,'codigo'=>$cdr['codigo'],'mensaje'=>$cdr['mensaje'],'numero'=>$codigo];
        } catch (Throwable $e) {
            return self::errorVenta($idVenta,'ENVIO',substr($e->getMessage(),0,1000),$xmlPath);
        }
    }

    private static function errorVenta($id,$estado,$mensaje,$xml='') { ModeloFacturacion::actualizarVentaSunat($id,['estado'=>$estado,'mensaje'=>$mensaje,'xml'=>$xml]); return ['ok'=>false,'estado'=>$estado,'mensaje'=>$mensaje]; }

    private static function esc($s) { return htmlspecialchars((string)$s, ENT_XML1|ENT_QUOTES,'UTF-8'); }
    private static function money($n) { return number_format((float)$n,2,'.',''); }
    private static function unitCode($u) { $u=strtolower(trim((string)$u)); return str_contains($u,'metro')?'MTR':'NIU'; }

    private static function generarXml($v,$c,$tipo,$serie,$numero) {
        $doc=new DOMDocument('1.0','UTF-8'); $doc->formatOutput=true;
        $root=$doc->createElementNS(self::NS_INV,'Invoice'); $root->setAttributeNS('http://www.w3.org/2000/xmlns/','xmlns:cac',self::NS_CAC); $root->setAttributeNS('http://www.w3.org/2000/xmlns/','xmlns:cbc',self::NS_CBC); $root->setAttributeNS('http://www.w3.org/2000/xmlns/','xmlns:ds',self::NS_DS); $doc->appendChild($root);
        $add=function($p,$n,$val)use($doc){$e=$doc->createElementNS($p==='cbc'?self::NS_CBC:self::NS_CAC,$p.':'.$n);$e->appendChild($doc->createTextNode((string)$val));return $e;};
        $root->appendChild($add('cbc','UBLVersionID','2.1')); $root->appendChild($add('cbc','CustomizationID','2.0')); $root->appendChild($add('cbc','ID',$serie.'-'.$numero)); $root->appendChild($add('cbc','IssueDate',date('Y-m-d',strtotime($v['fecha'])))); $root->appendChild($add('cbc','IssueTime',date('H:i:s',strtotime($v['fecha'])))); $root->appendChild($add('cbc','InvoiceTypeCode',$tipo)); $root->appendChild($add('cbc','DocumentCurrencyCode','PEN'));
        $supplier=$doc->createElementNS(self::NS_CAC,'cac:AccountingSupplierParty'); $party=$doc->createElementNS(self::NS_CAC,'cac:Party'); $pid=$doc->createElementNS(self::NS_CAC,'cac:PartyIdentification'); $pid->appendChild($add('cbc','ID',$c['ruc'])); $pid->firstChild->setAttribute('schemeID','6'); $party->appendChild($pid); $pn=$doc->createElementNS(self::NS_CAC,'cac:PartyName'); $pn->appendChild($add('cbc','Name',$c['nombre_comercial'] ?: $c['razon_social'])); $party->appendChild($pn); $plegal=$doc->createElementNS(self::NS_CAC,'cac:PartyLegalEntity'); $plegal->appendChild($add('cbc','RegistrationName',$c['razon_social'])); $addr=$doc->createElementNS(self::NS_CAC,'cac:RegistrationAddress'); $addr->appendChild($add('cbc','ID',$c['ubigeo'] ?: '150101')); $addr->appendChild($add('cbc','CityName',$c['provincia'] ?: 'Lima')); $addr->appendChild($add('cbc','District',$c['distrito'] ?: 'Lima')); $addr->appendChild($add('cbc','AddressLine',$c['direccion'])); $plegal->appendChild($addr); $party->appendChild($plegal); $supplier->appendChild($party); $root->appendChild($supplier);
        $customer=$doc->createElementNS(self::NS_CAC,'cac:AccountingCustomerParty'); $cp=$doc->createElementNS(self::NS_CAC,'cac:Party'); $cid=$doc->createElementNS(self::NS_CAC,'cac:PartyIdentification'); $docId=$v['cliente_documento'] ?: ($tipo==='03'?'00000000':''); $idNode=$add('cbc','ID',$docId); $idNode->setAttribute('schemeID',$tipo==='01'?'6':'1'); $cid->appendChild($idNode); $cp->appendChild($cid); $cle=$doc->createElementNS(self::NS_CAC,'cac:PartyLegalEntity'); $cle->appendChild($add('cbc','RegistrationName',$v['cliente_nombre'] ?: 'CLIENTE VARIOS')); $cp->appendChild($cle); $customer->appendChild($cp); $root->appendChild($customer);
        $igv=max(0,(float)$v['total']-(float)$v['subtotal']); $tax=$doc->createElementNS(self::NS_CAC,'cac:TaxTotal'); $tax->appendChild($add('cbc','TaxAmount',self::money($igv)))->setAttribute('currencyID','PEN'); $ts=$doc->createElementNS(self::NS_CAC,'cac:TaxSubtotal'); $ts->appendChild($add('cbc','TaxableAmount',self::money($v['subtotal'])))->setAttribute('currencyID','PEN'); $ts->appendChild($add('cbc','TaxAmount',self::money($igv)))->setAttribute('currencyID','PEN'); $tc=$doc->createElementNS(self::NS_CAC,'cac:TaxCategory'); $tc->appendChild($add('cbc','ID','S')); $tc->appendChild($add('cbc','Percent',self::money($c['igv'] ?: 18))); $tc->appendChild($add('cbc','TaxExemptionReasonCode','10')); $tst=$doc->createElementNS(self::NS_CAC,'cac:TaxScheme'); $tst->appendChild($add('cbc','ID','1000')); $tst->appendChild($add('cbc','Name','IGV')); $tst->appendChild($add('cbc','TaxTypeCode','VAT')); $tc->appendChild($tst); $ts->appendChild($tc); $tax->appendChild($ts); $root->appendChild($tax);
        $legal=$doc->createElementNS(self::NS_CAC,'cac:LegalMonetaryTotal'); $legal->appendChild($add('cbc','LineExtensionAmount',self::money($v['subtotal'])))->setAttribute('currencyID','PEN'); $legal->appendChild($add('cbc','TaxInclusiveAmount',self::money($v['total'])))->setAttribute('currencyID','PEN'); $legal->appendChild($add('cbc','PayableAmount',self::money($v['total'])))->setAttribute('currencyID','PEN'); $root->appendChild($legal);
        $lineNo=1; foreach($v['detalle'] as $it){ $line=$doc->createElementNS(self::NS_CAC,'cac:InvoiceLine'); $line->appendChild($add('cbc','ID',$lineNo++)); $line->appendChild($add('cbc','InvoicedQuantity',self::money($it['cantidad'])))->setAttribute('unitCode',self::unitCode($it['unidad_medida'])); $line->appendChild($add('cbc','LineExtensionAmount',self::money($it['total_item'])))->setAttribute('currencyID','PEN'); $priceRef=$doc->createElementNS(self::NS_CAC,'cac:PricingReference'); $alt=$doc->createElementNS(self::NS_CAC,'cac:AlternativeConditionPrice'); $unitInc=((float)$it['precio_unitario']*1.18); $alt->appendChild($add('cbc','PriceAmount',self::money($unitInc)))->setAttribute('currencyID','PEN'); $alt->appendChild($add('cbc','PriceTypeCode','01')); $priceRef->appendChild($alt); $line->appendChild($priceRef); $ltax=$doc->createElementNS(self::NS_CAC,'cac:TaxTotal'); $ltax->appendChild($add('cbc','TaxAmount',self::money((float)$it['total_item']*0.18)))->setAttribute('currencyID','PEN'); $lsub=$doc->createElementNS(self::NS_CAC,'cac:TaxSubtotal'); $lsub->appendChild($add('cbc','TaxableAmount',self::money($it['total_item'])))->setAttribute('currencyID','PEN'); $lsub->appendChild($add('cbc','TaxAmount',self::money((float)$it['total_item']*0.18)))->setAttribute('currencyID','PEN'); $lcat=$doc->createElementNS(self::NS_CAC,'cac:TaxCategory'); $lcat->appendChild($add('cbc','ID','S')); $lcat->appendChild($add('cbc','Percent',self::money($c['igv'] ?: 18))); $lcat->appendChild($add('cbc','TaxExemptionReasonCode','10')); $ls=$doc->createElementNS(self::NS_CAC,'cac:TaxScheme'); $ls->appendChild($add('cbc','ID','1000')); $ls->appendChild($add('cbc','Name','IGV')); $ls->appendChild($add('cbc','TaxTypeCode','VAT')); $lcat->appendChild($ls); $lsub->appendChild($lcat); $ltax->appendChild($lsub); $line->appendChild($ltax); $item=$doc->createElementNS(self::NS_CAC,'cac:Item'); $item->appendChild($add('cbc','Description',$it['descripcion'])); $line->appendChild($item); $price=$doc->createElementNS(self::NS_CAC,'cac:Price'); $price->appendChild($add('cbc','PriceAmount',self::money($it['precio_unitario'])))->setAttribute('currencyID','PEN'); $line->appendChild($price); $root->appendChild($line); }
        return $doc->saveXML();
    }

    private static function firmarXml($xml,$certPath,$password) {
        $raw=file_get_contents($certPath); if($raw===false)return false; $cert=$pkey=null;
        if (preg_match('/BEGIN CERTIFICATE/', $raw)) { $cert=$raw; $pkey=openssl_pkey_get_private($raw,$password); }
        else { $certData=[]; if(!openssl_pkcs12_read($raw,$certData,$password)) return false; $cert=$certData['cert']; $pkey=openssl_pkey_get_private($certData['pkey'],$password); }
        if(!$pkey || !$cert)return false;
        $doc=new DOMDocument(); $doc->preserveWhiteSpace=true; $doc->loadXML($xml,LIBXML_NOBLANKS); $root=$doc->documentElement;
        $canonical=$root->C14N(true,false,null,null); $digest=base64_encode(hash('sha256',$canonical,true));
        $sig=$doc->createElementNS(self::NS_DS,'ds:Signature'); $si=$doc->createElementNS(self::NS_DS,'ds:SignedInfo'); $cm=$doc->createElementNS(self::NS_DS,'ds:CanonicalizationMethod'); $cm->setAttribute('Algorithm','http://www.w3.org/TR/2001/REC-xml-c14n-20010315'); $si->appendChild($cm); $sm=$doc->createElementNS(self::NS_DS,'ds:SignatureMethod'); $sm->setAttribute('Algorithm','http://www.w3.org/2001/04/xmldsig-more#rsa-sha256'); $si->appendChild($sm); $ref=$doc->createElementNS(self::NS_DS,'ds:Reference'); $ref->setAttribute('URI',''); $trans=$doc->createElementNS(self::NS_DS,'ds:Transforms'); $tr=$doc->createElementNS(self::NS_DS,'ds:Transform'); $tr->setAttribute('Algorithm','http://www.w3.org/2000/09/xmldsig#enveloped-signature'); $trans->appendChild($tr); $tr2=$doc->createElementNS(self::NS_DS,'ds:Transform'); $tr2->setAttribute('Algorithm','http://www.w3.org/TR/2001/REC-xml-c14n-20010315'); $trans->appendChild($tr2); $ref->appendChild($trans); $dm=$doc->createElementNS(self::NS_DS,'ds:DigestMethod'); $dm->setAttribute('Algorithm','http://www.w3.org/2001/04/xmlenc#sha256'); $ref->appendChild($dm); $dv=$doc->createElementNS(self::NS_DS,'ds:DigestValue',$digest); $ref->appendChild($dv); $si->appendChild($ref); $sig->appendChild($si); $root->appendChild($sig); $signedInfoCanonical=$si->C14N(true,false,null,null); openssl_sign($signedInfoCanonical,$signature,$pkey,OPENSSL_ALGO_SHA256); $sv=$doc->createElementNS(self::NS_DS,'ds:SignatureValue',base64_encode($signature)); $sig->appendChild($sv); $ki=$doc->createElementNS(self::NS_DS,'ds:KeyInfo'); $x509=$doc->createElementNS(self::NS_DS,'ds:X509Data'); $clean=preg_replace('/-----BEGIN CERTIFICATE-----|-----END CERTIFICATE-----|\s+/','',$cert); $x509->appendChild($doc->createElementNS(self::NS_DS,'ds:X509Certificate',$clean)); $ki->appendChild($x509); $sig->appendChild($ki);
        return $doc->saveXML();
    }

    private static function decodeCdr($base64) {
        if (!$base64) return ['code'=>'9999','mensaje'=>'SUNAT no devolvió CDR.','zip'=>'']; $zipData=base64_decode($base64,true); if(!$zipData)return ['code'=>'9999','mensaje'=>'Respuesta CDR inválida.','zip'=>'']; $tmp=tempnam(sys_get_temp_dir(),'cdr_'); file_put_contents($tmp,$zipData); $z=new ZipArchive(); if($z->open($tmp)!==true)return ['code'=>'9999','mensaje'=>'No se pudo abrir CDR.','zip'=>$zipData]; $xml=''; for($i=0;$i<$z->numFiles;$i++){ $n=$z->getNameIndex($i); if(str_ends_with(strtolower($n),'.xml')){$xml=$z->getFromIndex($i);break;} } $z->close(); @unlink($tmp); if(!$xml)return ['code'=>'9999','mensaje'=>'CDR sin XML.','zip'=>$zipData]; $xd=new DOMDocument(); @$xd->loadXML($xml); $codes=$xd->getElementsByTagNameNS(self::NS_CBC,'ResponseCode'); $desc=$xd->getElementsByTagNameNS(self::NS_CBC,'Description'); return ['code'=>$codes->length?$codes->item(0)->nodeValue:'9999','mensaje'=>$desc->length?$desc->item(0)->nodeValue:'Sin descripción','zip'=>$zipData];
    }
}
