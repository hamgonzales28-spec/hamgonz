<?php
session_start();

require_once "config/config.php";
require_once "config/conexion.php";

require_once "controladores/plantilla.controlador.php";
require_once "controladores/auth.controlador.php";
require_once "controladores/exportar_excel.controlador.php";
require_once "controladores/exportar_pdf.controlador.php";
require_once "controladores/productos.controlador.php";

require_once "controladores/ventas.controlador.php";
require_once "controladores/facturacion.controlador.php";
require_once "lib_sunat.php";

require_once "modelos/usuarios.modelo.php";
require_once "modelos/productos.modelo.php";
require_once "modelos/ventas.modelo.php";
require_once "modelos/clientes.modelo.php";
require_once "modelos/facturacion.modelo.php";


require_once "controladores/compras.controlador.php";
require_once "modelos/compras.modelo.php";

// Comprobante público: no requiere iniciar sesión.
// Se atiende aquí también para servidores donde Apache redirige comprobante.php a index.php.
if (isset($_GET["ruta"]) && in_array($_GET["ruta"], ["comprobante", "comprobante.php"], true)) {
    require __DIR__ . "/comprobante.php";
    exit();
}
if (basename($_SERVER["SCRIPT_NAME"] ?? "") === "comprobante.php") {
    require __DIR__ . "/comprobante.php";
    exit();
}
// Manejar exportaciones únicamente cuando el usuario lo solicite mediante un parámetro específico
if (isset($_GET["exportar"]) && $_GET["exportar"] === "excel") {
    ControladorExportarExcel::ctrExportarExcel();
    exit();
}

$plantilla = new ControladorPlantilla();
$plantilla->ctrPlantilla();