<?php

if (isset($_POST["documento"]) && isset($_POST["tipo"])) {

    $documento = trim($_POST["documento"]);
    $tipo = trim($_POST["tipo"]);
    $token = 'sk_18401.hu5G2HUjx3WUrZHxarVz7FaYiOa6GM3I'; 

    if ($tipo == "dni") {
        $url = "https://api.decolecta.com/v1/reniec/dni/" . $documento;
    } else if ($tipo == "ruc") {
        $url = "https://api.decolecta.com/v1/sunat/ruc?numero=" . $documento;
    } else {
        echo json_encode(["error" => true, "message" => "Tipo de documento no válido"]);
        exit;
    }

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer ' . $token,
            'Accept: application/json'
        ),
    ));

    $response = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo json_encode(["error" => true, "message" => "Error cURL: " . $err]);
        exit;
    }

    if ($httpCode !== 200) {
        echo json_encode(["error" => true, "httpCode" => $httpCode, "message" => "Documento no encontrado o token inválido"]);
        exit;
    }

    $data = json_decode($response, true);
    if (!$data || !is_array($data)) {
        echo json_encode(["error" => true, "message" => "Respuesta inválida de la API"]);
        exit;
    }

    $data = array_change_key_case($data, CASE_LOWER);

    if ($tipo == "ruc") {
        $razonSocial = $data["razon_social"]
            ?? $data["company_name"]
            ?? $data["nombre_o_razon_social"]
            ?? $data["nombre"]
            ?? $data["business_name"]
            ?? $data["full_name"]
            ?? $data["razonsocial"]
            ?? "";

        $direccion = $data["direccion"]
            ?? $data["address"]
            ?? $data["direccion_fiscal"]
            ?? $data["domicilio_fiscal"]
            ?? $data["fiscal_address"]
            ?? "";

        $data["razonSocial"] = trim((string) $razonSocial);
        $data["nombre"] = trim((string) $razonSocial);
        $data["direccion"] = trim((string) $direccion);
    }

    if ($tipo == "dni") {
        $nombres = $data["first_name"] ?? $data["nombres"] ?? $data["name"] ?? $data["nombre"] ?? "";
        $apePaterno = $data["first_lastname"] ?? $data["apellido_paterno"] ?? $data["apellidoPaterno"] ?? $data["paterno"] ?? "";
        $apeMaterno = $data["second_lastname"] ?? $data["apellido_materno"] ?? $data["apellidoMaterno"] ?? $data["materno"] ?? "";

        $nombreCompleto = trim(($nombres . " " . $apePaterno . " " . $apeMaterno));
        $razonSocial = $nombreCompleto ?: ($data["nombre_completo"] ?? $data["nombreCompleto"] ?? $data["razon_social"] ?? $data["razonSocial"] ?? "");
        $data["nombres"] = $nombres;
        $data["apellidoPaterno"] = $apePaterno;
        $data["apellidoMaterno"] = $apeMaterno;
        $data["nombreCompleto"] = $nombreCompleto;
        $data["razonSocial"] = $razonSocial;
    }

    echo json_encode($data);
}