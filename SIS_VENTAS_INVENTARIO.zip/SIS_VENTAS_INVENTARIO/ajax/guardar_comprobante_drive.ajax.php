<?php
header('Content-Type: application/json; charset=utf-8');
http_response_code(410);
echo json_encode([
    'ok' => false,
    'mensaje' => 'El almacenamiento en Google Drive está desactivado. El comprobante se guarda en el sistema local.'
], JSON_UNESCAPED_UNICODE);
