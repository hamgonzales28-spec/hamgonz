<?php

// 1. Incluimos primero la conexión usando la ruta relativa desde la carpeta /ajax/// Si tu archivo de conexión está dentro de 'config', cambia a "../config/conexion.php"
require_once "../controladores/productos.controlador.php";
require_once "../modelos/productos.modelo.php";

class AjaxProductos {

    public $idProducto;

    public function ajaxEditarProducto() {

        $item = "id";
        $valor = $this->idProducto;
        $respuesta = ControladorProductos::ctrMostrarProductos($item, $valor);
        echo json_encode($respuesta);
    }
}

/*=============================================
PETICIÓN AJAX PARA EDITAR PRODUCTO
=============================================*/
if (isset($_POST["idProducto"])) {

    $editar = new AjaxProductos();
    $editar->idProducto = $_POST["idProducto"];
    $editar->ajaxEditarProducto();

}