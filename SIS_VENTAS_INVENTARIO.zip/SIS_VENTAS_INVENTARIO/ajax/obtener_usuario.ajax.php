<?php
require_once "../modelos/usuarios.modelo.php";

if (isset($_POST["idUsuario"])) {
    $usuario = ModeloUsuarios::mdlMostrarUsuarios("usuarios", "id", $_POST["idUsuario"]);
    echo json_encode($usuario);
}
