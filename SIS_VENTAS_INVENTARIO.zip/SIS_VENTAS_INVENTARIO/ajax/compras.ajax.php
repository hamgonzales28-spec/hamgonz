<?php
if (ob_get_length()) {
    ob_clean();
}

error_reporting(0);
ini_set('display_errors', 0);

// Conexión centralizada en config/conexion.php
if (file_exists("../config/conexion.php")) {
    require_once "../config/conexion.php";
} else if (file_exists("config/conexion.php")) {
    require_once "config/conexion.php";
}

class AjaxCompras {

    public $idCompra;

    public function ajaxObtenerDetalleCompra() {

        $valor = $this->idCompra;
        $respuesta = array();

        try {
            if (class_exists("Conexion")) {
                $conexion = Conexion::conectar();
                
                // 1. Intentar consulta por tabla de detalle
                $stmt = $conexion->prepare("SELECT d.*, p.descripcion 
                                           FROM detalle_compras d 
                                           LEFT JOIN productos p ON d.id_producto = p.id 
                                           WHERE d.id_compra = :id_compra");
                $stmt->bindParam(":id_compra", $valor, PDO::PARAM_INT);
                
                if ($stmt->execute()) {
                    $respuesta = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }

                // 2. Si se guarda como JSON en la tabla compras
                if (empty($respuesta)) {
                    $stmtJson = $conexion->prepare("SELECT productos FROM compras WHERE id = :id");
                    $stmtJson->bindParam(":id", $valor, PDO::PARAM_INT);
                    $stmtJson->execute();
                    $compraJson = $stmtJson->fetch(PDO::FETCH_ASSOC);

                    if ($compraJson && !empty($compraJson["productos"])) {
                        $productosArray = json_decode($compraJson["productos"], true);

                        if (is_array($productosArray)) {
                            foreach ($productosArray as $prod) {
                                $idProd = isset($prod["id"]) ? $prod["id"] : 0;
                                $stmtP = $conexion->prepare("SELECT descripcion FROM productos WHERE id = :id");
                                $stmtP->bindParam(":id", $idProd, PDO::PARAM_INT);
                                $stmtP->execute();
                                $pData = $stmtP->fetch(PDO::FETCH_ASSOC);

                                $respuesta[] = array(
                                    "descripcion" => $pData ? $pData["descripcion"] : "Producto #" . $idProd,
                                    "cantidad" => isset($prod["cantidad"]) ? $prod["cantidad"] : 1,
                                    "precio_unitario" => isset($prod["precio"]) ? $prod["precio"] : 0,
                                    "total_producto" => isset($prod["total"]) ? $prod["total"] : 0
                                );
                            }
                        }
                    }
                }
            }
        } catch (Exception $e) {
            $respuesta = array();
        }

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($respuesta ? $respuesta : array(), JSON_UNESCAPED_UNICODE);
        exit();
    }
}

if (isset($_POST["idCompra"])) {
    $detalle = new AjaxCompras();
    $detalle->idCompra = $_POST["idCompra"];
    $detalle->ajaxObtenerDetalleCompra();
}