<?php
require_once __DIR__ . "/config.php";

class Conexion {
    public static function conectar() {
        try {
            $link = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
            $link->exec("SET NAMES utf8mb4");
            return $link;
        } catch (PDOException $e) {
            die("Error en la conexión PDO: " . $e->getMessage());
        }
    }
}
