<?php
define("BASE_URL", "http://localhost/SIS_VENTAS_INVENTARIO/");
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "sistema_ventas_inventario");

define("SYSTEM_NAME", "SIS_VENTAS");

// URL pública para los comprobantes enviados por WhatsApp.
// En producción coloca aquí tu dominio, por ejemplo: https://midominio.com/SIS_VENTAS_INVENTARIO
define("PUBLIC_BASE_URL", "");

// Google Drive: completar con un token OAuth vigente y el ID de la carpeta destino.
define("GOOGLE_DRIVE_ACCESS_TOKEN", "");
define("GOOGLE_DRIVE_FOLDER_ID", "1Ro432ErwQqWzbYzGIvtgZPmEV9CsFwFr");
define("GOOGLE_DRIVE_REFRESH_TOKEN", "");
define("GOOGLE_DRIVE_CLIENT_ID", "");
define("GOOGLE_DRIVE_CLIENT_SECRET", "");

define("WHATSAPP_TOKEN", "");
define("WHATSAPP_PHONE_ID", "");