<?php
/**
 * Cliente mínimo para subir comprobantes PDF a Google Drive mediante la API v3.
 * Requiere un OAuth access token con el alcance https://www.googleapis.com/auth/drive.file
 * y que la carpeta de destino esté compartida con la cuenta que generó el token.
 */
class GoogleDrive {
    private static $accessToken = null;
    private static $tokenError = '';

    public static function obtenerEnlaceCarpeta($carpetaId = '') {
        return $carpetaId !== ''
            ? 'https://drive.google.com/drive/folders/' . rawurlencode($carpetaId)
            : '';
    }

    public static function obtenerEnlaceComprobante($codigo, $carpetaId = '', $reintento = false) {
        if ($carpetaId === '' || !self::obtenerToken() || !function_exists('curl_init')) {
            return '';
        }

        $nombre = self::limpiarNombre('Comprobante_' . (defined('SYSTEM_NAME') ? SYSTEM_NAME : 'SIS_VENTAS') . '_' . $codigo . '.pdf');
        $consulta = "name = '" . str_replace("'", "\\'", $nombre) . "' and '" . str_replace("'", "\\'", $carpetaId) . "' in parents and trashed = false";
        $url = 'https://www.googleapis.com/drive/v3/files?' . http_build_query([
            'q' => $consulta,
            'fields' => 'files(id,name)',
            'pageSize' => 1,
            'spaces' => 'drive'
        ]);

        $curl = curl_init($url);
        curl_setopt_array($curl, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . self::$accessToken],
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 6,
            CURLOPT_SSL_VERIFYPEER => true
        ]);
        $respuesta = curl_exec($curl);
        $codigoHttp = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if (!$reintento && in_array($codigoHttp, [401, 403], true)) {
            self::$accessToken = null;
            self::obtenerToken(true);
            return self::obtenerEnlaceComprobante($codigo, $carpetaId, true);
        }
        $datos = json_decode((string)$respuesta, true);

        if (empty($datos['files'][0]['id'])) {
            return '';
        }

        $archivoId = $datos['files'][0]['id'];
        self::hacerAccesible($archivoId);
        return 'https://drive.google.com/file/d/' . rawurlencode($archivoId) . '/view';
    }

    public static function subirPdf($contenido, $nombre, $carpetaId = '', $reintento = false) {
        if ($carpetaId === '' || !self::obtenerToken()) {
            return [
                'ok' => false,
                'omitido' => true,
                'mensaje' => self::$tokenError !== '' ? self::$tokenError : 'Google Drive no está configurado.'
            ];
        }

        if (!function_exists('curl_init')) {
            return ['ok' => false, 'mensaje' => 'La extensión cURL de PHP no está habilitada.'];
        }

        $metadata = json_encode([
            'name' => self::limpiarNombre($nombre),
            'mimeType' => 'application/pdf',
            'parents' => [$carpetaId]
        ], JSON_UNESCAPED_UNICODE);

        $separador = 'svi_' . bin2hex(random_bytes(12));
        $cuerpo = '--' . $separador . "\r\n"
            . "Content-Type: application/json; charset=UTF-8\r\n\r\n"
            . $metadata . "\r\n"
            . '--' . $separador . "\r\n"
            . "Content-Type: application/pdf\r\n\r\n"
            . $contenido . "\r\n"
            . '--' . $separador . "--\r\n";

        $curl = curl_init('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true&fields=id,name,webViewLink');
        curl_setopt_array($curl, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $cuerpo,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . self::$accessToken,
                'Content-Type: multipart/related; boundary=' . $separador,
                'Content-Length: ' . strlen($cuerpo)
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true
        ]);

        $respuesta = curl_exec($curl);
        $codigo = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $error = curl_error($curl);
        curl_close($curl);

        if ($respuesta === false || $codigo < 200 || $codigo >= 300) {
            if (!$reintento && in_array($codigo, [401, 403], true)) {
                self::$accessToken = null;
                if (self::obtenerToken(true)) {
                    return self::subirPdf($contenido, $nombre, $carpetaId, true);
                }
            }
            $detalle = $error !== '' ? $error : 'HTTP ' . $codigo;
            return ['ok' => false, 'mensaje' => 'No se pudo subir el comprobante a Google Drive: ' . $detalle];
        }

        $datos = json_decode($respuesta, true);
        if (empty($datos['id'])) {
            return ['ok' => false, 'mensaje' => 'Google Drive no devolvió el identificador del archivo.'];
        }

        $datos['acceso_publico'] = self::hacerAccesible($datos['id']);
        $datos['webViewLink'] = 'https://drive.google.com/file/d/' . rawurlencode($datos['id']) . '/view';
        return ['ok' => true, 'datos' => $datos];
    }

    private static function hacerAccesible($archivoId) {
        $url = 'https://www.googleapis.com/drive/v3/files/' . rawurlencode($archivoId) . '/permissions?' . http_build_query([
            'supportsAllDrives' => 'true',
            'sendNotificationEmail' => 'false'
        ]);
        $curl = curl_init($url);
        curl_setopt_array($curl, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode([
                'type' => 'anyone',
                'role' => 'reader',
                'allowFileDiscovery' => false
            ]),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . self::$accessToken,
                'Content-Type: application/json'
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 6,
            CURLOPT_SSL_VERIFYPEER => true
        ]);

        curl_exec($curl);
        $codigo = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        return $codigo >= 200 && $codigo < 300;
    }

    private static function obtenerToken($forzar = false) {
        if (!$forzar && self::$accessToken !== null) {
            return self::$accessToken !== '';
        }

        self::$accessToken = defined('GOOGLE_DRIVE_ACCESS_TOKEN') ? trim(GOOGLE_DRIVE_ACCESS_TOKEN) : '';

        // Google OAuth Playground entrega access tokens de duración limitada.
        // La renovación se activa al completar también GOOGLE_DRIVE_CLIENT_SECRET.
        if (defined('GOOGLE_DRIVE_REFRESH_TOKEN') && GOOGLE_DRIVE_REFRESH_TOKEN !== ''
            && defined('GOOGLE_DRIVE_CLIENT_ID') && GOOGLE_DRIVE_CLIENT_ID !== ''
            && defined('GOOGLE_DRIVE_CLIENT_SECRET') && GOOGLE_DRIVE_CLIENT_SECRET !== '') {
            $curl = curl_init('https://oauth2.googleapis.com/token');
            curl_setopt_array($curl, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => http_build_query([
                    'client_id' => GOOGLE_DRIVE_CLIENT_ID,
                    'client_secret' => GOOGLE_DRIVE_CLIENT_SECRET,
                    'refresh_token' => GOOGLE_DRIVE_REFRESH_TOKEN,
                    'grant_type' => 'refresh_token'
                ]),
                CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_TIMEOUT => 8,
                CURLOPT_SSL_VERIFYPEER => true
            ]);
            $respuesta = curl_exec($curl);
            curl_close($curl);
            $datos = json_decode((string)$respuesta, true);
            if (!empty($datos['access_token'])) {
                self::$accessToken = $datos['access_token'];
                self::$tokenError = '';
            } else {
                // Conservar el access token configurado como respaldo. Esto
                // permite trabajar mientras se reemplaza el refresh token;
                // si también está caducado, la API devolverá el error real.
                self::$tokenError = 'No se pudo renovar el acceso OAuth de Google Drive.';
            }
        }

        return self::$accessToken !== '';
    }

    private static function limpiarNombre($nombre) {
        $nombre = preg_replace('/[^a-zA-Z0-9._-]/', '_', (string)$nombre);
        return substr($nombre ?: 'comprobante.pdf', 0, 180);
    }
}
