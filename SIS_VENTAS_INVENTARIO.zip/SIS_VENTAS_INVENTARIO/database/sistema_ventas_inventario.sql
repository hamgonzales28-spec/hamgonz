-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-08-2026 a las 20:40:08
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema_ventas_inventario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cajas`
--

CREATE TABLE `cajas` (
  `id` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `monto_inicial` decimal(10,2) NOT NULL,
  `monto_ventas_efectivo` decimal(10,2) DEFAULT 0.00,
  `monto_compras_efectivo` decimal(10,2) DEFAULT 0.00,
  `monto_final_esperado` decimal(10,2) DEFAULT 0.00,
  `monto_final_real` decimal(10,2) DEFAULT 0.00,
  `diferencia` decimal(10,2) DEFAULT 0.00,
  `fecha_apertura` datetime DEFAULT current_timestamp(),
  `fecha_cierre` datetime DEFAULT NULL,
  `estado` enum('abierta','cerrada') DEFAULT 'abierta'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `cajas`
--

INSERT INTO `cajas` (`id`, `id_usuario`, `monto_inicial`, `monto_ventas_efectivo`, `monto_compras_efectivo`, `monto_final_esperado`, `monto_final_real`, `diferencia`, `fecha_apertura`, `fecha_cierre`, `estado`) VALUES
(1, 1, 500.00, 0.00, 0.00, 500.00, 88714.80, 88214.80, '2026-08-10 23:34:31', '2026-08-10 23:35:46', 'cerrada'),
(2, 1, 1000.00, 5900.00, 0.00, 6900.00, 1700.00, -5200.00, '2026-08-11 00:09:41', '2026-08-13 02:43:42', 'cerrada'),
(3, 1, 1000.00, 0.00, 0.00, 1000.00, 1700.00, 700.00, '2026-08-13 02:44:25', '2026-08-13 02:44:39', 'cerrada'),
(4, 1, 1000.00, 1720.00, 0.00, 2720.00, 3420.00, 700.00, '2026-08-13 02:46:38', '2026-08-13 02:51:46', 'cerrada'),
(5, 1, 1000.00, 360.00, 0.00, 1360.00, 3420.00, 2060.00, '2026-08-13 09:09:24', '2026-08-14 01:42:56', 'cerrada'),
(6, 1, 2000.00, 4120.00, 0.00, 6120.00, 6120.00, 0.00, '2026-08-14 01:47:29', '2026-08-14 01:52:07', 'cerrada'),
(7, 1, 2000.00, 4120.00, 1500.00, 4620.00, 3120.00, -1500.00, '2026-08-14 01:52:53', '2026-08-14 01:56:29', 'cerrada'),
(8, 1, 2000.00, 0.00, 0.00, 2000.00, 0.00, -2000.00, '2026-08-14 14:43:15', '2026-08-17 18:12:54', 'cerrada'),
(9, 1, 1000.00, 2.00, 0.00, 1002.00, 2.00, -1000.00, '2026-08-17 18:37:40', '2026-08-17 19:04:35', 'cerrada'),
(10, 1, 1000.00, 2.00, 0.00, 1002.00, 2.00, -1000.00, '2026-08-17 19:17:42', '2026-08-17 19:18:15', 'cerrada'),
(11, 1, 1000.00, 36.00, 0.00, 1036.00, 36.00, -1000.00, '2026-08-17 19:37:40', '2026-08-17 19:42:50', 'cerrada'),
(12, 1, 1000.00, 2.00, 0.00, 1002.00, 2.00, -1000.00, '2026-08-17 19:50:23', '2026-08-17 19:51:26', 'cerrada'),
(13, 1, 1000.00, 32.00, 10.00, 1022.00, 32.00, -990.00, '2026-08-17 20:08:32', '2026-08-17 20:13:31', 'cerrada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `categoria` varchar(255) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `categoria`, `fecha`) VALUES
(1, 'Tecnología', '2026-08-12 07:16:21'),
(2, 'Accesorios', '2026-08-12 07:16:21'),
(3, 'Oficina', '2026-08-12 07:16:21'),
(4, 'Pendas', '2026-08-18 00:36:31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `documento` varchar(15) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `compras` int(11) DEFAULT 0,
  `ultima_compra` datetime DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `documento`, `nombre`, `email`, `telefono`, `direccion`, `compras`, `ultima_compra`, `fecha_registro`) VALUES
(1, '75208366', 'Hamilton Gonzales', 'hamgonzales.28@gmail.com', '987654321', 'san juan de miraflores', 0, NULL, '2026-08-11 05:55:46'),
(2, '76543218', 'Damaris Rosa', 'dam@gmail.com', '912345678', '000156', 0, NULL, '2026-08-11 05:57:15'),
(3, '74362211', 'Maria Anadeli Horna', 'ana@gmail.com', '998877600', 'lima', 0, NULL, '2026-08-11 15:27:54');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id` int(11) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `proveedor` varchar(255) NOT NULL,
  `metodo_pago` varchar(50) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`id`, `codigo`, `proveedor`, `metodo_pago`, `total`, `fecha`) VALUES
(1, 'COMP-10001', 'provedor', 'Transferencia', 1500.00, '2026-08-13 05:03:17'),
(2, 'COMP-10002', 'Provedor', 'Transferencia', 15.00, '2026-08-13 05:11:29'),
(3, 'COMP-10003', 'general', 'Efectivo', 60.00, '2026-08-13 05:13:17'),
(4, 'COMP-10004', 'general', 'Efectivo', 10.00, '2026-08-13 07:04:53'),
(5, 'COMP-10005', 'ham', 'Efectivo', 40.00, '2026-08-13 07:06:30'),
(6, 'COMP-10006', 'ham', 'Efectivo', 300.00, '2026-08-13 07:17:55'),
(7, 'COMP-10007', 'ham', 'Transferencia', 300.00, '2026-08-13 07:18:36'),
(8, 'COMP-10008', 'general', 'Efectivo', 1500.00, '2026-08-14 06:54:39'),
(9, 'COMP-10009', ' hamg_tech', 'Transferencia', 10.00, '2026-08-15 07:02:49'),
(10, 'COMP-10010', ' hamg_tech', 'Efectivo', 0.00, '2026-08-17 23:58:46'),
(11, 'COMP-10011', ' hamg_tech', 'Efectivo', 0.00, '2026-08-18 00:17:07'),
(12, 'COMP-10012', ' hamg_tech', 'Efectivo', 10.00, '2026-08-18 01:12:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_compras`
--

CREATE TABLE `detalle_compras` (
  `id` int(11) NOT NULL,
  `id_compra` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `total_producto` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_compras`
--

INSERT INTO `detalle_compras` (`id`, `id_compra`, `id_producto`, `cantidad`, `precio_unitario`, `total_producto`) VALUES
(1, 1, 10, 1, 1500.00, 1500.00),
(2, 2, 17, 1, 15.00, 15.00),
(3, 3, 16, 2, 30.00, 60.00),
(4, 4, 16, 1, 10.00, 10.00),
(5, 5, 16, 4, 10.00, 40.00),
(6, 6, 9, 1, 300.00, 300.00),
(7, 7, 9, 1, 300.00, 300.00),
(8, 8, 10, 1, 1500.00, 1500.00),
(9, 9, 14, 1, 10.00, 10.00),
(10, 10, 18, 1, 0.00, 0.00),
(11, 11, 18, 1, 0.00, 0.00),
(12, 12, 14, 1, 10.00, 10.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `codigo` varchar(50) NOT NULL,
  `codigo_barras` varchar(50) DEFAULT NULL,
  `descripcion` varchar(255) NOT NULL,
  `unidad_medida` varchar(30) NOT NULL DEFAULT 'Unidad',
  `stock` int(11) NOT NULL DEFAULT 0,
  `precio_venta` decimal(10,2) NOT NULL DEFAULT 0.00,
  `precio_compra` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `productos` ADD UNIQUE KEY `uk_productos_codigo_barras` (`codigo_barras`);

--
-- Volcado de datos para la tabla `productos`
--

-- Migración para bases de datos existentes (MariaDB/MySQL compatible)
ALTER TABLE `productos` ADD COLUMN IF NOT EXISTS `unidad_medida` varchar(30) NOT NULL DEFAULT 'Unidad' AFTER `descripcion`;

INSERT INTO `productos` (`id`, `id_categoria`, `codigo`, `descripcion`, `unidad_medida`, `stock`, `precio_venta`, `precio_compra`) VALUES
(8, 1, 'PROD008', 'TELEFONO', 'Unidad', 25, 950.00, 0.00),
(9, 1, 'PROD009', 'Scanner', 'Unidad', 18, 360.00, 300.00),
(10, 3, 'PROD010', 'laptop lenovo', 'Unidad', 15, 1700.00, 1500.00),
(14, 3, 'PROD-184', 'hojas a4', 'Unidad', 32, 14.00, 10.00),
(15, 2, 'PROD-942', 'lampara', 'Unidad', 99, 35.00, 0.00),
(16, 2, 'PROD-623', 'tela', 'Metro', 35, 12.00, 10.00),
(17, 2, 'PROD-865', 'wegwe', 'Unidad', 109, 20.00, 15.00),
(18, 3, 'PROD-125', 'lapiz', 'Unidad', 12, 2.00, 0.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL,
  `doc_identidad` varchar(15) DEFAULT NULL,
  `ruc` varchar(15) DEFAULT NULL,
  `razon_social` varchar(150) NOT NULL,
  `contacto` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id`, `doc_identidad`, `ruc`, `razon_social`, `contacto`, `telefono`, `email`, `direccion`, `fecha`) VALUES
(1, NULL, NULL, 'provedor', NULL, NULL, NULL, NULL, '2026-08-15 05:54:21'),
(2, NULL, NULL, 'general', NULL, NULL, NULL, NULL, '2026-08-15 05:54:21'),
(3, '', '', 'ham', '', '', '', '', '2026-08-15 05:54:21'),
(4, '75208366', '009988776655', ' hamg_tech', 'hamlet g', '998776654', 'hamgonzales.28@gmail.com', 'lima', '2026-08-15 06:55:28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `perfil` varchar(50) NOT NULL DEFAULT 'Administrador'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `usuario`, `password`, `perfil`) VALUES
(1, 'Administrador', 'admin', 'admin123', 'Administrador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `codigo_factura` varchar(50) NOT NULL,
  `tipo_comprobante` varchar(20) NOT NULL DEFAULT 'Boleta',
  `id_usuario` int(11) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `pague_con` decimal(10,2) NOT NULL DEFAULT 0.00,
  `vuelto` decimal(10,2) NOT NULL DEFAULT 0.00,
  `metodo_pago` varchar(50) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `codigo_factura`, `tipo_comprobante`, `id_usuario`, `id_cliente`, `subtotal`, `total`, `pague_con`, `vuelto`, `metodo_pago`, `fecha`) VALUES
(1, 'VNT-20260810-168', 'Boleta', 1, NULL, 770.00, 908.60, 0.00, 0.00, 'Efectivo', '2026-08-09 21:16:18'),
(3, 'BOL-20260810-956', 'Boleta', 1, NULL, 770.00, 908.60, 0.00, 0.00, 'Efectivo', '2026-08-09 21:42:51'),
(5, 'BOL-20260810-829', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 21:50:39'),
(6, 'BOL-20260810-196', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 21:55:23'),
(7, 'BOL-20260810-452', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:02:13'),
(8, 'BOL-20260810-534', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:08:12'),
(9, 'BOL-20260810-708', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:14:33'),
(11, 'BOL-20260810-925', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:20:16'),
(12, 'BOL-20260810-564', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:21:14'),
(13, 'BOL-20260810-282', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:21:31'),
(14, 'BOL-20260810-583', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:21:50'),
(15, 'BOL-20260810-765', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:25:34'),
(16, 'BOL-20260810-314', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:27:04'),
(17, 'BOL-20260810-410', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:36:01'),
(18, 'BOL-20260810-908', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:39:24'),
(19, 'BOL-20260810-618', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:43:43'),
(20, 'BOL-20260810-313', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:57:24'),
(21, 'BOL-20260810-201', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 22:57:40'),
(23, 'BOL-20260810-649', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-09 23:38:15'),
(24, 'BOL-20260810-647', 'Boleta', 1, NULL, 590.00, 696.20, 0.00, 0.00, 'Efectivo', '2026-08-10 00:04:43'),
(25, 'BOL-20260810-215', 'Boleta', 1, NULL, 590.00, 696.20, 0.00, 0.00, 'Efectivo', '2026-08-10 00:20:33'),
(27, 'BOL-20260810-903', 'Boleta', 1, NULL, 590.00, 696.20, 0.00, 0.00, 'Efectivo', '2026-08-10 00:56:41'),
(28, 'BOL-20260810-455', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-10 00:57:17'),
(29, 'BOL-20260810-388', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-10 01:01:11'),
(30, 'BOL-20260810-954', 'Boleta', 1, NULL, 180.00, 212.40, 0.00, 0.00, 'Efectivo', '2026-08-10 01:01:29'),
(31, 'BOL-20260810-808', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 01:10:23'),
(32, 'BOL-20260810-364', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 01:13:50'),
(33, 'BOL-20260810-563', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 01:14:02'),
(34, 'BOL-20260810-405', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 01:15:45'),
(35, 'BOL-20260810-400', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 01:16:16'),
(36, 'BOL-20260810-773', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 01:28:58'),
(37, 'BOL-20260810-527', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 01:42:16'),
(38, 'BOL-20260810-128', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 01:52:43'),
(39, 'BOL-20260810-392', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 01:58:52'),
(40, 'BOL-20260810-577', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 01:59:19'),
(41, 'BOL-20260810-523', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 02:00:05'),
(42, 'BOL-20260810-743', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 02:06:42'),
(43, 'BOL-20260810-119', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 02:07:35'),
(44, 'BOL-20260810-800', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 02:11:41'),
(45, 'BOL-20260810-240', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 02:11:48'),
(46, 'BOL-20260810-354', 'Boleta', 1, NULL, 2000.00, 2360.00, 0.00, 0.00, 'Efectivo', '2026-08-10 02:15:41'),
(51, 'BOL-20260810-660', 'Boleta', 1, NULL, 2000.00, 2360.00, 2360.00, 0.00, 'Efectivo', '2026-08-10 11:44:20'),
(53, 'BOL-20260810-530', 'Boleta', 1, NULL, 2000.00, 2360.00, 2360.00, 0.00, 'Efectivo', '2026-08-10 11:56:50'),
(54, 'BOL-20260810-801', 'Boleta', 1, NULL, 2000.00, 2360.00, 2360.00, 0.00, 'Efectivo', '2026-08-10 11:59:24'),
(55, 'BOL-20260810-682', 'Boleta', 1, NULL, 2000.00, 2360.00, 2360.00, 0.00, 'Yape/Plin', '2026-08-10 13:40:32'),
(56, 'BOL-20260810-594', 'Boleta', 1, NULL, 2000.00, 2360.00, 2360.00, 0.00, 'Yape/Plin', '2026-08-10 13:45:30'),
(57, 'BOL-20260810-436', 'Boleta', 1, NULL, 2000.00, 2360.00, 2360.00, 0.00, 'Efectivo', '2026-08-10 13:46:15'),
(58, 'BOL-20260810-761', 'Boleta', 1, NULL, 2000.00, 2360.00, 2020.00, 0.00, 'Efectivo', '2026-08-10 13:54:21'),
(59, 'BOL-20260810-643', 'Boleta', 1, NULL, 2000.00, 2360.00, 3000.00, 0.00, 'Efectivo', '2026-08-10 14:11:36'),
(60, 'BOL-20260810-945', 'Boleta', 1, NULL, 2000.00, 2360.00, 2400.00, 0.00, 'Efectivo', '2026-08-10 14:27:46'),
(61, 'BOL-20260810-207', 'Boleta', 1, NULL, 4000.00, 4000.00, 4060.00, 60.00, 'Efectivo', '2026-08-10 15:14:09'),
(62, 'BOL-20260810-268', 'Boleta', 1, NULL, 2000.00, 2000.00, 2060.00, 60.00, 'Efectivo', '2026-08-10 15:56:14'),
(63, 'BOL-20260810-481', 'Boleta', 1, NULL, 2590.00, 2590.00, 2600.00, 10.00, 'Efectivo', '2026-08-10 15:58:13'),
(64, 'BOL-20260811-152', 'Boleta', 1, NULL, 2000.00, 2000.00, 2020.00, 20.00, 'Efectivo', '2026-08-10 18:24:33'),
(65, 'BOL-20260811-855', 'Boleta', 1, NULL, 2000.00, 2000.00, 2030.00, 30.00, 'Efectivo', '2026-08-10 18:40:15'),
(66, 'BOL-20260811-841', 'Boleta', 1, NULL, 450.00, 450.00, 500.00, 50.00, 'Efectivo', '2026-08-10 20:28:28'),
(67, 'BOL-20260811-654', 'Boleta', 1, NULL, 450.00, 450.00, 500.00, 50.00, 'Efectivo', '2026-08-10 20:59:15'),
(68, 'BOL-20260811-557', 'Boleta', 1, NULL, 450.00, 450.00, 500.00, 50.00, 'Efectivo', '2026-08-10 21:03:54'),
(69, 'BOL-20260811-551', 'Boleta', 1, NULL, 450.00, 450.00, 500.00, 50.00, 'Efectivo', '2026-08-10 21:15:47'),
(70, 'BOL-20260811-862', 'Boleta', 1, NULL, 450.00, 450.00, 500.00, 50.00, 'Efectivo', '2026-08-10 21:19:51'),
(71, 'BOL-20260811-130', 'Boleta', 1, NULL, 2450.00, 2450.00, 2500.00, 50.00, 'Efectivo', '2026-08-10 21:37:20'),
(72, 'BOL-20260811-641', 'Boleta', 1, NULL, 2450.00, 2450.00, 2500.00, 50.00, 'Efectivo', '2026-08-10 21:38:01'),
(73, 'BOL-20260811-882', 'Boleta', 1, NULL, 700.00, 700.00, 720.00, 20.00, 'Efectivo', '2026-08-10 23:32:07'),
(74, 'TKT-20260811-700', 'Ticket', 1, 2, 0.00, 0.00, 0.00, 0.00, 'Efectivo', '2026-08-11 03:33:10'),
(75, 'TKT-20260811-463', 'Ticket', 1, 1, 0.00, 0.00, 0.00, 0.00, 'Yape/Plin', '2026-08-11 03:34:02'),
(76, 'TKT-20260811-835', 'Ticket', 1, 1, 0.00, 0.00, 0.00, 0.00, 'Yape/Plin', '2026-08-11 03:35:05'),
(77, 'TKT-20260811-896', 'Ticket', 1, 1, 700.00, 700.00, 730.00, 30.00, 'Efectivo', '2026-08-11 03:51:28'),
(78, 'TKT-20260811-226', 'Ticket', 1, 1, 2100.00, 2100.00, 2110.00, 10.00, 'Efectivo', '2026-08-11 09:23:17'),
(79, 'TKT-20260811-664', 'Ticket', 1, 1, 700.00, 700.00, 720.00, 20.00, 'Efectivo', '2026-08-11 09:27:29'),
(80, 'TKT-20260811-508', 'Ticket', 1, 1, 700.00, 700.00, 720.00, 20.00, 'Tarjeta', '2026-08-11 09:36:09'),
(81, 'TKT-20260811-890', 'Ticket', 1, 1, 700.00, 700.00, 740.00, 40.00, 'Transferencia', '2026-08-11 09:49:53'),
(83, 'TKT-20260811-216', 'Ticket', 1, 1, 700.00, 700.00, 750.00, 50.00, 'Yape/Plin', '2026-08-11 10:47:49'),
(84, 'TKT-20260811-270', 'Ticket', 1, 1, 700.00, 700.00, 720.00, 20.00, 'Efectivo', '2026-08-11 16:03:56'),
(85, 'BOL-20260812-235', 'Boleta', 1, 1, 35.00, 35.00, 40.00, 5.00, 'Tarjeta', '2026-08-12 03:35:36'),
(89, 'TKT-20260813-461', 'Ticket', 1, 2, 1700.00, 1700.00, 1700.00, 0.00, 'Efectivo', '2026-08-13 01:06:17'),
(90, 'TKT-20260813-601', 'Ticket', 1, 1, 20.00, 20.00, 40.00, 20.00, 'Efectivo', '2026-08-13 02:47:52'),
(91, 'TKT-20260813-724', 'Ticket', 1, 1, 1700.00, 1700.00, 1720.00, 20.00, 'Efectivo', '2026-08-13 02:50:07'),
(92, 'BOL-20260814-323', 'Boleta', 1, 1, 360.00, 360.00, 400.00, 40.00, 'Efectivo', '2026-08-14 00:00:14'),
(93, 'TKT-20260814-871', 'Ticket', 1, 1, 4120.00, 4120.00, 4200.00, 80.00, 'Efectivo', '2026-08-14 01:49:01'),
(94, 'TKT-20260814-874', 'Ticket', 1, 1, 4120.00, 4120.00, 4200.00, 80.00, 'Efectivo', '2026-08-14 01:54:03'),
(95, 'TKT-20260818-459', 'Ticket', 1, 1, 2.00, 2.00, 5.00, 3.00, 'Efectivo', '2026-08-17 19:04:15'),
(96, 'TKT-20260818-881', 'Ticket', 1, 1, 2.00, 2.00, 5.00, 3.00, 'Efectivo', '2026-08-17 19:18:00'),
(97, 'TKT-20260818-507', 'Ticket', 1, 1, 22.00, 22.00, 30.00, 8.00, 'Efectivo', '2026-08-17 19:38:06'),
(98, 'TKT-20260818-335', 'Ticket', 1, 1, 14.00, 14.00, 15.00, 1.00, 'Efectivo', '2026-08-17 19:42:34'),
(99, 'TKT-20260818-874', 'Ticket', 1, 1, 2.00, 2.00, 5.00, 3.00, 'Efectivo', '2026-08-17 19:51:09'),
(100, 'TKT-20260818-276', 'Ticket', 1, 1, 32.00, 32.00, 40.00, 8.00, 'Efectivo', '2026-08-17 20:13:11');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas_detalle`
--

CREATE TABLE `ventas_detalle` (
  `id` int(11) NOT NULL,
  `id_venta` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `total_item` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas_detalle`
--

INSERT INTO `ventas_detalle` (`id`, `id_venta`, `id_producto`, `cantidad`, `precio_unitario`, `total_item`) VALUES
(76, 85, 15, 1, 35.00, 35.00),
(82, 89, 10, 1, 1700.00, 1700.00),
(83, 90, 17, 1, 20.00, 20.00),
(84, 91, 10, 1, 1700.00, 1700.00),
(85, 92, 9, 1, 360.00, 360.00),
(86, 93, 10, 2, 1700.00, 3400.00),
(87, 93, 9, 2, 360.00, 720.00),
(88, 94, 10, 2, 1700.00, 3400.00),
(89, 94, 9, 2, 360.00, 720.00),
(90, 95, 18, 1, 2.00, 2.00),
(91, 96, 18, 1, 2.00, 2.00),
(92, 97, 18, 1, 2.00, 2.00),
(93, 97, 17, 1, 20.00, 20.00),
(94, 98, 18, 1, 2.00, 2.00),
(95, 98, 16, 1, 12.00, 12.00),
(96, 99, 18, 1, 2.00, 2.00),
(97, 100, 17, 1, 20.00, 20.00),
(98, 100, 16, 1, 12.00, 12.00);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_productos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_productos` (
`id` int(11)
,`id_categoria` int(11)
,`codigo` varchar(50)
,`codigo_barras` varchar(50)
,`descripcion` varchar(255)
,`unidad_medida` varchar(30)
,`stock` int(11)
,`precio_venta` decimal(10,2)
,`categoria` varchar(255)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_productos`
--
DROP TABLE IF EXISTS `vista_productos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_productos`  AS SELECT `p`.`id` AS `id`, `p`.`id_categoria` AS `id_categoria`, `p`.`codigo` AS `codigo`, `p`.`codigo_barras` AS `codigo_barras`, `p`.`descripcion` AS `descripcion`, `p`.`unidad_medida` AS `unidad_medida`, `p`.`stock` AS `stock`, `p`.`precio_venta` AS `precio_venta`, coalesce(`c`.`categoria`,'Sin Categoría') AS `categoria` FROM (`productos` `p` left join `categorias` `c` on(`p`.`id_categoria` = `c`.`id`)) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cajas`
--
ALTER TABLE `cajas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `documento` (`documento`);

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `detalle_compras`
--
ALTER TABLE `detalle_compras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_detalle_compra` (`id_compra`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo_factura` (`codigo_factura`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `ventas_detalle`
--
ALTER TABLE `ventas_detalle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_venta` (`id_venta`),
  ADD KEY `id_producto` (`id_producto`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cajas`
--
ALTER TABLE `cajas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `detalle_compras`
--
ALTER TABLE `detalle_compras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT de la tabla `ventas_detalle`
--
ALTER TABLE `ventas_detalle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle_compras`
--
ALTER TABLE `detalle_compras`
  ADD CONSTRAINT `fk_detalle_compra` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `ventas_detalle`
--
ALTER TABLE `ventas_detalle`
  ADD CONSTRAINT `ventas_detalle_ibfk_1` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ventas_detalle_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
