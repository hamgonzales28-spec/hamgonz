-- ============================================================
-- FACTURACION ELECTRONICA SUNAT - INSTALACION MANUAL
-- ============================================================
-- Este archivo se ejecuta MANUALMENTE desde phpMyAdmin/MySQL.
-- El sistema PHP NO crea, migra ni modifica estas estructuras.
-- Ejecutar sobre la base de datos del sistema de ventas.
-- ============================================================

CREATE TABLE IF NOT EXISTS `sunat_configuracion` (
  `id` int NOT NULL DEFAULT 1,
  `ruc` varchar(11) NOT NULL DEFAULT '',
  `razon_social` varchar(150) NOT NULL DEFAULT '',
  `nombre_comercial` varchar(150) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `ubigeo` varchar(6) DEFAULT NULL,
  `departamento` varchar(100) DEFAULT NULL,
  `provincia` varchar(100) DEFAULT NULL,
  `distrito` varchar(100) DEFAULT NULL,
  `sol_usuario` varchar(100) DEFAULT NULL,
  `sol_clave` varchar(255) DEFAULT NULL,
  `certificado_path` varchar(500) DEFAULT NULL,
  `certificado_clave` varchar(255) DEFAULT NULL,
  `ambiente` enum('beta','produccion') NOT NULL DEFAULT 'beta',
  `serie_factura` varchar(4) NOT NULL DEFAULT 'F001',
  `serie_boleta` varchar(4) NOT NULL DEFAULT 'B001',
  `igv` decimal(5,2) NOT NULL DEFAULT 18.00,
  `activo` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `sunat_configuracion` (`id`,`ambiente`,`serie_factura`,`serie_boleta`,`igv`,`activo`)
VALUES (1,'beta','F001','B001',18.00,0)
ON DUPLICATE KEY UPDATE `id`=`id`;

CREATE TABLE IF NOT EXISTS `sunat_correlativos` (
  `tipo` varchar(20) NOT NULL,
  `serie` varchar(4) NOT NULL,
  `numero` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`tipo`,`serie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Columnas SUNAT en ventas. Estas sentencias se ejecutan manualmente.
ALTER TABLE `ventas` ADD COLUMN IF NOT EXISTS `sunat_estado` varchar(30) DEFAULT 'NO_APLICA';
ALTER TABLE `ventas` ADD COLUMN IF NOT EXISTS `sunat_codigo` varchar(20) DEFAULT NULL;
ALTER TABLE `ventas` ADD COLUMN IF NOT EXISTS `sunat_mensaje` text DEFAULT NULL;
ALTER TABLE `ventas` ADD COLUMN IF NOT EXISTS `sunat_ticket` varchar(100) DEFAULT NULL;
ALTER TABLE `ventas` ADD COLUMN IF NOT EXISTS `sunat_xml` varchar(500) DEFAULT NULL;
ALTER TABLE `ventas` ADD COLUMN IF NOT EXISTS `sunat_cdr` varchar(500) DEFAULT NULL;
ALTER TABLE `ventas` ADD COLUMN IF NOT EXISTS `sunat_hash` varchar(64) DEFAULT NULL;
ALTER TABLE `ventas` ADD COLUMN IF NOT EXISTS `sunat_fecha_envio` datetime DEFAULT NULL;
